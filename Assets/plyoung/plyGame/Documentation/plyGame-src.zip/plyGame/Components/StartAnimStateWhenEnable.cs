﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[AddComponentMenu("plyGame/Misc/Start Anim State when Enable")]
	public class StartAnimStateWhenEnable : MonoBehaviour
	{
		public Animator animator;
		public string stateName;

		private int hash = 0;

		protected void Awake()
		{
			if (animator != null && !string.IsNullOrEmpty(stateName))
			{
				hash = Animator.StringToHash(stateName);
			}
		}

		protected void OnEnable()
		{
			if (hash != 0)
			{
				animator.Play(hash);//, -1, 0f);
			}
		}

		// ============================================================================================================
	}
}