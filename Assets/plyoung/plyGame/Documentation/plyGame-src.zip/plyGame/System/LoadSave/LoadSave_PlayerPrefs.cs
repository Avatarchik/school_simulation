﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[AddComponentMenu("")]
	public class LoadSave_PlayerPrefs : LoadSaveProviderBase
	{
		public override void Save()
		{
			PlayerPrefs.Save();
		}

		public override bool HasKey(string key)
		{
			return PlayerPrefs.HasKey(key);
		}

		public override void DeleteKey(string key)
		{
			PlayerPrefs.DeleteKey(key);
		}

		public override void DeleteAll()
		{
			PlayerPrefs.DeleteAll();
		}

		public override void SetString(string key, string value)
		{
			PlayerPrefs.SetString(key, value);
		}

		public override string GetString(string key, string defaultVal)
		{
			return PlayerPrefs.GetString(key, defaultVal);
		}

		// ============================================================================================================
	}
}