﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	/// <summary> Type used to identify plyGame related objects. </summary>
	public enum plyGameObjectIdentifyingType
	{
		ident,		//!< identify object by its ident
		screenName, //!< identify object by its Screen Name
		shortName,  //!< identify object by its Short Name
		meta		//!< identify object by its meta data
	}

	// ================================================================================================================
}