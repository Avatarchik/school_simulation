﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================
/*
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary> plyGame Input manager </summary>
	[AddComponentMenu("")]
	public class plyInput : MonoBehaviour
	{
		/// <summary> Gets reference to the plyInput instance </summary>
		public static plyInput Instance { get; private set; }

		/// <summary> The defined and sorted input definitions. [group, list-of-inputs-under-group] </summary>
		public Dictionary<string, List<InputDefinition>> Inputs { get { if (sortedInputs == null) SortInputs(); return sortedInputs; } }
		private Dictionary<string, List<InputDefinition>> sortedInputs = null; // <group, list-of-inputs-under-group>

		/// <summary> Set this to True in each frame that input from mouse was handled. Will be reset to
		///  False in LateUpdate() </summary>
		public static bool MouseInputHandled { get; set; }

		// ============================================================================================================

		private static int nextIndex = 0;
		private static InputDefinition[] inputs = new InputDefinition[0];

		private static readonly string[] MouseAxisString = new string[] { "None", "MouseX", "MouseY", "ScrollWheel" };
		private static readonly string[] GamepadAxisString = new string[] { "Pad1A1", "Pad1A2", "Pad1A3", "Pad1A4", "Pad1A5", "Pad1A6", "Pad1A7", "Pad1A8", "Pad1A9", "Pad1A10" };

		private static bool shownInputConfigError = false;

		// ============================================================================================================
		#region system

		protected void Awake()
		{
			Instance = this;
			MouseInputHandled = false;
			Object.DontDestroyOnLoad(gameObject);
		}

		protected void LateUpdate()
		{
			MouseInputHandled = false;
		}

		#endregion
		// ============================================================================================================
		#region pub

		/// <summary> Initialise plyInput. You need to specify the maximum amount of buttons and axis that
		///  will be defined. The parentObject you specify should be a global that will not be destroyed
		///  during the life of the game running, else simply pass null and plyInput will create its own
		///  object. If asset is set then then the inputs (buttons) defined in it will be added now. </summary>
		public static void Init(GameObject parentObject, int maxButtonDefines, InputDefAsset asset)
		{
			if (Instance == null)
			{
				if (parentObject == null)
				{
					parentObject = new GameObject("plyInput");
					Object.DontDestroyOnLoad(parentObject);
				}
				parentObject.AddComponent<plyInput>();
			}

			if (asset != null)
			{
				if (maxButtonDefines < asset.inputDefs.Count) maxButtonDefines = asset.inputDefs.Count;
			}

			nextIndex = 0;
			inputs = new InputDefinition[maxButtonDefines];

			if (asset != null)
			{
				for (int i = 0; i < asset.inputDefs.Count; i++) DefineButton(asset.inputDefs[i]);
			}

		}

		/// <summary> Call to save the changes made to the buttons to PlayerPrefs or via SaveLoad provider. </summary>
		public static void Save()
		{
			// todo
		}

		/// <summary> Call this only after having defined all buttons to read the changes that where saved
		///  to PlayerPrefs (or via SaveLoad provider) and overwrite any defaults assigned while defining
		///  the buttons. </summary>
		public static void Restore()
		{
			// todo
		}

		/// <summary> Define a button from an input definition. Return index (idx) of new input or -1 on error. </summary>
		public static int DefineButton(InputDefinition def)
		{
			if (nextIndex >= inputs.Length)
			{
				Debug.LogError("You need to call Init with the correct value for the maximum possible buttons that will be defined.");
				return -1;
			}

			inputs[nextIndex] = def.Copy();
			nextIndex++;
			return nextIndex - 1;
		}

		/// <summary> Return the index (idx) of the defined button, -1 if not found. An def.ident is the combination of category and name
		/// for example: "Player/SelectNextTarget" </summary>
		public static int GetInputIdx(string def.ident)
		{
			for (int i = 0; i < inputs.Length; i++)
			{
				if (inputs[i].def.ident == def.ident)
				{
					return i;
				}
			}
			return -1;
		}

		/// <summary> Return true if the input definition is active </summary>
		public static bool IsActive(int idx)
		{
			if (idx < 0) return false;
			return inputs[idx].active;
		}

		/// <summary> Return true if the inputs, identified by idx1 and idx2, use similar buttons or axis. </summary>
		public static bool SameBinds(int idx1, int idx2)
		{
			if (idx1 < 0 || idx2 < 0) return false;
			if (inputs[idx1].type != inputs[idx2].type) return false;
			if (!inputs[idx1].active || !inputs[idx2].active) return false;

			if (inputs[idx1].type == InputDefinition.InputType.Button)
			{
				return
					inputs[idx1].key1 == inputs[idx2].key1 ||
					inputs[idx1].key1 == inputs[idx2].key2 ||
					inputs[idx1].key1 == inputs[idx2].key1Alt ||
					inputs[idx1].key1 == inputs[idx2].key2Alt ||
					inputs[idx1].key2 == inputs[idx2].key1 ||
					inputs[idx1].key2 == inputs[idx2].key2 ||
					inputs[idx1].key2 == inputs[idx2].key1Alt ||
					inputs[idx1].key2 == inputs[idx2].key2Alt ||
					inputs[idx1].key1Alt == inputs[idx2].key1 ||
					inputs[idx1].key1Alt == inputs[idx2].key2 ||
					inputs[idx1].key1Alt == inputs[idx2].key1Alt ||
					inputs[idx1].key1Alt == inputs[idx2].key2Alt ||
					inputs[idx1].key2Alt == inputs[idx2].key1 ||
					inputs[idx1].key2Alt == inputs[idx2].key2 ||
					inputs[idx1].key2Alt == inputs[idx2].key1Alt ||
					inputs[idx1].key2Alt == inputs[idx2].key2Alt;
			}
			else
			{
				return
					inputs[idx1].mouseAxis == inputs[idx2].mouseAxis ||
					(
						inputs[idx1].gamepad == inputs[idx2].gamepad &&
						inputs[idx1].gamepadAxis == inputs[idx2].gamepadAxis
					);
			}
		}

		// ============================================================================================================

		/// <summary> True if it is mouse button </summary>
		public static bool IsMouseButton(KeyCode k)
		{
			return (k >= KeyCode.Mouse0 && k <= KeyCode.Mouse6);
		}

		/// <summary> Returns true while the virtual button is held down. </summary>
		public static bool GetButton(int idx)
		{
			if (idx < 0) return false;
			if (!inputs[idx].active) return false;
			if (inputs[idx].type != InputDefinition.InputType.Button) return false;

			if (MouseInputHandled)
			{	// if bind uses mouse button then it will not be allowed
				if ((Input.GetKey(inputs[idx].key1) && IsMouseButton(inputs[idx].key1)) ||
					(Input.GetKey(inputs[idx].key2) && IsMouseButton(inputs[idx].key2)) ||
					(Input.GetKey(inputs[idx].key1Alt) && IsMouseButton(inputs[idx].key1Alt)) ||
					(Input.GetKey(inputs[idx].key2Alt) && IsMouseButton(inputs[idx].key2Alt))
					) return false;
			}

			return ((Input.GetKey(inputs[idx].key1) && (inputs[idx].key2 == KeyCode.None || Input.GetKey(inputs[idx].key2))) ||
					(Input.GetKey(inputs[idx].key1Alt) && (inputs[idx].key2Alt == KeyCode.None || Input.GetKey(inputs[idx].key2Alt))) );
		}

		/// <summary> Returns true during the frame the user pressed down the virtual button identified by
		///  'name'. </summary>
		public static bool GetButtonDown(int idx)
		{
			if (idx < 0) return false;
			if (!inputs[idx].active) return false;
			if (inputs[idx].type != InputDefinition.InputType.Button) return false;

			if (MouseInputHandled)
			{	// if bind uses mouse button then it will not be allowed
				if ((Input.GetKeyDown(inputs[idx].key1) && IsMouseButton(inputs[idx].key1)) ||
					(Input.GetKeyDown(inputs[idx].key2) && IsMouseButton(inputs[idx].key2)) ||
					(Input.GetKey(inputs[idx].key1Alt) && IsMouseButton(inputs[idx].key1Alt)) ||
					(Input.GetKey(inputs[idx].key2Alt) && IsMouseButton(inputs[idx].key2Alt))
					) return false;
			}

			return ((Input.GetKeyDown(inputs[idx].key1) && (inputs[idx].key2 == KeyCode.None || Input.GetKey(inputs[idx].key2))) || 
					(Input.GetKeyDown(inputs[idx].key1Alt) && (inputs[idx].key2Alt == KeyCode.None || Input.GetKey(inputs[idx].key2Alt))) );
		}

		/// <summary> Returns true the first frame the user releases the virtual button. </summary>
		public static bool GetButtonUp(int idx)
		{
			if (idx < 0) return false;
			if (!inputs[idx].active) return false;
			if (inputs[idx].type != InputDefinition.InputType.Button) return false;

			if (MouseInputHandled)
			{	// if bind uses mouse button then it will not be allowed
				if ((Input.GetKeyUp(inputs[idx].key1) && IsMouseButton(inputs[idx].key1)) ||
					(Input.GetKeyUp(inputs[idx].key2) && IsMouseButton(inputs[idx].key2)) ||
					(Input.GetKey(inputs[idx].key1Alt) && IsMouseButton(inputs[idx].key1Alt)) ||
					(Input.GetKey(inputs[idx].key2Alt) && IsMouseButton(inputs[idx].key2Alt))
					) return false;
			}
			
			return ((Input.GetKeyUp(inputs[idx].key1) && (inputs[idx].key2 == KeyCode.None || Input.GetKey(inputs[idx].key2))) || 
					(Input.GetKeyUp(inputs[idx].key1Alt) && (inputs[idx].key2Alt == KeyCode.None || Input.GetKey(inputs[idx].key2Alt))) );
		}

		/// <summary> Returns the value of the virtual axis. </summary>
		public static float GetAxis(int idx)
		{
			try
			{
				try
				{
					if (idx < 0) return 0f;
					if (!inputs[idx].active) return 0f;
					if (inputs[idx].type != InputDefinition.InputType.Axis) return 0f;

					if (Input.GetKey(inputs[idx].key1) || Input.GetKey(inputs[idx].key1Alt)) return 1f;
					if (Input.GetKey(inputs[idx].key2) || Input.GetKey(inputs[idx].key2Alt)) return -1f;

					if (inputs[idx].mouseAxis != InputDefinition.MouseAxis.None)
					{
						float f = Input.GetAxis(MouseAxisString[(int)inputs[idx].mouseAxis]);
						if (f != 0.0f)
						{
							if (inputs[idx].mouseInvert) f *= -1f;
							return f;
						}
					}

					if (inputs[idx].gamepad != InputDefinition.Gamepad.None && inputs[idx].gamepadAxis != InputDefinition.GamepadAxis.None)
					{
						int i = (((int)inputs[idx].gamepad - 1) * 4) + (int)inputs[idx].gamepadAxis;
						float f = Input.GetAxis(GamepadAxisString[i]);
						if (inputs[idx].gamepadInvert) f *= -1f;
						return f;
					}
				}
				catch (UnityException)
				{
					if (!shownInputConfigError)
					{
						Debug.LogError("Definition missing. Required by: " + inputs[idx].name);
						Debug.LogError("The Unity Input Manager configuration seems to be invalid. Go to plyGame Main Editor > Input Definitions and press the 'Setup Input Manager' button. Have a look at the plyGame documentation to learn more.");
						shownInputConfigError = true;
					}
				}
			}
			catch (System.IndexOutOfRangeException)
			{
				if (!shownInputConfigError)
				{
					Debug.LogError("The Unity Input Manager configuration seems to be invalid. Go to plyGame Main Editor > Input Definitions and press the 'Setup Input Manager' button. Have a look at the plyGame documentation to learn more.");
					shownInputConfigError = true;
				}
			}

			return 0f;
		}

		/// <summary> Returns the axis for input idx1. If it is 0 then the axis for input idx2 will be returned. </summary>
		public static float GetAxis(int idx1, int idx2)
		{
			float f = GetAxis(idx1);
			if (f != 0.0f) return f;
			return GetAxis(idx2);
		}

		// ============================================================================================================

		/// <summary> Call this before using the Inputs property to make sure the Dictionary is inited
		///  correctly with latest input definitions. </summary>
		public void SortInputs()
		{
			sortedInputs = new Dictionary<string, List<InputDefinition>>();
			for (int i = 0; i < inputs.Length; i++)
			{
				if (inputs[i] == null) break;
				List<InputDefinition> l = null;
				if (sortedInputs.ContainsKey(inputs[i].category)) l = sortedInputs[inputs[i].category];
				if (l == null)
				{
					l = new List<InputDefinition>();
					sortedInputs.Add(inputs[i].category, l);
				}
				l.Add(inputs[i]);
			}
		}

		#endregion
		// ============================================================================================================
	}
}
*/