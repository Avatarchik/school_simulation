﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class EventHandler_OnGUIScreens : plyEventHandler
	{
		private List<plyEvent> screenShownEvents = new List<plyEvent>(0);

		// ============================================================================================================

		public override void StateChanged()
		{
			screenShownEvents = new List<plyEvent>(0);
		}

		public override void AddEvent(plyEvent e)
		{
			if (e.uniqueIdent.Equals("On Screen Shown"))
			{
				screenShownEvents.Add(e);
				bloxObject.NeedObjectActive = true;
			}
		}

		public override void CheckEvents()
		{
			// disable this component if there is nothing for it to do
			enabled = screenShownEvents.Count > 0;
			screenShownEvents.TrimExcess();
		}

		// ============================================================================================================

		public void OnScreenShown(string screenName, int screenType)
		{
			if (screenShownEvents.Count == 0) return;
			RunEvents(screenShownEvents, new plyEventArg("screenName", screenName), new plyEventArg("screenType", screenType));
		}

		// ============================================================================================================
	}
}
