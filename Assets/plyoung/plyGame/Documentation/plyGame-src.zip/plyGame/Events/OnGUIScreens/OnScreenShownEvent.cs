﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("GUI", "On Screen Shown",
		Description = "Called when a plyGame GUI Screen is about to become visible.\n\n" +
		"The following Temporary Variables will be set:\n\n" +
		"- <b>screenName</b>: (String) Name of the screen.\n" +
		"- <b>screenType</b>: (Integer) 0 = Custom Screen, 1 = Load Screen.\n"
		)]
	public class OnScreenShownEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_OnGUIScreens);
		}

		// ============================================================================================================
	}
}