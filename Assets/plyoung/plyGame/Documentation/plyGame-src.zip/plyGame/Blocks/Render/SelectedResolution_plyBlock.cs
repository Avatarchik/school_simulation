﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Render", "Screen (plyGame)", "Selected Resolution", BlockType.Variable, Order = 31, ShowName = "Selected Resolution",
		ReturnValueString="Return - String", ReturnValueType = typeof(String_Value),
		Description = "Return a string name of the current resolution in the temporary resolution setting.")]
	public class SelectedResolution_plyBlock : String_Value
	{
		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = GameGlobal.Instance.GetSelectedResolution();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}