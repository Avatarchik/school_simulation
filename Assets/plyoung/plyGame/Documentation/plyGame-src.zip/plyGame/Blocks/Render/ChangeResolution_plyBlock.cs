﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Render", "Screen (plyGame)", "Change Resolution", BlockType.Action, Order = 31,
		Description = "Increase or decrease the selected resolution. It does not apply any resolution but only allows you to change the selection. Use 'Apply' to apply the selected resolution.")]
	public class ChangeResolution_plyBlock : plyBlock
	{
		public enum Do { Increase, Decrease }

		[plyBlockField("Do", ShowAfterField = "Resolution", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public Do mode = Do.Increase;

		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.ChangeSelectedResolution(mode == Do.Increase);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}