﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Audio", "Sound (plyGame)", "Change Volume", BlockType.Action, Order = 1, ShowIcon = "listener", ShowName="Change volume",
		Description = "Change volume of a sound type. The volume range from 0 (minimum) to 100 (maximum). You need to make a call to the 'Apply' when done so that all volume updaters are informed and the changes saved.")]
	public class plyGame_Audio_ChangeVolume : plyBlock
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "The sound volume type to affect.")]
		public GameGlobal.VolumeType type = GameGlobal.VolumeType.Main;

		[plyBlockField("by", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Amount - Integer", Description = "The amount by which to change the volume. A positive number will increase it while a negative number decreases it. The volume will be capped between 0 and 100.")]
		public Int_Value amount;

		public override void Created()
		{
			GameGlobal.Create();
			stopAllOnError = false;
			blockIsValid = amount != null;
			if (!blockIsValid) Log(LogType.Error, "You need to specify an amount.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Instance.ChangeSoundVolumeBy(type, amount.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}