﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Audio", "Sound (plyGame)", "Play Music", BlockType.Action, Order = 1, ShowIcon = "audio",
		Description = "Starts a music clip. Will stop and replace any existing playing music.")]
	public class plyGame_Audio_PlayMusic : plyBlock
	{
		[plyBlockField("Play Music", SubName = "Clip - Audio Clip", ShowName = true, ShowValue = true, DefaultObject = typeof(UnityObject_Value), BasicTypeHint = typeof(AudioClip), Description = "The music clip to start.")]
		public UnityObject_Value clip;

		[plyBlockField("Only if none playing", Description = "Set this if you want the music to only be started if no existing music is playing or the playing music is not the same as specified clip.")]
		public bool onlyIfNonePlaying = true;

		public override void Created()
		{
			GameGlobal.Create();
			stopAllOnError = false;
			blockIsValid = clip != null;
			if (!blockIsValid) Log(LogType.Error, "The music clip must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			AudioClip aud = clip.RunAndGetUnityObject() as AudioClip;
			if (aud == null)
			{
				Log(LogType.Error, "The music clip is invalid.");
				return BlockReturn.Error;
			}

			GameGlobal.Instance.PlayMusic(aud, onlyIfNonePlaying);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}