﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Show Custom Screen", BlockType.Action, Order = 10, 
		Description = "Will show a custom screen. These screens are created in the plyGame Interface Editor.")]
	public class ShowCustomScreen_plyBlock : plyBlock
	{

		[plyBlockField("Show Screen:", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screen = new ScreenDefNameTextData();

		[plyBlockField("Additive", Description = "Select whether this screen should be made visible additively or not. If you unselect this option (False) then all visible screens will be hidden before this one is made visible. If selected (True) then this screen will be made visible without touching the visibility of other screens.")]
		public bool additive = true;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = !string.IsNullOrEmpty(screen.name);
			if (!blockIsValid) Log(LogType.Error, "Screen Name must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				Log(LogType.Warning, "The screen system is not yet ready. You are making calls too early.");
				return BlockReturn.OK;
			}

			if (additive) GameGlobal.Instance.uiManager.ShowAdditive(screen.name, true);
			else GameGlobal.Instance.uiManager.Show(screen.name, true);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}