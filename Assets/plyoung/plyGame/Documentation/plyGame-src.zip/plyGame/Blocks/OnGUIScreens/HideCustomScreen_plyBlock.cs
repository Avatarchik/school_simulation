﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Hide Custom Screen", BlockType.Action, Order = 10, 
		Description = "Will hide a custom screen. These screens are created in the plyGame Interface Editor.")]
	public class HideCustomScreen_plyBlock : plyBlock
	{
		[plyBlockField("Hide Screen:", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screen = new ScreenDefNameTextData();

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = !string.IsNullOrEmpty(screen.name);
			if (!blockIsValid) Log(LogType.Error, "Screen Name must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				return BlockReturn.OK;
			}

			GameGlobal.Instance.uiManager.ShowAdditive(screen.name, false);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}