﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Get Profile Count", BlockType.Variable, Order = 1, ShowName = "LoadSave Profile Count",
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value),
		/*CustomStyle = "plyBlox_VarYellowDark",*/ Description = "Get the number of profiles that are saved.")]
	public class LoadSave_GetProfileCount_plyBlock : Int_Value
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = GameGlobal.GetSavedProfileCount();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}