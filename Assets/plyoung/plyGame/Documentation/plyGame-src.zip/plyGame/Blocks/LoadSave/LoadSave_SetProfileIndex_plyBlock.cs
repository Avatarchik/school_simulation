﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Set Profile (idx)", BlockType.Action, Order = 1,
		Description = "Set the active profile by index.")]
	public class LoadSave_SetProfileIndex_plyBlock : plyBlock
	{
		[plyBlockField("Set LoadSave Profile to", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), EmptyValueName = "-invalid-", SubName = "Profile Index - Integer", Description="The index (number) of the profile to activate.")]
		public Int_Value index;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = index != null;
			if (!blockIsValid) Log(LogType.Error, "The Profile index must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.SetActiveProfile(index.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}