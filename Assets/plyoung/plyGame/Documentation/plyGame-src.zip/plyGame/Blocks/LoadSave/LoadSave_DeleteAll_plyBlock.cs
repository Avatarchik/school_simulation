﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Delete All", BlockType.Action, Order = 1, ShowName = "Delete All Saved Data",
		Description = "Will delete all data stored by LoadSave System.")]
	public class LoadSave_DeleteAll_plyBlock : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.DeleteAllSaveData();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}