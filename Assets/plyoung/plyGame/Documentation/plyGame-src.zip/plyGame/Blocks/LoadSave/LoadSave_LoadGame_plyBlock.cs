﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Load Game", BlockType.Action, Order = 1, ShowName = "Load Game from",
		Description = "Load state of game from the specified slot of active profile. Will fail with error message in console if slot has nothing to load. Will change active Slot if a slot is given.")]
	public class LoadSave_LoadGame_plyBlock : plyBlock
	{
		[plyBlockField("Slot", ShowName = true, ShowValue = true, EmptyValueName = "-current-", SubName="Slot - Integer", Description="The slot to load from. Leave empty if currently set slot should be used. Will change the current/ active slot to this one if set.")]
		public Int_Value slot;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (slot != null) GameGlobal.SetActiveSaveSlot(slot.RunAndGetInt());
			GameGlobal.LoadGameSession();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}