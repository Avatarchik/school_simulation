﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("IO", "LoadSave (plyGame)", "Set Slot", BlockType.Action, Order = 1,
		Description = "Set the Slot, for active profile, that the LoadSave system should use when a Save or Load related request is made.")]
	public class LoadSave_SetSlot_plyBlock : plyBlock
	{
		[plyBlockField("Set LoadSave Slot to", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), EmptyValueName = "-invalid-", SubName = "Slot - Integer", Description="The Slot to set as the current/ active one.")]
		public Int_Value slot;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = slot != null;
			if (!blockIsValid) Log(LogType.Error, "The Slot field must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.SetActiveSaveSlot(slot.RunAndGetInt());
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}