﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	public class ScreenDefNameTextData
	{
		public string name = "";

		public override string ToString()
		{
			return string.IsNullOrEmpty(name) ? "-invalid-" : name;
		}

		public ScreenDefNameTextData Copy()
		{
			ScreenDefNameTextData o = new ScreenDefNameTextData();
			o.name = this.name;
			return o;
		}

		// ============================================================================================================
	}
}