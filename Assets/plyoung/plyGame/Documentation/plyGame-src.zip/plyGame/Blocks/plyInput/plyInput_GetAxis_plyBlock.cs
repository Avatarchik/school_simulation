﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Input", "Input (plyGame)", "Get Axis", BlockType.Variable, Order = 1,
		ReturnValueString = "Return - Float", ReturnValueType = typeof(Float_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns the value of an Axis. It is normally between -1 and +1. '0' would be when the axis is at its default location. Take for example a joystick axis that can be moved left and right. All the way to left would then be -1 while all the way to the right would be a value of +1 and if the stick is not sued it would be 0 or a value very close to 0. This block works with the axis you defined in plyGame Input Definitions editor.")]
	public class plyInput_GetAxis_plyBlock : Float_Value
	{

		[plyBlockField("Axis Name", ShowAfterField = "Axis", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public InputDefNameTextData axis = new InputDefNameTextData(); // input definition name

		private int AxisIdx = -1;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = !string.IsNullOrEmpty(axis.name);
			if (!blockIsValid) Log(LogType.Error, "Axis Name must be set.");
		}

		public override void Initialise()
		{
			AxisIdx = plyInput.GetInputIdx(axis.name);
			value = 0f;
			if (AxisIdx == -1) blockIsValid = false;
			if (!blockIsValid) Log(LogType.Error, "Axis is not defined: " + axis.name);
		}

		public override BlockReturn Run(BlockReturn param)
		{
			value = plyInput.GetAxis(AxisIdx);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}