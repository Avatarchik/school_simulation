﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Flow", "System", "(un)Pause Game", BlockType.Action, Order = 0,
		Description = "Pause or Continue the game. In this state the character controllers and some other game systems will not execute. This is useful when you do not want player character input or NPC AI to execute while in-game menus are open.")]
	public class plyGame_Pause_plyBlock : plyBlock
	{
		public enum State { Pause, Continue }

		[plyBlockField("State", ShowAfterField="Game", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "Set whether game is paused or not.")]
		public State state = State.Pause;

		public override void Created()
		{
			GameGlobal.Create();
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameGlobal.Paused = (state == State.Pause);
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}