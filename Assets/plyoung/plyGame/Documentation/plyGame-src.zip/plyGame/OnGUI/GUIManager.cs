﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	[RequireComponent(typeof(plyBlox))]
	public class GUIManager : MonoBehaviour
	{
		public static GUIManager Instance { get; private set; }

		// ============================================================================================================

		private GameObject guiCameraObject;
		private Camera guiCamera;
		private bool showSimpleLoad = false;
		private Rect simpleLoadFrame;
		private EventHandler_OnGUIScreens events = null;

		private float loadTimer = 0f;
		private GUIScreen showLoadScreen = null;
		private bool needToHideLoadScreen = false;
		private int needToRecalcFrames = 0;

		public List<GUIScreen> visibleScreens { get; set; }
		public List<GUIScreen> loadScreens { get; set; }
		public List<GUIScreen> customScreens { get; set; }
		public plyBlox bloxObject { get; set; }
		public float minLoadTime { get; set; }
		public bool clickToContinue { get; set; }

		/// <summary> Use this to find out if the screens system is ready. You should not make calls to its functions
		/// while this is false. The Screen system only initialise properly after the Language screen exits. </summary>
		public bool screensSystemReady { get; set; }

		public AudioSource _audioSource = null;

		// ============================================================================================================

		protected void Awake()
		{
			Instance = this;
			Object.DontDestroyOnLoad(gameObject);

			bloxObject = gameObject.GetComponent<plyBlox>();
			events = gameObject.GetComponent<EventHandler_OnGUIScreens>();

			minLoadTime = 0f;
			screensSystemReady = false;
			visibleScreens = new List<GUIScreen>(0);
			loadScreens = new List<GUIScreen>(0);
			customScreens = new List<GUIScreen>(0);

			guiCameraObject = new GameObject("ONGUICamera");
			guiCameraObject.transform.parent = gameObject.transform;
			guiCamera = guiCameraObject.AddComponent<Camera>();
			guiCamera.clearFlags = CameraClearFlags.SolidColor;
			guiCamera.backgroundColor = Color.black;
			guiCamera.nearClipPlane = 1f;
			guiCamera.farClipPlane = 100.0f;
			guiCamera.depth = 100;
			guiCamera.rect = new Rect(0.0f, 0.0f, 1.0f, 1.0f);
			guiCamera.orthographic = true;
			guiCamera.orthographicSize = Screen.height / 2;
			guiCamera.transform.position = new Vector3(Screen.width / 2, -Screen.height / 2, -10.0f);
			guiCamera.cullingMask = 0;
			guiCamera.useOcclusionCulling = false;
		}

		protected void Start()
		{
			ShowSimpleLoad();
		}

		public void ScreenResolutionChanged()
		{
			needToRecalcFrames = 2; // I will wait 2 frames before actually doing it so screen res got time to change
		}

		public void AddLoadScreen(GUIScreen s)
		{
			loadScreens.Add(s);
			s.OnAddedToManager();
			RegisterEventListener(s);
		}

		public void AddCustomScreen(GUIScreen s)
		{
			customScreens.Add(s);
			s.OnAddedToManager();
			RegisterEventListener(s);
		}

		private void RegisterEventListener(GUIScreen s)
		{
			for (int i = 0; i < s.uiElements.Count; i++)
			{
				if (!string.IsNullOrEmpty(s.uiElements[i].eventName))
				{
					s.uiElements[i].SetCallback(OnElementEvent, null);
				}
			}
		}

		public void RemoveAllScreens()
		{
			for (int i = 0; i < visibleScreens.Count; i++) visibleScreens[i].OnVisibleChange(false);
			visibleScreens = new List<GUIScreen>(0);
			if (!showSimpleLoad)
			{
				if (!GUIManager.Instance.bloxObject.NeedObjectActive) gameObject.SetActive(false);
				guiCameraObject.SetActive(false);
			}
		}

		public void HideAllScreens(bool forced)
		{
			if (showSimpleLoad || showLoadScreen != null)
			{
				HideLoadScreen(forced);
			}

			for (int i = 0; i < visibleScreens.Count; i++) visibleScreens[i].OnVisibleChange(false);
			visibleScreens = new List<GUIScreen>(0);
			if (!showSimpleLoad && showLoadScreen == null)
			{
				if (!GUIManager.Instance.bloxObject.NeedObjectActive) gameObject.SetActive(false);
				guiCameraObject.SetActive(false);
			}
		}

		public void HideLoadScreen()
		{
			HideLoadScreen(false);
		}

		public void HideLoadScreen(bool force)
		{
			if (!showSimpleLoad && showLoadScreen == null) return;

			if (!force)
			{
				needToHideLoadScreen = true;
				if (clickToContinue)
				{
					if (Input.anyKey == false) return;
				}
				else
				{
					if (loadTimer < minLoadTime) return;
				}
			}

			needToHideLoadScreen = false;
			if (showLoadScreen!=null) showLoadScreen.OnVisibleChange(false);
			showSimpleLoad = false;
			showLoadScreen = null;
			UpdateClearFlag();

			if (visibleScreens.Count == 0)
			{
				if (!GUIManager.Instance.bloxObject.NeedObjectActive) gameObject.SetActive(false);
				guiCameraObject.SetActive(false);
			}
		}

		//  Will hide all screens and show "now loading ..."
		public void ShowSimpleLoad()
		{
			HideAllScreens(true);
			gameObject.SetActive(true);
			guiCameraObject.SetActive(true);
			simpleLoadFrame = new Rect(Screen.width * 0.5f - 40, Screen.height * 0.5f, 200, 30);
			loadTimer = 0f;
			showSimpleLoad = true;
			guiCamera.clearFlags = CameraClearFlags.Color;
			guiCamera.backgroundColor = Color.black;
		}

		public void ShowLoadScreen(int index)
		{
			if (index < 0 || index >= loadScreens.Count)
			{
				Debug.LogWarning("Index ("+index+") is not within the range of defined screens [0.." + loadScreens.Count + "]. Now showing random load screen.");
				ShowLoadScreen();
				return;
			}

			HideAllScreens(true);
			gameObject.SetActive(true);
			guiCameraObject.SetActive(true);
			if (events != null) events.OnScreenShown(loadScreens[index].name, 1);
			loadScreens[index].OnVisibleChange(true);
			showLoadScreen = loadScreens[index];
			loadTimer = 0f;
			guiCamera.clearFlags = CameraClearFlags.Color;
			guiCamera.backgroundColor = showLoadScreen.backgroundColor;
		}

		public void ShowLoadScreen(string name)
		{
			int index = -1;
			for (int i=0; i < loadScreens.Count; i++)
			{
				if (loadScreens[i].name.Equals(name)) { index = i; break; }
			}

			if (index == -1)
			{
				Debug.LogWarning("The given load screen name is not defined ["+name+"]. Now showing random load screen.");
				ShowLoadScreen();
				return;
			}

			HideAllScreens(true);
			gameObject.SetActive(true);
			guiCameraObject.SetActive(true);
			if (events != null) events.OnScreenShown(loadScreens[index].name, 1);
			loadScreens[index].OnVisibleChange(true);
			showLoadScreen = loadScreens[index];
			loadTimer = 0f;
			guiCamera.clearFlags = CameraClearFlags.Color;
			guiCamera.backgroundColor = showLoadScreen.backgroundColor;
		}

		// Will hide all screens and show a random Load Screen
		public void ShowLoadScreen()
		{
			if (loadScreens.Count == 0)
			{
				ShowSimpleLoad();
				return;
			}

			HideAllScreens(true);
			gameObject.SetActive(true);
			guiCameraObject.SetActive(true);
			int r = loadScreens.Count > 1 ? Random.Range(0, loadScreens.Count) : 0;
			if (events != null) events.OnScreenShown(loadScreens[r].name, 1);
			loadScreens[r].OnVisibleChange(true);
			showLoadScreen = loadScreens[r];

			loadTimer = 0f;
			guiCamera.clearFlags = CameraClearFlags.Color;
			guiCamera.backgroundColor = showLoadScreen.backgroundColor;
		}

		public void Show(string screenName, bool show)
		{
			for (int i = 0; i < customScreens.Count; i++)
			{
				if (customScreens[i].name.Equals(screenName))
				{
					Show(customScreens[i], show);
					return;
				}
			}
		}

		public void Show(GUIScreen screen, bool show)
		{
			HideAllScreens(false);
			ShowAdditive(screen, show);
		}

		public void ShowAdditive(string screenName, bool show)
		{
			for (int i = 0; i < customScreens.Count; i++)
			{
				if (customScreens[i].name.Equals(screenName))
				{
					ShowAdditive(customScreens[i], show);
					return;
				}
			}
		}

		private void ShowAdditive(GUIScreen screen, bool show)
		{
			if (show)
			{
				if (visibleScreens.Count == 0)
				{
					gameObject.SetActive(true);
					guiCameraObject.SetActive(true);
				}

				if (!visibleScreens.Contains(screen))
				{
					if (events != null) events.OnScreenShown(screen.name, 0);
					visibleScreens.Add(screen);
					UpdateClearFlag();
					screen.OnVisibleChange(true);
				}
			}
			else
			{
				screen.OnVisibleChange(false);
				visibleScreens.Remove(screen);
				if (visibleScreens.Count == 0)
				{
					if (!GUIManager.Instance.bloxObject.NeedObjectActive) gameObject.SetActive(false);
					guiCameraObject.SetActive(false);
				}
			}
		}

		public bool IsVisible(string screenName)
		{
			for (int i = 0; i < visibleScreens.Count; i++)
			{
				if (visibleScreens[i].name.Equals(screenName)) return true;
			}
			return false;
		}

		public bool IsVisible(GUIScreen screen)
		{
			if (screen == null) return false;
			return screen.visible;
		}

		public GUIScreen GetScreen(string screenName)
		{
			for (int i = 0; i < customScreens.Count; i++)
			{
				if (customScreens[i].name.Equals(screenName)) return customScreens[i];
			}
			return null;
		}

		public GUIScreen GetScreen(int id)
		{
			for (int i = 0; i < customScreens.Count; i++)
			{
				if (customScreens[i].id == id) return customScreens[i];
			}
			return null;
		}

		private void UpdateClearFlag()
		{
			if (showSimpleLoad || showLoadScreen != null) return;

			bool clearBack = false;
			for (int i = visibleScreens.Count - 1; i >= 0; i--)
			{
				if (visibleScreens[i].doClearBack)
				{
					guiCamera.clearFlags = CameraClearFlags.Color;
					guiCamera.backgroundColor = visibleScreens[i].backgroundColor;
					clearBack = true;
					break;
				}
			}

			if (!clearBack)
			{
				guiCamera.clearFlags = CameraClearFlags.Depth;
			}
		}

		// ============================================================================================================

		public void PlayGUISound(AudioClip clip)
		{
			if (_audioSource == null)
			{
				_audioSource = gameObject.AddComponent<AudioSource>();
				SoundVolumeUpdater updater = gameObject.AddComponent<SoundVolumeUpdater>();
				updater.audioSource = _audioSource;
				updater.volumeType = GameGlobal.Instance.dataAsset.guiVolumeType;
				_audioSource.playOnAwake = false;
				_audioSource.bypassEffects = true;
				_audioSource.bypassListenerEffects = true;
				_audioSource.bypassReverbZones = true;
				_audioSource.loop = false;
			}

			_audioSource.Stop();
			_audioSource.clip = clip;
			_audioSource.Play();
		}

		public void StopGUISound()
		{
			if (_audioSource != null) _audioSource.Stop();
		}

		// ============================================================================================================

		protected void Update()
		{
			if (showSimpleLoad || showLoadScreen!=null)
			{
				loadTimer += Time.deltaTime;
				if (needToHideLoadScreen) HideLoadScreen();
			}

			if (needToRecalcFrames > 0)
			{
				needToRecalcFrames--;
				if (needToRecalcFrames == 0)
				{
					for (int i = 0; i < customScreens.Count; i++)
					{
						customScreens[i].needRecalcFrames = true;
					}
					for (int i = 0; i < loadScreens.Count; i++)
					{
						loadScreens[i].needRecalcFrames = true;
					}
				}
			}
		}

		protected void OnGUI()
		{
			if (showSimpleLoad)
			{
				plyInput.MouseInputHandled = true;
				GUI.Label(simpleLoadFrame, "now loading ...");
				return;
			}

			if (showLoadScreen!=null)
			{
				plyInput.MouseInputHandled = true;
				showLoadScreen.DrawElements();
				return;
			}

			for (int i = 0; i < visibleScreens.Count; i++)
			{
				if (visibleScreens[i].doClearBack) plyInput.MouseInputHandled = true; // do not allow click-through if user can't see what is behind the screen
				visibleScreens[i].DrawElements();
			}

			if (GUIUtility.hotControl != 0 || guiCamera.clearFlags == CameraClearFlags.Color) plyInput.MouseInputHandled = true;
		}

		private static void OnElementEvent(object sender, object[] args)
		{
			OnGUIElement ele = (OnGUIElement)sender;
			plyEvent ev = GUIManager.Instance.bloxObject.GetEvent(ele.eventName);
			if (ev == null)
			{
				Debug.LogError("GUIManager: Event [" + ele.eventName + "] not found.");
				return;
			}

			ev.SetTempVarValue("param1", ele.eventParam1);
			ev.SetTempVarValue("param2", ele.eventParam2);
			ev.SetTempVarValue("param3", ele.eventParam3);
			GUIManager.Instance.bloxObject.RunEvent(ev);
		}

		// ============================================================================================================
	}
}