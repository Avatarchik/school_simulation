﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[System.Serializable]
	public class OnGUIBox : OnGUIElement
	{
		// ============================================================================================================

		public OnGUIBox()
		{
			type = UIElementType.Box;
			styleName = "box";
		}

		public override OnGUIElement Copy()
		{
			OnGUIBox obj = new OnGUIBox();
			this.CopyTo(obj);
			return obj;
		}

		public override void CopyTo(OnGUIElement obj)
		{
			base.CopyTo(obj);
		}

		// ============================================================================================================

		public override void Draw()
		{
			GUI.Box(frame, GUIContent.none, style);
		}

		public override void EdDraw(Rect r)
		{
			GUI.Box(r, GUIContent.none, style);
		}

		// ============================================================================================================
	}
}