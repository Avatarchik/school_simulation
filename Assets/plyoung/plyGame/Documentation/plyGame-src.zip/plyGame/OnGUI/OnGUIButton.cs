﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[System.Serializable]
	public class OnGUIButton : OnGUIElement
	{
		public string label;
		public Texture2D image;

		// ============================================================================================================

		private GUIContent content = null;

		// ============================================================================================================

		public OnGUIButton()
		{
			type = UIElementType.Button;
			styleName = "button";
		}

		public override OnGUIElement Copy()
		{
			OnGUIButton obj = new OnGUIButton();
			this.CopyTo(obj);
			return obj;
		}

		public override void CopyTo(OnGUIElement obj)
		{
			base.CopyTo(obj);
			OnGUIButton o = obj as OnGUIButton;
			o.image = this.image;
			o.label = this.label;
			o.soundClip = this.soundClip;
		}

		// ============================================================================================================

		public override void InitGUICache(GUISkin skin)
		{
			base.InitGUICache(skin);
			content = new GUIContent(label, image);
		}

		public override void Draw()
		{
			if (GUI.Button(frame, content, style))
			{
				PlaySound();
				if (onEvent != null) onEvent(this, args);
			}
		}

		public override void EdDraw(Rect r)
		{
			GUI.Box(r, content, style);
		}

		public override void SetText(string txt)
		{
			label = txt;
			content = new GUIContent(label, image);
		}

		public override void SetImage(Texture2D img)
		{
			image = img;
			content = new GUIContent(label, image);
		}

		// ============================================================================================================
	}
}