﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[System.Serializable]
	public class OnGUIMovie : OnGUIElement
	{
		public Texture video;

		// ============================================================================================================

		public OnGUIMovie()
		{
			type = UIElementType.Movie;
			Reflect();
		}

		public override OnGUIElement Copy()
		{
			OnGUIMovie obj = new OnGUIMovie();
			this.CopyTo(obj);
			return obj;
		}

		public override void CopyTo(OnGUIElement obj)
		{
			base.CopyTo(obj);
			OnGUIMovie o = obj as OnGUIMovie;
			o.video = this.video;
		}

		// ============================================================================================================

		private System.Type MovieTextureType;
		private System.Reflection.MethodInfo playMethod;
		private System.Reflection.MethodInfo StopMethod;
		private System.Reflection.PropertyInfo isPlayingProperty;

		private void Reflect()
		{
			MovieTextureType = System.Type.GetType("UnityEngine.MovieTexture, UnityEngine");
			if (MovieTextureType != null)
			{
				playMethod = MovieTextureType.GetMethod("Play");
				StopMethod = MovieTextureType.GetMethod("Stop");
				isPlayingProperty = MovieTextureType.GetProperty("isPlaying");
			}
		}

		private void PlayMovieTexture()
		{
			StopMovieTexture();
			playMethod.Invoke(video, null);
		}

		private void StopMovieTexture()
		{
			StopMethod.Invoke(video, null);
		}

		private bool MovieTextureIsPlaying()
		{
			return (bool)isPlayingProperty.GetValue(video, null);
		}

		// ============================================================================================================

		public override void Init()
		{
			if (MovieTextureType == null) return;
		}

		public override void OnScreenVisibleChange(bool becomeVisible)
		{
			base.OnScreenVisibleChange(becomeVisible);
			if (!this.visible) return;
			if (MovieTextureType == null)
			{
				Debug.LogError("Movie playback not supported.");
				return;
			}

			if (becomeVisible)
			{
				if (video != null) PlayMovieTexture();
				if (soundClip != null) GUIManager.Instance.PlayGUISound(soundClip);
			}
			else
			{
				if (video != null) StopMovieTexture();
				if (soundClip != null) GUIManager.Instance.StopGUISound();
			}
		}

		public override void Draw()
		{
			if (video != null)
			{
				GUI.DrawTexture(frame, video);
			}
		}

		public override void EdDraw(Rect r)
		{
			if (video != null)
			{
				GUI.DrawTexture(r, video);
			}
		}

		// ============================================================================================================

		public bool IsPlaying
		{
			get 
			{
				if (video == null) return false;
				return MovieTextureIsPlaying();
			}
		}

		// ============================================================================================================
	}
}