﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary> The input definitions. </summary>
	[System.Serializable]
	public class InputDefAsset : ScriptableObject
	{
		[HideInInspector] public List<InputDefinition> inputDefs = new List<InputDefinition>(); //!< List if defined input definitions

		// ============================================================================================================
	}
}