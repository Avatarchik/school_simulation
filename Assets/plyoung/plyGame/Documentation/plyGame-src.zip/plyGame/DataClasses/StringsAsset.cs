﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	[System.Serializable]
	public class StringsAsset : ScriptableObject
	{
		[HideInInspector] public string language = "";	// Default language if empty.
		[HideInInspector] public List<string> strings = new List<string>();	

		// ============================================================================================================
	}
}