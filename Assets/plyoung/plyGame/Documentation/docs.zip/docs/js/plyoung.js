$(document).ready(function(){
	var o="work";
	var u=window.location.href.match(/#(.*)/);
	if(u){if(u[1]&&u[1]!==""){o=u[1]}}
	showPanel(o);

	$("li#work a").click(function(){showPanel("work")});
	$("li#life a").click(function(){showPanel("life")});
	$("li#contact a").click(function(){showPanel("contact")});

    $("#submit_btn").click(function() { 
        var user_name    = $('input[name=name]').val(); 
        var user_email   = $('input[name=email]').val();
        var user_message = $('textarea[name=message]').val();
        
        var proceed = true;
        if(user_name==""){ $('input[name=name]').css('border-color','red'); proceed = false;}
        if(user_email==""){ $('input[name=email]').css('border-color','red'); proceed = false;}
        if(user_message=="") {$('textarea[name=message]').css('border-color','red'); proceed = false;}
        
        if(proceed) {
            post_data = {'userName':user_name, 'userEmail':user_email, 'userMessage':user_message};
            $.post('contact.php', post_data, function(data){  
                $("#result").hide().html('<div class="alert alert-success">'+data+'</div>').slideDown();		                
                $('#contactForm input').val(''); 
                $('#contactForm textarea').val(''); 		                
            }).fail(function(err) {$("#result").hide().html('<div class="alert alert-danger">'+err.statusText+'</div>').slideDown();});
        }
    });
    $("#contactForm input, #contactForm textarea").keyup(function() { $("#contactForm input, #contactForm textarea").css('border-color',''); $("#result").slideUp();});		    
    function showPanel(opt){
        $(".plypanel").hide();
        $(".navbar-nav li").removeClass("active");
        $("#"+opt+"-panel").slideDown();
        $("#"+opt).addClass("active");
    }
});
