$(document).ready(function() {
  // images, thumb and lighbox
  $("a.thumb").each(function(){$(this).attr("data-toggle", "modal").attr("data-target","#lightbox")});
  var $lightbox = $('#lightbox');
  $('[data-target="#lightbox"]').on('click', function(event) {
    var $img = $(this).find('img'),src = $img.attr('src'),alt = $img.attr('alt'),css = {'maxWidth': $(window).width() - 100,'maxHeight': $(window).height() - 100};
    $lightbox.find('img').attr('src', src);
    $lightbox.find('img').attr('alt', alt);
    $lightbox.find('img').css(css);
  }); 
  $lightbox.on('shown.bs.modal', function (e) {
    var $img = $lightbox.find('img');
    $lightbox.find('.modal-dialog').css({'width': $img.width()});
  });

  // c# and blox syntax highlight
  $('pre code').each(function(i,v){hljs.highlightBlock(v);});
  $('pre code.blox').each(function(i,v){$(v).html(FormatBlox($(v).html()));});
  $('.hljs-event-block').popover({placement: 'top', animation: 'true'});
  $('.hljs-variable-block').popover({animation: 'true', html: 'true'});
  $('.hljs-condition-block').popover({animation: 'true', html: 'true'});
  $('.hljs-container-block').popover({animation: 'true', html: 'true'});
  $('.hljs-action-block').popover({animation: 'true', html: 'true'});
});

function FormatBlox(s)
{
  var start = s.indexOf('[@E:');
  if (start>=0) {    
    lend = s.indexOf('\n', start + 1);
    end = s.indexOf('@]', start+4);
    mrk = s.indexOf(':: ', start+4);
    if (mrk>=0 && end>=0 && mrk<lend && end<lend)
    {
      src = s.substring(start, end + 2);
      blk = s.substring(start + 4, mrk);
      label = s.substring(mrk+3, end);
      s = s.replace(src, 'Event: ' + label);
      s = s.substr(0, start - 1) + ' title="' + blk + '"' + s.substr(start - 1);
      start = s.indexOf('\n', start);
    }else return 'Error in blox syntax detected\nThis can hapen when the page is translated';
  } else start = 0;

  var done = false;
  while (done == false){
    start = s.indexOf('>[@C:', start);
    if (start < 0) start = s.indexOf('>[@B:', start);
    if (start >= 0){
      end = s.indexOf('\n', start + 1);  
      src = s.substring(start, end);  
      fb = FormatBlock(src, 0);
      if (fb==null) return 'Error in blox syntax detected\nThis can hapen when the page is translated';
      s = s.replace(src,fb);
      start = end;
    }else done = true;
  }
  return s;
}

function FormatBlock(s, i)
{
  var pl = 'right';
  if (i > 3) i = 1;
  if (i==1) pl = 'top';
  else if (i==2) pl = 'bottom';
  else if (i==3) pl = 'left';

  var src, blk, fb, s1=0,s2=0,s3=0, ve=0, vs=0;
  var tooltip = '';
  var start = 1;
  var end = s.indexOf(':: ', start + 4);
  var end_alt = s.indexOf('@]', start + 4);
  if (end >= 0 && end < end_alt)
  {
    src = s.substring(start, end + 3);
    tooltip = src.substring(4, end - start);
    tooltip = tooltip.replace('/>/G', '&gt;');
    s = s.replace(src, '');
    s = s.substr(0, start - 1) + 'data-placement="'+pl+'" data-content="' + tooltip + '"' + s.substr(start - 1);
  }
  else
  {
    end = s.indexOf('@]');
    if (end >= 0)
    {
      src = s.substring(start, end + 2);
      blk = src.substring(4, end - start);
      s = s.replace(src, blk);
    }
  }

  start = s.indexOf('>[@B:');
  if (start >= 0)
  {
    end = s.indexOf('@]', start+1);
    src = s.substring(start);
    fb = FormatBlock(src, i+1);
    if (fb==null)return null;
    s = s.replace(src,fb);
  }

  if (tooltip.length > 0) 
  {
    start = tooltip.length + pl.length + 32;
    var done = false;
    tooltip = "";
    var ve = start, vs = start;
    while (done == false)
    {
      vs = s.indexOf('[V:');
      end_alt = s.indexOf('@]');
      if (vs >= 0 && (vs < end_alt || end_alt < 0))
      {
        ve = s.indexOf(':V]', vs);
        s1 = s.indexOf('[V:',vs+3);
        s2 = s.indexOf('[H:',vs+3);
        s3 = s.indexOf('[@B:',vs+3);
        if (ve>vs && (ve<s1||s1<0) && (ve<s2||s2<0) && (ve<s3||s3<0))
        {
          src = s.substring(vs, ve + 3);
          blk = s.substring(vs + 3, ve);
          blk = '<b>' + blk.substring(blk.indexOf('\001')+1) + '</b>';
          s = s.replace(src, blk);
        }else{
          //alert(s + "\n\nA: ve="+ve+"\nvs="+vs+"\ns1="+s1+"\ns2="+s2+"\ns3="+s3);
          return null;
        }
      } 
      else
      {
        vs = s.indexOf('[H:');
        if (vs >= 0 && (vs < end_alt || end_alt < 0))
        {
          ve = s.indexOf(':H]', vs);
          s1 = s.indexOf('[V:',vs+3);
          s2 = s.indexOf('[H:',vs+3);
          s3 = s.indexOf('[@B:',vs+3);
          if (ve>vs && (ve<s1||s1<0) && (ve<s2||s2<0) && (ve<s3||s3<0))
          {
            src = s.substring(vs, ve + 3);
            blk = s.substring(vs + 3, ve);
            tooltip += '<br>' + blk.replace('\001', " := '") + "'";
            s = s.replace(src, '');
          }else{
            //alert(s + "\n\nB: ve="+ve+"\nvs="+vs+"\ns1="+s1+"\ns2="+s2+"\ns3="+s3);
            return null;
          }
        }
        else done = true;
      }
    }    
    s = s.substr(0, start) + tooltip + s.substr(start);
  }
  s = s.replace('@]', '');
  return s;
}