﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Skill", "On Skill Activate",
		Description = "Called when a skill is used/ activated.\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>skillOwner</b>: The Actor (GameObject) that owns the Skill.\n"+
		"- <b>skillObject</b>: The Skill (GameObject).\n" +
		"- <b>skillOwnerData</b>: Data (System.Object) of owner. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"+
		"- <b>skillData</b>: Data (System.Object) of skill. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
		"- <b>selectedPos</b>: (Vector3) The position of the object that was selected when the Skill was activated. Only valid if something was selected. You will probably only use this if the Skill depends on something being selected.\n" +
		"- <b>mouseClickPos</b>: (Vector3) The world position of the mouse when the skill was activated.\n"
	)]
	public class SkillActivateEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Skills);
		}

		// ============================================================================================================
	}
}