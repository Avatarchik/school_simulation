﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Factions", "On Status Change",
		Description = "Called when the status (relationship) of one faction towards another, changed.\n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>newStatus</b>: The new status\n  1 = Friendly\n  2 = Neutral\n  3 = Hostile\n"+
		"- <b>faction</b>: The faction who's status changed towards the other. This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n" +
		"- <b>otherFac</b>: The faction towards which the status changed. This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n" +
		"- <b>factionIdx</b>: Index of faction who's status changed towards the other. Index is in order as defined factions, starting at 0.\n" +
		"- <b>otherFacIdx</b>: Index of the faction towards which the status changed. Index is in order as defined factions, starting at 0.\n"
	)]
	public class FactionStatusChangedEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Factions);
		}

		// ============================================================================================================
	}
}