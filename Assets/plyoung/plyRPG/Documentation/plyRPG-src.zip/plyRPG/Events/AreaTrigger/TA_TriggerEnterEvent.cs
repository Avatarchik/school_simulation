﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("Trigger/Area Trigger", "On AreaTrigger Enter",
		Description = "This Event should be used on an Area Trigger only. Called when another collider enters the trigger area. Note that trigger events are only sent if one of the colliders also has a rigid body attached.\n\n" + 
		"The following Temporary Variables will be set:\n\n" +
		"- <b>type</b>: The type of object that caused the trigger. (Integer) with one of the following values, 0: unknown, 1: player, 2: npc.\n" +
		"- <b>obj</b>: The GameObject that caused the trigger."
		)]
	public class TA_TriggerEnterEvent: plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_TATrigger);
		}

		// ============================================================================================================
	}
}