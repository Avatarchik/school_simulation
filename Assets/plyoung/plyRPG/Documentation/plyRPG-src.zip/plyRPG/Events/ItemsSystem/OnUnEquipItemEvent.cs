﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Items", "On UnEquip Item",
		Description = "Called when an Item is un-equipped. You can use this Event in the plyBlox of an Item or the object that has the Equipment Slots component on it. The Event will first trigger for the Equipment Slots and then for the Item. It is triggered just before the Item object is removed from the character (from scene)." +
		"\n\nThe following Temporary Variables will be set:\n\n" +
		"- <b>equipSlot</b>: The slot (int) from which the Item was removed.\n" +
		"- <b>item</b>: The Item (System.Object) that was removed. The Item object just before it is destroyed (removed from character in scene). This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
		"- <b>owner</b>: The owner (GameObject) of the Slot the Item was removed from.\n"
		)]
	public class OnUnEquipItemEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Item);
		}

		// ============================================================================================================
	}
}