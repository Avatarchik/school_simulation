﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Items", "On Remove Item from Bag",
		Description = "Called when an Item is removed from a Bag. You can use this Event in the plyBlox of an Item or object that has an Item Bag component. It will first trigger for the Bag and then for the Item. The event is triggered for the instance of the item in the bag just before it is destroyed." + 
		"\n\nThe following Temporary Variables will be set:\n\n" +
		"- <b>bagSlot</b>: The bag slot (int) from which the Item was taken.\n" +
		"- <b>item</b>: The Item (System.Object) that was removed from the bag. Instance of the Item objet in the bag just before the object is destroyed. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n" +
		"- <b>owner</b>: The owner (GameObject) of the bag from which the Item was removed.\n"
		)]
	public class OnRemoveItemFromBagEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Item);
		}

		// ============================================================================================================
	}
}