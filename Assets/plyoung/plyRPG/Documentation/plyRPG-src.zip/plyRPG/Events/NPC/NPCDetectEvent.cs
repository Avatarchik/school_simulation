﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/NPC", "On Detect Characters",
		Description = "Called when the Non-Player Character (NPC) detects another NPC or the Player Character. This Event will trigger in Blox on the NPC Object and child objects of it. (note: You can use the Actor Events, 'make selection' and 'clear selection', to act when the NPC engage or disengage a target)\n\nThe following Temporary Variables will be set:\n\n- <b>closest</b>: The closest (GameObject) of all the detected characters.\n- <b>total</b>: The total number of characters detected.\n")]
	public class NPCDetectEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_NPC);
		}

		// ============================================================================================================
	}
}