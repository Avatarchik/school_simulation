﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Actor", "On Actor Death",
		Description = "Called when the Actor (Character) is killed. This is called as soon as the death loop is started. This Event will trigger in Blox on the Character Object and child objects of it.\n")]
	public class OnActorDeathEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Actor);
		}

		// ============================================================================================================
	}
}