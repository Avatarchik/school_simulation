﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Equip (plyRPG)", "UnEquip Item", BlockType.Action, Order = 4,
		Description = "Remove Item from specified Equipment Slot.")]
	public class Equip_Un_plyBlock : plyBlock
	{
		[plyBlockField("UnEquip Slot", CustomValueStyle = "plyBlox_BoldLabel", ShowName = true, ShowValue = true, Description = "")]
		public EquipSlotData equipSlotNfo = new EquipSlotData();

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has equip slots.")]
		public GameObject_Value target;

		[plyBlockField("drop option", CustomValueStyle = "plyBlox_BoldLabel", Description = "What should happen to the unequipped item if the bag is full.")]
		public ItemBag.ItemDropOption dropOpt = ItemBag.ItemDropOption.toScene;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private EquipmentSlots slots;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			// ** Get reference to equip slots
			if (slots == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				slots = go.GetComponent<EquipmentSlots>();
				if (slots == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Equipments Slots component on it.");
					return BlockReturn.Error;
				}
			}

			if (false == slots.UnEquipItem(equipSlotNfo.name, dropOpt))
			{
				Log(LogType.Error, "Failed to unequip item.");
				return BlockReturn.Error;
			}

			if (!cacheTarget) slots = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}