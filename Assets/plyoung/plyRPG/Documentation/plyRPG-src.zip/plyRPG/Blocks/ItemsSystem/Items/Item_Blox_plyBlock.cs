﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Items (plyRPG)", "Item plyBlox", BlockType.Variable, Order = 1,
		ReturnValueString = "Return - plyBlox", ReturnValueType = typeof(plyBlox_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Return the plyBlox object of the specified Item. Note that for an Item in the Bag you should not manipulate local variable values for stacked Items as only the variables for the 1st Item in the stack will be updated. You would normally use it to read the local variables of Items and in some cases update the values for Items in the scene or those which are equipped (not those in the bag, except if not stacked kind).")]
	public class Item_Blox_plyBlock : plyBlox_Value
	{
		[plyBlockField("Blox of Item", ShowName = true, ShowValue = true, DefaultObject = typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item object.")]
		public SystemObject_Value itVal;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = itVal != null;
			if (!blockIsValid) Log(LogType.Error, "The Item field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			Item item = itVal.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid.");
				return BlockReturn.Error;
			}

			value = item.GetComponent<plyBlox>();

			if (value == null)
			{
				Log(LogType.Error, "The Item does not have a plyBlox.");
				return BlockReturn.Error;
			}

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}