﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Items (plyRPG)", "Item", BlockType.Variable, Order = 1,
		ReturnValueString = "Return - System.Object", ReturnValueType = typeof(SystemObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Allows you to pick an Item from list of defined Items or via its meta data. Return reference to Item object which can be used in other Item related Blocks.")]
	public class Item_plyBlock : SystemObject_Value
	{
		[plyBlockField("Item", ShowIfTargetFieldInvalid = "itemNfo", ShowValue = true, Description = "You can either select the Item from a list or choose to identify it by its screen name, ident, meta, or short name. Choose 'none' from the list to use the ident method and then add a String block in the provided space so that you can enter the ident.")]
		public String_Value ident;

		[plyBlockField("Item", CustomValueStyle = "plyBlox_BoldLabel")]
		public ItemFieldData itemNfo = new ItemFieldData();

		[plyBlockField("ident type", ShowIfTargetFieldInvalid = "itemNfo", Description = "What kind of value did you enter to identify the Item by?")]
		public plyGameObjectIdentifyingType identType = plyGameObjectIdentifyingType.screenName;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Item Object, if you know it will not change, improving performance a little. This is done either way when the Item was chosen from a list.")]
		public bool cacheTarget = false;

		private Item item = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (string.IsNullOrEmpty(itemNfo.id))
			{
				cacheTarget = true;
				if (ident == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Item ident is not set.");
					return;
				}
			}
			else
			{
				ident = null; // set to null since the nfo method is used
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (item == null)
			{
				// ** need to lookup the item
				if (ident != null)
				{
					// first find the id
					item = ItemsAsset.Instance.GetDefinition(ident.RunAndGetString(), identType);
					if (item == null)
					{
						Log(LogType.Error, "The specified Item is not defined: " + ident.RunAndGetString() + " (" + identType + ")");
						return BlockReturn.Error;
					}
				}

				// ** item was selected from list
				else
				{	// create an id and lookup the item. gonna cache it since it won't change at runtime.
					UniqueID uid = new UniqueID(itemNfo.id);
					item = ItemsAsset.Instance.GetDefinition(uid);
					if (item == null)
					{
						Log(LogType.Error, "The Item does not seem to be defined any longer.");
						return BlockReturn.Error;
					}
				}
			}

			value = item;
			if (!cacheTarget) item = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}