﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Equip (plyRPG)", "Get Item in EquipSlot", BlockType.Variable, Order = 4, ShowName = "Item in",
		ReturnValueString = "Return - System.Object", ReturnValueType = typeof(SystemObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Get the Item in specified equip slot. Will return empty/ null value if no Item is in the Slot.")]
	public class EquipSlot_GetInSlot_plyBlock : SystemObject_Value
	{
		[plyBlockField("Equip Slot", ShowName = true, ShowValue = true, DefaultObject = typeof(String_Value), SubName = "Slot - String/ Integer", Description = "Slot to look in. This can be either the name (string) of the index (integer) of the slot. Any other value type will throw an error.")]
		public plyValue_Block slot;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has equip slots.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private EquipmentSlots equipSlots;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = slot != null;
			if (!blockIsValid) Log(LogType.Error, "The Slot must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (equipSlots == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				equipSlots = go.GetComponent<EquipmentSlots>();
				if (equipSlots == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Equipment Slot component on it.");
					return BlockReturn.Error;
				}
			}

			object v = slot.RunAndGetValue();
			if (v == null)
			{
				Log(LogType.Error, "The Slot value was null.");
				return BlockReturn.Error;
			}

			if (v.GetType() == typeof(int))
			{
				//Debug.Log("int = " + ((int)v).ToString());
				value = equipSlots.ItemInSlot((int)v);
			}
			else if (v.GetType() == typeof(string))
			{
				//Debug.Log("str = " + ((string)v));
				value = equipSlots.ItemInSlot((string)v);
			}
			else
			{
				Log(LogType.Error, "The Slot field must be of type string or integer.");
				return BlockReturn.Error;
			}

			if (!cacheTarget) equipSlots = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}