﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Render", "Markers (plyRPG)", "Add Marker", BlockType.Action, Order = 10,
		Description = "Add a marker to the target object as specified offset from target's pivot.")]
	public class Marker_Add_plyBlock : plyBlock
	{
		[plyBlockField("Add marker", ShowIfTargetFieldInvalid = "markerInfo", ShowName = true, ShowValue = true, Description = "The marker to add. You can either identify it by its name or select it from a list. To use the name method, select none from the list and then add a String block in the provided space so that you can enter the name of the Marker.")]
		public String_Value markerName;

		[plyBlockField("Marker", CustomValueStyle = "plyBlox_BoldLabel")]
		public MarkerFieldData markerInfo = new MarkerFieldData();

		[plyBlockField("to", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The owner of the marker. The marker will become a child object of this object and follow it around.")]
		public GameObject_Value target;

		[plyBlockField("with offset", ShowName = true, ShowValue = true, EmptyValueName = "(0,0,0)", SubName = "Offset - Vector3", Description = "Position to offset the marker from the target's pivot point.")]
		public Vector3_Value offset;

		[plyBlockField("and name", ShowName = true, ShowValue = true, EmptyValueName = "-default-", SubName = "Name - String", Description = "You can enter a new name so that it is easy to identify the marker when you need to show or hide it. Keep this empty if you want to use the default name.")]
		public String_Value newName;

		[plyBlockField("visible", SubName = "visible - Boolean", Description = "Should the marker be visible or hidden after it is added?")]
		public bool visible = true;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private GameObject go = null;
		private GameObject markerFab = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = true;
		}

		public override void Initialise()
		{
			if (string.IsNullOrEmpty(markerInfo.id))
			{
				if (markerName == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Name of marker to use must be set or you must select one from the list.");
					return;
				}
			}
			else
			{
				markerName = null; // not using the name method
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (go == null)
			{
				go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}
			}

			if (markerFab == null)
			{
				// ** need to look it up
				if (markerName != null)
				{
					// first find the id
					markerFab = MarkersAsset.Instance.GetPrefab(markerName.RunAndGetString());
					if (markerFab == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The specified Marker is not defined: " + markerName);
						return BlockReturn.Error;
					}
				}
				// ** was selected from list
				else
				{	// create an id and lookup the skill. gonna cache it since it won't change at runtime.
					UniqueID id = new UniqueID(markerInfo.id);
					markerFab = MarkersAsset.Instance.GetPrefab(id);
					if (markerFab == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Marker does not seem to be defined any longer. Check the List of markers in the plyGame Editor Window.");
						return BlockReturn.Error;
					}
				}
			}

			GameObject mgo = (GameObject)Object.Instantiate(markerFab);
			if (newName != null)
			{
				string s = newName.RunAndGetString();
				if (!string.IsNullOrEmpty(s)) mgo.name = s;
				else mgo.name = markerFab.name;
			}
			else mgo.name = markerFab.name; // do not want the "(copy)" in name

			mgo.transform.parent = go.transform;
			if (offset != null) mgo.transform.localPosition = offset.RunAndGetVector3();
			else mgo.transform.localPosition = Vector2.zero;

			mgo.SetActive(visible);

			if (false == cacheTarget)
			{
				// do not cache
				go = null;
				markerFab = null;
			}

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}