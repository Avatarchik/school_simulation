﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Anim", "Character Legacy (plyRPG)", "Go Idle", BlockType.Action, Order = 5,
		 Description = "Set Character back in normal mode and in idle animation. This sets the character legacy animation controller back into 'normal' state where it can control the idle and movement animations.")]
	public class Chara_GoIdle_plyBlock : plyBlock
	{
		[plyBlockField("Set", ShowAfterField="to go Idle", SubName = "Target - GameObject", EmptyValueName = "-self-", ShowName = true, ShowValue = true, Description = "The character.")]
		public GameObject_Value targetChara;

		[plyBlockField("Cache target", Description = "Tell plyBlox whether it may cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private LegacyAnimControl animController;

		public override void Created()
		{
			stopAllOnError = false;
			blockIsValid = true;
			if (targetChara == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			
			
				if (animController == null)
				{
					GameObject go = targetChara == null ? owningBlox.gameObject : targetChara.RunAndGetGameObject();
					if (go == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "Target is invalid.");
						return BlockReturn.Error;
					}

					animController = go.GetComponent<LegacyAnimControl>();
					if (animController == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target does not have a legacy animation controller.");
						return BlockReturn.Error;
					}
				}

				animController.GoIdle();
				if (!cacheTarget) animController = null;
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}