﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Action Slot (plyRPG)", "Equip Skill", BlockType.Action, Order = 7,
		Description = "Equip a Skill to specified slot. Will force the player to learn the skill if not known.")]
	public class Ac_EquipSkill_plyBlock : plyBlock
	{
		[plyBlockField("Equip", ShowName = true, ShowValue = true, DefaultObject = typeof(Skill_plyBlock), SubName = "Skill - SystemObject", Description = "The Skill to equip.")]
		public SystemObject_Value val;

		[plyBlockField("on ActionSlot", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Slot Number - Integer", Description = "Slot number to equip to. Slots starts at number 0.")]
		public Int_Value slotVal;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a player object.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private PlayerBaseController player = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = val != null && slotVal != null;
			if (!blockIsValid) Log(LogType.Error, "The skill and slot number fields must be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (player == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					player = o.GetComponent<PlayerBaseController>();
					if (player == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Player Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			Skill skill = val.RunAndGetSystemObject() as Skill;
			if (skill == null)
			{
				Log(LogType.Error, "The Skill value is invalid.");
				return BlockReturn.Error;
			}

			Skill sk = player.actor.LearnSkill(skill, true);
			if (sk != null)
			{
				if (!player.actionSlots.EquipSkill(slotVal.RunAndGetInt(), sk.id))
				{
					Log(LogType.Error, "Error while trying to equip.");
					return BlockReturn.Error;
				}
			}
			else
			{
				Log(LogType.Error, "Skill not valid.");
				return BlockReturn.Error;
			}

			if (false == cacheTarget) player = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}