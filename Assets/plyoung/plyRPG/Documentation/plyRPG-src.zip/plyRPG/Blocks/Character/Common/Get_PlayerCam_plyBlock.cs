﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Common (plyRPG)", "Player Camera", BlockType.Variable, Order = 1, ShowName = "Player Camera",
		ReturnValueString = "Return - GameObject", ReturnValueType = typeof(GameObject_Value),
		Description = "Returns the active player camera GameObject. Prints error to console if camera is not yet set.")]
	public class Get_PlayerCam_plyBlock : GameObject_Value
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (Player.Camera == null)
			{
				Log(LogType.Error, "Player Camera is not yet set.");
				return BlockReturn.Error;
			}

			value = Player.Camera.gameObject;

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}