﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Action Slot (plyRPG)", "Equip Item", BlockType.Action, Order = 7,
		Description = "Equip an Item to specified slot.")]
	public class Ac_EquipItem_plyBlock : plyBlock
	{
		[plyBlockField("Equip", ShowName = true, ShowValue = true, DefaultObject = typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item to equip.")]
		public SystemObject_Value val;

		[plyBlockField("on ActionSlot", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value),  SubName = "Slot Number - Integer", Description = "Slot number to equip to. Slots starts at number 0.")]
		public Int_Value slotVal;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a player object.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		//private ItemBag bag = null;
		private PlayerBaseController player = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = val != null && slotVal != null;
			if (!blockIsValid) Log(LogType.Error, "The item and slot number fields must be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			//if (bag == null)
			//{
			//	GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
			//	if (o != null)
			//	{
			//		bag = o.GetComponent<ItemBag>();
			//		if (bag == null)
			//		{
			//			blockIsValid = false;
			//			Log(LogType.Error, "The Target is invalid. Could not find any Item Bag on it.");
			//			return BlockReturn.Error;
			//		}
			//	}
			//}

			if (player == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					player = o.GetComponent<PlayerBaseController>();
					if (player == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Player Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			Item item = val.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid.");
				return BlockReturn.Error;
			}

			if (!player.actionSlots.EquipItem(slotVal.RunAndGetInt(), item.prefabId))
			{
				Log(LogType.Error, "Error while trying to equip.");
				return BlockReturn.Error;
			}

			if (false == cacheTarget)
			{
				//bag = null;
				player = null;
			}

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}