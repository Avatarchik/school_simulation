﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "PlayerMan (plyRPG)", "Destroy Player", BlockType.Action, Order = 2, ShowName = "Destroy Player",
		Description = "Instruct the Player Manager to destroy the player character currently in the scene.")]
	public class PlrMan_DestroyPlr_plyBlock : plyBlock
	{
		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (PlayerManager.Instance == null)
			{
				Log(LogType.Error, "The Player Manager is not active. Make sure you've set it up correctly.");
				return BlockReturn.Error;
			}

			PlayerManager.Instance.DestroyPlayer();
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}