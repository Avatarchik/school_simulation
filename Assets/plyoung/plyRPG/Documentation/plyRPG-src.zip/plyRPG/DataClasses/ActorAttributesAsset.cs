﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> Contains the defined Actor Attributes. </summary>
	[System.Serializable]
	public class ActorAttributesAsset : ScriptableObject
	{

		[HideInInspector] public List<ActorAttribute> attributes = new List<ActorAttribute>(); //!< List of all defined attributes
		[HideInInspector] public UniqueID hpAttribId = new UniqueID(); //!< Id of Attribute that represents Health in the game
		[HideInInspector] public UniqueID xpAttribId = new UniqueID(); //!< Id of Attribute that represents Experience in the game

		// ============================================================================================================

		/// <summary> Provide access to asset at runtime </summary>
		public static ActorAttributesAsset Instance
		{
			get
			{
				if (_instance == null)
				{	// try to get reference to the asset
					_instance = (ActorAttributesAsset)GameGlobal.Instance.GetAsset<ActorAttributesAsset>();					
					// create a fake if no real asset exist
					if (_instance == null) _instance = ScriptableObject.CreateInstance<ActorAttributesAsset>();
				}
				return _instance;
			}
		}
		private static ActorAttributesAsset _instance;

		/// <summary> Get an attribute definition by its Id. Return null if Id is invalid or attribute not found. </summary>
		public ActorAttribute GetDefinition(UniqueID id)
		{
			if (id.IsEmpty) return null;
			for (int i = 0; i < attributes.Count; i++)
			{
				if (attributes[i].id == id) return attributes[i];
			}
			return null;
		}

		/// <summary> Get an attribute's index in the attributes list by Id. Return -1 if not found. </summary>
		public int GetDefinitionIdx(UniqueID id)
		{
			if (id.IsEmpty) return -1;
			for (int i = 0; i < attributes.Count; i++)
			{
				if (attributes[i].id == id) return i;
			}
			return -1;
		}

		/// <summary> Return the screen name of an attribute. Return "-invalid-" if not found. </summary>
		public string GetScreenName(UniqueID id)
		{
			if (id.IsEmpty) return "-invalid-";
			for (int i = 0; i < attributes.Count; i++)
			{
				if (attributes[i].id == id) return attributes[i].def.screenName;
			}
			return "-invalid-";
		}

		/// <summary> Returns a list of names of all defined attributes. </summary>
		public string[] GetNames()
		{
			string[] n = new string[attributes.Count];
			for (int i = 0; i < n.Length; i++) n[i] = attributes[i].def.screenName;
			return n;
		}

		// ============================================================================================================
	}
}