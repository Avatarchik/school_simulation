﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> The defined Actor Classes. </summary>
	[System.Serializable]
	public class ActorClassesAsset : ScriptableObject
	{

		[HideInInspector] public List<GameObject> classFabs = new List<GameObject>(); //!< List if Actor Class prefabs

		// ============================================================================================================

		[HideInInspector, System.NonSerialized]
		public List<ActorClass> classes = new List<ActorClass>(0);  //!< List of defined classes. Should call UpdateCache() or UpdateCacheIfNeeded() before using this for first time.

		/// <summary> Provide access to asset at runtime </summary>
		public static ActorClassesAsset Instance
		{
			get
			{
				if (_instance == null)
				{	// try to get reference to the asset
					_instance = (ActorClassesAsset)GameGlobal.Instance.GetAsset<ActorClassesAsset>();
					// create a fake if no real asset exist
					if (_instance == null) _instance = ScriptableObject.CreateInstance<ActorClassesAsset>();
				}
				return _instance;
			}
		}
		private static ActorClassesAsset _instance;

		/// <summary> Used to update the list of defined actor classes from the classFabs list. </summary>
		public void UpdateCacheIfNeeded()
		{
			if (classFabs.Count > classes.Count) UpdateCache();
		}

		/// <summary> Used to update the list of defined actor classes from the classFabs list. </summary>
		public void UpdateCache()
		{
			classes = new List<ActorClass>(classFabs.Count);
			for (int i = 0; i < classFabs.Count; i++)
			{
				classes.Add(classFabs[i].GetComponent<ActorClass>());
			}
		}

		/// <summary> Get Actor Class prefab by its Id. Return null if not found. </summary>
		public GameObject GetPrefab(UniqueID id)
		{
			ActorClass s = GetDefinition(id);
			if (s != null) return s.gameObject;
			return null;
		}

		/// <summary> Get Actor Class definition by its Id. Return null if not found. </summary>
		public ActorClass GetDefinition(UniqueID id)
		{
			if (id.IsEmpty) return null;
			if (classFabs.Count > classes.Count) UpdateCache();
			for (int i = 0; i < classes.Count; i++)
			{
				if (classes[i].id == id) return classes[i];
			}
			return null;
		}

		/// <summary> Get index of Actor Class in the actor classes list by its Id. Return -1 if not found. </summary>
		public int GetDefinitionIdx(UniqueID id)
		{
			if (id.IsEmpty) return -1;
			if (classFabs.Count > classes.Count) UpdateCache();
			for (int i = 0; i < classes.Count; i++)
			{
				if (classes[i].id == id) return i;
			}
			return -1;
		}

		/// <summary> Get the screen name of an actor class. Return "-invalid-" if not found. </summary>
		public string GetScreenName(UniqueID id)
		{
			if (id.IsEmpty) return "-invalid-";
			if (classFabs.Count > classes.Count) UpdateCache();
			for (int i = 0; i < classes.Count; i++)
			{
				if (classes[i].id == id) return classes[i].def.screenName;
			}
			return "-invalid-";
		}

		/// <summary> Returns a list of names of all defined actor classes. </summary>
		public string[] GetNames()
		{
			if (classFabs.Count > classes.Count) UpdateCache();
			string[] n = new string[classes.Count];
			for (int i = 0; i < n.Length; i++) n[i] = classes[i].def.screenName;
			return n;
		}

		// ============================================================================================================
	}
}