﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("plyGame/Objects/Marker")]
	public class Marker : MonoBehaviour
	{
		[HideInInspector] public UniqueID id = new UniqueID();

		public int ident = 0;

		// ============================================================================================================

		protected void Reset()
		{
			id = UniqueID.Create(id);
		}

		// ============================================================================================================
	}
}