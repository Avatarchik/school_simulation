﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[System.Serializable]
	public class SimpleCustomizer_Materials
	{
		public string name;
		public List<Material> materials = new List<Material>();
		public int depth = 1;
	}

	[System.Serializable]
	public class SimpleCustomizer_Colors
	{
		public string name;
		public List<Color> colors = new List<Color>();
		public int depth = 1;
	}

	[System.Serializable]
	public class SimpleCustomizer_Textures
	{
		public string name;
		public List<Texture2D> textures = new List<Texture2D>();
		public int depth = 1;
	}

	[System.Serializable]
	public class SimpleCustomizer_ObjectGroup
	{
		public string name;
		public List<GameObject> objects = new List<GameObject>();
	}

	/// <summary> This component makes it easier to manipulate the used material, colour and
	/// the enabled objects of a parent object. Useful for simple character customization.
	/// 
	/// For materials, colours and textures the group name should start with the same name
	/// as the objects that should be affected. So if you wanted to change the Face of a
	/// character by changing the materials on an object named FaceArt then you could name
	/// the group "Face" or "FaceArt".
	/// 
	/// The objects group work different and will simply disable all objects in the same group
	/// except for the one you set to be active when making a call to ChangeObject.
	/// </summary>
	[AddComponentMenu("plyGame/Systems/Simple Customizer")]
	public class SimpleCustomizer : MonoBehaviour
	{

		/// <summary> List of Material groups </summary>
		public List<SimpleCustomizer_Materials> matGroups = new List<SimpleCustomizer_Materials>();

		/// <summary> List of Colour groups </summary>
		public List<SimpleCustomizer_Colors> colGroups = new List<SimpleCustomizer_Colors>();

		/// <summary> List of Texture groups </summary>
		public List<SimpleCustomizer_Textures> texGroups = new List<SimpleCustomizer_Textures>();

		/// <summary> List of Object groups </summary>
		public List<SimpleCustomizer_ObjectGroup> objGroups = new List<SimpleCustomizer_ObjectGroup>();

		// ============================================================================================================

		public class Settings
		{
			public int type = 0; // 0: obj, 1:mat, 2:tex, 3:col
			public int group = 0;
			public int idx = 0;
		}

		private List<Settings> settings = new List<Settings>();
		private bool isPrefabInstance = true;

		// ============================================================================================================

		protected void Awake()
		{
		}

		protected void Start()
		{
			isPrefabInstance = false;

			// run through the settings and apply them in case they
			// where set when this object was instantiated
			for (int i = 0; i < settings.Count; i++)
			{
				switch (settings[i].type)
				{
					case 0: ChangeObject(settings[i].group, settings[i].idx); break;
					case 1: ChangeMaterial(settings[i].group, settings[i].idx); break;
					case 2: ChangeTexture(settings[i].group, settings[i].idx); break;
					case 3: ChangeColor(settings[i].group, settings[i].idx); break;
				}
			}
		}

		/// <summary> You need to call this with the data from the prefab's settings
		/// if calls where made on the prefab's ChangeObject, ChangeMaterial, etc
		/// </summary>
		public void UseSettings(List<Settings> s)
		{
			settings = new List<Settings>(s.Count);
			settings.AddRange(s);
		}

		/// <summary> Return the settings of this customizer. Settings tells what
		/// objects, material, etc should be applied. It records the calls to 
		/// ChangeObject, ChangeMaterial, etc to create these settings </summary>
		public List<Settings> GetSettings()
		{
			return settings;
		}

		// ============================================================================================================

		/// <summary> Return the index of the given group name. -1 if not found. </summary>
		public int GetMaterialGroup(string name)
		{
			for (int i = 0; i < matGroups.Count; i++)
			{
				if (matGroups[i].name.Equals(name)) return i;
			}
			return -1;
		}

		/// <summary> Return the index of the given group name. -1 if not found. </summary>
		public int GetTextureGroup(string name)
		{
			for (int i = 0; i < texGroups.Count; i++)
			{
				if (texGroups[i].name.Equals(name)) return i;
			}
			return -1;
		}

		/// <summary> Return the index of the given group name. -1 if not found. </summary>
		public int GetColorGroup(string name)
		{
			for (int i = 0; i < colGroups.Count; i++)
			{
				if (colGroups[i].name.Equals(name)) return i;
			}
			return -1;
		}

		/// <summary> Return the index of the given group name. -1 if not found. </summary>
		public int GetObjectGroup(string name)
		{
			for (int i = 0; i < objGroups.Count; i++)
			{
				if (objGroups[i].name.Equals(name)) return i;
			}
			return -1;
		}

		// ============================================================================================================

		/// <summary> Change to one at idx to be active in the given group. </summary>
		public bool ChangeObject(int group, int idx)
		{
			if (group < 0 || group >= objGroups.Count)
			{
				Debug.LogError("[SimpleCustomizer] The object group index is invalid: " + group);
				return false;
			}

			if (idx < 0 || idx >= objGroups[group].objects.Count)
			{
				Debug.LogError("[SimpleCustomizer] The object index is invalid: " + idx + ", for group: " + group);
				return false;
			}

			if (false == isPrefabInstance)
			{
				for (int i = 0; i < objGroups[group].objects.Count; i++)
				{
					if (objGroups[group].objects[i] == null) continue;
					objGroups[group].objects[i].SetActive(i == idx);
				}
			}

			UpdateSetting(0, group, idx);
			return true;
		}

		/// <summary> Change to one at idx to be active in the given group. </summary>
		public bool ChangeMaterial(int group, int idx)
		{
			if (group < 0 || group >= matGroups.Count)
			{
				Debug.LogError("[SimpleCustomizer] The material group index is invalid: " + group);
				return false;
			}

			if (idx < 0 || idx >= matGroups[group].materials.Count)
			{
				Debug.LogError("[SimpleCustomizer] The material index is invalid: " + idx + ", for group: " + group);
				return false;
			}

			if (matGroups[group].materials[idx] == null)
			{
				Debug.LogError("[SimpleCustomizer] The material at " + idx + ", for group: " + group + ", is null.");
				return false;
			}

			if (false == isPrefabInstance)
			{
				if (matGroups[group].depth < 1) matGroups[group].depth = 1;
				ChangeMat(matGroups[group].name, matGroups[group].materials[idx], transform, matGroups[group].depth, 0);
			}

			UpdateSetting(1, group, idx);
			return true;
		}

		private void ChangeMat(string name, Material mat, Transform parent, int maxDepth, int depth)
		{
			depth++;
			for (int i = 0; i < parent.childCount; i++)
			{
				Transform tr = parent.GetChild(i);
				if (tr.renderer && tr.name.StartsWith(name))
				{
					tr.renderer.material = mat;
				}
				if (depth < maxDepth) ChangeMat(name, mat, tr, maxDepth, depth);
			}
		}

		/// <summary> Change to one at idx to be active in the given group. </summary>
		public bool ChangeTexture(int group, int idx)
		{
			if (group < 0 || group >= texGroups.Count)
			{
				Debug.LogError("[SimpleCustomizer] The texture group index is invalid: " + group);
				return false;
			}

			if (idx < 0 || idx >= texGroups[group].textures.Count)
			{
				Debug.LogError("[SimpleCustomizer] The texture index is invalid: " + idx + ", for group: " + group);
				return false;
			}

			if (texGroups[group].textures[idx] == null)
			{
				Debug.LogError("[SimpleCustomizer] The texture at " + idx + ", for group: " + group + ", is null.");
				return false;
			}

			if (false == isPrefabInstance)
			{
				if (texGroups[group].depth < 1) texGroups[group].depth = 1;
				ChangeTex(texGroups[group].name, texGroups[group].textures[idx], transform, texGroups[group].depth, 0);
			}

			UpdateSetting(2, group, idx);
			return true;
		}

		private void ChangeTex(string name, Texture2D tex, Transform parent, int maxDepth, int depth)
		{
			depth++;
			for (int i = 0; i < parent.childCount; i++)
			{
				Transform tr = parent.GetChild(i);
				if (tr.renderer && tr.name.StartsWith(name))
				{
					tr.renderer.material.mainTexture = tex;
				}
				if (depth < maxDepth) ChangeTex(name, tex, tr, maxDepth, depth);
			}
		}

		/// <summary> Change to one at idx to be active in the given group. </summary>
		public bool ChangeColor(int group, int idx)
		{
			if (group < 0 || group >= colGroups.Count)
			{
				Debug.LogError("[SimpleCustomizer] The colour group index is invalid: " + group);
				return false;
			}

			if (idx < 0 || idx >= colGroups[group].colors.Count)
			{
				Debug.LogError("[SimpleCustomizer] The colour index is invalid: " + idx + ", for group: " + group);
				return false;
			}

			if (colGroups[group].colors[idx] == null)
			{
				Debug.LogError("[SimpleCustomizer] The colour at " + idx + ", for group: " + group + ", is null.");
				return false;
			}

			if (false == isPrefabInstance)
			{
				if (colGroups[group].depth < 1) colGroups[group].depth = 1;
				ChangeCol(colGroups[group].name, colGroups[group].colors[idx], transform, colGroups[group].depth, 0);
			}

			UpdateSetting(3, group, idx);
			return true;
		}

		private void ChangeCol(string name, Color col, Transform parent, int maxDepth, int depth)
		{
			depth++;
			for (int i = 0; i < parent.childCount; i++)
			{
				Transform tr = parent.GetChild(i);
				if (tr.renderer && tr.name.StartsWith(name))
				{
					tr.renderer.material.color = col;
				}
				if (depth < maxDepth) ChangeCol(name, col, tr, maxDepth, depth);
			}
		}

		private void UpdateSetting(int type, int group, int idx)
		{
			for (int i = 0; i < settings.Count; i++)
			{
				if (settings[i].type == type)
				{
					if (settings[i].group == group)
					{
						settings[i].idx = idx;
						return;
					}
				}
			}

			settings.Add(new Settings() { type = type, group = group, idx = idx });
		}

		// ============================================================================================================
	}
}
