﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[AddComponentMenu("")]
	public class plyItem : Targetable
	{


		// ============================================================================================================

		protected void Reset()
		{
			Setup();
		}

		protected void Awake()
		{
			GameGlobal.Create();
			Setup();
		}

		private void Setup()
		{
			gameObject.layer = GameGlobal.LayerMapping.plyItem;

		}

		// ============================================================================================================

		public override Type TargetableType()
		{
			return Type.Item;
		}

		// ============================================================================================================
	}
}