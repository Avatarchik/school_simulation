﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("")]
	public class ItemInScene : InteractObject
	{
		public Item owner { get; set; }

		// ============================================================================================================

		new protected void Awake()
		{
			gameObject.layer = GameGlobal.LayerMapping.plyItem;
		}
		
		public override Type TargetableType()
		{
			return Type.Item;
		}

		public override bool MustFaceToInteract()
		{
			return false;
		}

		public override object DataObject()
		{
			// owner carries the common data. the object this component is on now
			// is just helper - the item art used when item is laying in scene
			return owner;
		}

		protected void OnInteract(CharacterControllerBase chara)
		{
			owner.PerformPickup();
		}



//		private Item it;
//		private float pickDist = 0.0f;
//		private float distanceCheckTime = 0.0f;

//		private bool persistenceOn = true;
//		private PersistableObject persistObj;
//		private bool isRuntimeItem = false;

//		// ============================================================================================================

//		/// <summary> Create Item in scene </summary>
//		public static ItemInScene Create(Item item, Vector3 pos, Quaternion rot, UniqueID withSaveKey)
//		{
//			GameObject newObj = item.floorArtPrefab == null ? new GameObject(item.def.screenName) : (GameObject)Object.Instantiate(item.floorArtPrefab);

//			newObj.name = item.def.screenName;
//			newObj.transform.position = pos;
//			newObj.transform.rotation = rot;

//			GameObject parent = GameObject.Find("Items");
//			if (!parent) parent = new GameObject("Items");
//			newObj.transform.parent = parent.transform;

//			ItemInScene its = newObj.AddComponent<ItemInScene>();
//			its.itemID = item.id.Copy();

//			PersistableObject p = newObj.AddComponent<PersistableObject>();
//			p.id = withSaveKey == null ? UniqueID.Create() : withSaveKey.Copy();
//			p.objectStartsActive = true;
//			p.persistBloxLocalVars = false;
//			p.persistPosition = false;
//			p.persistRotation = false;
//			p.persistScale = false;
//			p.persistActiveState = false;
//			p.persistDestroyedState = true;

//			if (Application.isPlaying)
//			{	// this is when the item is dropped in the scene at runtime
//				// needed so that the item can be restored after scene changes
//				GameGlobal.AddCreateLoadKey(typeof(ItemInScene), p.id.ToString());
//				its.isRuntimeItem = true;
//			}

//			return its;
//		}

//		new protected void Reset()
//		{
//			base.Reset();
//			gameObject.layer = GameGlobal.LayerMapping.plyItem;
//			CheckCollider();
//		}

//		new protected void Awake()
//		{
//			base.Awake();
//			gameObject.layer = GameGlobal.LayerMapping.plyItem;
//			CheckCollider();
//			persistObj = GetComponent<PersistableObject>();
//		}

//		protected void Start()
//		{
//			it = ItemsAsset.Instance.GetDefinition(itemID);
//			if (it == null)
//			{
//				Debug.LogError("Item trying to initialise but no definition for it found: " + gameObject.name);
//				gameObject.SetActive(false);
//				return;
//			}

//			if (it.autoPickupDist > 0.0f)
//			{	// add distance based activation so that object is only active when player close enough
//				pickDist = it.autoPickupDist;
//				DistanceBasedActivation dba = gameObject.AddComponent<DistanceBasedActivation>();
//				dba.inactivePlayerDistance = ItemsAsset.Instance.autoPickItemDisableDistance;
//			}
//			else
//			{	// no need for this to be active if not checking player distance
//				enabled = false;
//			}
//		}

//		public override Type TargetableType()
//		{
//			return Type.Item;
//		}

//		public override object DataObject()
//		{
//			return it;
//		}

//		// ============================================================================================================

//		public static void LoadCreate(string key)
//		{
//			// load the data needed to recreate item
//			string id = GameGlobal.GetStringKey(key + ".it", null);
//			if (string.IsNullOrEmpty(id))
//			{
//				Debug.LogError("Failed to create Item from saved data. The Item's definition ID could not be read.");
//				return;
//			}

//			Item it = ItemsAsset.Instance.GetDefinition(new UniqueID(id));
//			if (it == null)
//			{
//				Debug.LogError("Failed to find the Item definition from provided ID: " + id);
//				return;
//			}

//			Create(it, Vector3.zero, Quaternion.identity, new UniqueID(key));
//		}

//		public void Save(string key)
//		{
//			if (!persistenceOn) return;
//			GameGlobal.SetStringKey(key + ".it", itemID.ToString());
//		}

//		public void Load(string key)
//		{
//			if (!persistenceOn) return;
//			// ...
//		}

//		public void DeleteSaveData(string key)
//		{
//			if (!persistenceOn) return;
//			GameGlobal.DeleteKey(key + ".it");
//			GameGlobal.RemoveCreateLoadKey(typeof(ItemInScene), key);

//			// no need to save destroyed state if was placed at runtime
//			if (isRuntimeItem) GameGlobal.DeleteKey(key + ".destroyed");
//		}

//		public void DisablePersistence()
//		{
//			persistenceOn = false;
//		}

//		// ============================================================================================================

//		private void CheckCollider()
//		{
//			Collider c = gameObject.GetComponent<Collider>();
//			if (c == null)
//			{
//				c = gameObject.AddComponent<BoxCollider>();
//				(c as BoxCollider).size += new Vector3(0.5f, 0.5f, 0.5f);
//			}
//			c.isTrigger = true;
//		}

//		protected void LateUpdate()
//		{
//			if (it == null) { enabled = false; return; }
//			if (Time.time > distanceCheckTime)
//			{
//				if (pickDist <= 0.0f) { enabled = false; return; }
//				if (Player.Instance == null) return;

//				// check if player close enough for auto-pickup to work
//				if (Vector3.Distance(Player.Instance.transform.position, transform.position) <= pickDist)
//				{
//					enabled = false;
//					pickDist = 0.0f; // if failed to "pick" then will not attempt again
//					PerformPickup();
//				}

//				distanceCheckTime = Time.time + 0.2f;
//			}
//		}

//		protected void OnInteract(CharacterControllerBase chara)
//		{
//			PerformPickup();
//		}

//		private void PerformPickup()
//		{
//			if (Player.Instance.actor.bag == null)
//			{
//				// no point in going on if payer does not even have a bag
//				Debug.LogError("Item pickup can only be performed if the player object has an ItemBag component on it.");
//				return;
//			}

//			bool done = false;

//			if (it.isCurrency)
//			{
//				Player.Instance.actor.bag.AddCurrency(Random.Range(it.minCurrency, it.maxCurrency));
//				done = true;
//			}
//			else
//			{
//				done = Player.Instance.actor.bag.AddItemToBag(it);
//			}

//			if (done)
//			{	// item was picked up. simply destroy it
//				Destroy(gameObject);
//			}
//		}

		// ============================================================================================================
	}
}
