﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	//The default Third Person player camera. 
	[AddComponentMenu("plyGame/Camera/Third Person Camera")]
	public class ThirdPersonCamera : MonoBehaviour
	{
		public CharacterControllerBase targetCharacter;
		public Camera targetCamera;									// The camera to control
		public Vector3 targetOffset = new Vector3(0f, 1.7f, 0f);	// Target Offset to look at from target object's pivot
		public LayerMask obstacleLayers = (1 << GameGlobal.LayerMapping.Floor) | (1 << GameGlobal.LayerMapping.Wall); // Which layers should count as obstructing the view and is ground? The target object's collider(s) should not be in any of these layers.

		public float rotationSpeed = 0.3f;			// Horizontal rotation speed
		public float tiltSpeed = 0.3f;				// Vertical rotation speed
		public float followDamping = 0.1f;			// How fast the camera catches up with the target's position changes
		public float forwardSnapSpeed = 10.0f;		// How fast the camera snap to target object's forward vector when target moves
		public float maxTiltAngle = 45.0f;			// When the cam is tilted down and becomes grounded it will move towards the target and start looking up from the ground. This determine that max up angle.
		public float minZoomDistance = 1f;			// How close to target the cam can come
		public float maxZoomDistance = 10.0f;		// How far out from the target the cam can be zoomed
		public float zoomSpeed = 1.0f;				// How fast zooming happens
		public float zoomSmoothing = 10.0f;			// How smooth/ fast camera respond to changes in its distance from target object

		public bool requireCursorLock = true;		// Turn this off if the camera should be controllable even without cursor lock
		public bool controlCursorLock = true;		// Turn this off if you want mouse lock controlled elsewhere (for example via a key bind that show or hide the mouse cursor)

		public float gamepadRotateMulti = 0.3f;		// Multiplier applied to rotationUpdateSpeed & lookUpSpeed when using gamepad
		public float gamepadTiltMulti = 0.3f;
		public float gamepadZoomMulti = 0.03f;		// Multiplier applied to zoomSpeed when using gamepad

		// ============================================================================================================

		private Transform camTr;
		private Collider targetCollider;
		private Transform targetObject; // transform of target character

		//private const float movementThreshold = 0.1f;	// These helps when detecting if there was enough
		//private const float rotationThreshold = 0.1f;	// change to warrant updates in the camera

		private Vector3 targetPosition;
		private Vector3 posSmooth;
		private Vector3 posVelocity = Vector3.zero;

		//private Vector3 lastStationaryPosition;
		//private Vector3 movement;

		private float optimalDistance;
		private float targetDistance;
		private float distanceSmooth;

		private float rotationAmount;
		private float zAxis;
		private float hAxis;
		private float vAxis;
		private Vector3 inverseLineOfSight;
		private RaycastHit hit;
		private Vector3 cameraForward;
		private float forwardAngle;
		private bool lookFromBelow;
		private Vector2 planeForward;
		private float fieldOfViewRadius;
		private float doubleCharacterRadius;

		private int Key_HoldToRotate = -1;
		private int Key_RotateAxis = -1;
		private int Key_HoldToTilt = -1;
		private int Key_TiltAxis = -1;
		private int Key_Zoom = -1;
		private int Key_GamepadRotate = -1;
		private int Key_GamepadTilt = -1;
		private int Key_GamepadZoom = -1;
		private int Key_GamepadCharacterTurn = -1;

		// ============================================================================================================

		protected void Reset()
		{
			obstacleLayers = (1 << GameGlobal.LayerMapping.Floor) | (1 << GameGlobal.LayerMapping.Wall);
			if (targetCharacter == null) targetCharacter = GetComponent<CharacterControllerBase>();
			if (targetCamera == null) targetCamera = Camera.main;
		}

		protected void Awake()
		{
			GameGlobal.Create(); // make sure global is available, in case user is running scene via Unity play button.

			if (targetCharacter == null) targetCharacter = GetComponent<CharacterControllerBase>();
			if (targetCamera == null) targetCamera = Camera.main;

			if (targetCharacter == null)
			{
				Debug.LogError("[Third Person Camera] No target character assigned.");
				enabled = false;
				return;
			}

			if (targetCamera == null)
			{
				Debug.LogError("[Third Person Camera] No target camera assigned.");
				enabled = false;
				return;
			}

			targetObject = targetCharacter.transform;
			Player.Camera = targetCamera;
			camTr = targetCamera.transform;
		}

		protected void Start()
		{
			if (obstacleLayers != 0)
			{
				targetCollider = targetObject.GetComponent<Collider>();
				if (targetCollider == null)
				{
					obstacleLayers = 0;
					Debug.LogWarning("[Third Person Camera] Target object has no collider. Camera will ignore obstacle collision.");
				}
			}

			targetPosition = posSmooth = targetObject.position;
			//lastStationaryPosition = targetPosition;
			//smoothedDistance = targetDistance = optimalDistance = (camTr.position - targetObject.position).magnitude;
			distanceSmooth = targetDistance = optimalDistance = Mathf.Clamp(minZoomDistance + (maxZoomDistance - minZoomDistance) / 2f, minZoomDistance, maxZoomDistance);
			targetPosition += targetObject.right * targetOffset.x + targetObject.up * targetOffset.y + targetObject.forward * targetOffset.z;

			camTr.forward = targetCharacter.transform.forward;
			camTr.position = targetPosition - (camTr.forward * distanceSmooth); // start camera at the target so it do not fly in from 0x0x0
			camTr.LookAt(targetPosition);

			// Cache the input bind indexes
			Key_HoldToRotate = plyInput.GetInputIdx("Camera 3rd Person/Hold to Rotate");
			Key_RotateAxis = plyInput.GetInputIdx("Camera 3rd Person/Rotate Axis");
			Key_HoldToTilt = plyInput.GetInputIdx("Camera 3rd Person/Hold to Tilt");
			Key_TiltAxis = plyInput.GetInputIdx("Camera 3rd Person/Tilt Axis");
			Key_Zoom = plyInput.GetInputIdx("Camera 3rd Person/Zoom");
			Key_GamepadRotate = plyInput.GetInputIdx("Camera 3rd Person/GamepadRotateCam");
			Key_GamepadTilt = plyInput.GetInputIdx("Camera 3rd Person/GamepadTiltCam");
			Key_GamepadZoom = plyInput.GetInputIdx("Camera 3rd Person/GamepadZoomCam");
			Key_GamepadCharacterTurn = plyInput.GetInputIdx("Camera 3rd Person/GamepadCharacterTurn");
		}

		protected void OnEnable()
		{
			targetPosition = targetObject.position + targetObject.right * targetOffset.x + targetObject.up * targetOffset.y + targetObject.forward * targetOffset.z;
			camTr.position = targetPosition;
		}

		protected void OnDestroy()
		{
			Player.Camera = null;
		}

		protected void FixedUpdate()
		{
			if (GameGlobal.Paused) return;

			targetPosition = targetObject.position + targetObject.right * targetOffset.x + targetObject.up * targetOffset.y + targetObject.forward * targetOffset.z;

			// Cast a sphere from the target towards the camera - using the view radius - checking against the obstacle layers
			if (obstacleLayers != 0)
			{
				inverseLineOfSight = camTr.position - targetPosition;
				if (Physics.SphereCast(targetPosition, ViewRadius, inverseLineOfSight, out hit, optimalDistance, obstacleLayers))
				{	// If something is hit, set the target distance to the hit position
					targetDistance = Mathf.Min((hit.point - targetPosition).magnitude, optimalDistance);
				}
				else
				{	// If nothing is hit, target the optimal distance
					targetDistance = optimalDistance;
				}
			}
			else
			{
				targetDistance = optimalDistance;
			}
		}

		protected void Update()
		{
			if (GameGlobal.Paused) return;
			if (targetCharacter.controlEnabled)
			{	// only allow cam input if character control enabled
				zAxis = plyInput.GetAxis(Key_GamepadZoom);
				if (zAxis != 0.0f) zAxis *= gamepadZoomMulti;
				else zAxis = plyInput.GetAxis(Key_Zoom);
				if (zAxis != 0.0f)
				{
					optimalDistance = Mathf.Clamp(optimalDistance + zAxis * -zoomSpeed, minZoomDistance, maxZoomDistance);
				}
			}
		}

		protected void LateUpdate()
		{
			if (GameGlobal.Paused) return;
			
			PositionUpdate();

			if (targetCharacter.controlEnabled)
			{	// only allow cam input if character control enabled

				if ((plyInput.GetButton(Key_HoldToRotate) || plyInput.GetButton(Key_HoldToTilt)) && (!requireCursorLock || controlCursorLock || Screen.lockCursor))
				{
					if (controlCursorLock) Screen.lockCursor = true;
					FreeUpdate();
					//lastStationaryPosition = targetObject.position;
				}
				else if (false == GamepadUpdate())
				{
					if (controlCursorLock) Screen.lockCursor = false;
					//movement = targetObject.position - lastStationaryPosition;
					//if (new Vector2(movement.x, movement.z).magnitude > movementThreshold)
					//{	// Only bother with update if target moved enough
					FollowUpdate();
					//}
				}
			}
			else
			{	// let the camera follow update when chara control disabled so that it can follow if chara auto moving
				if (controlCursorLock) Screen.lockCursor = false;
				FollowUpdate();
			}
		}

		private void PositionUpdate()
		{
			targetPosition = targetObject.position + targetObject.right * targetOffset.x + targetObject.up * targetOffset.y + targetObject.forward * targetOffset.z;
			//posSmooth = Vector3.Lerp(posSmooth, targetObject.position + targetOffset, Time.deltaTime * followDamping);
			posSmooth = Vector3.SmoothDamp(posSmooth, targetPosition, ref posVelocity, followDamping);
			distanceSmooth = Mathf.Lerp(distanceSmooth, targetDistance, Time.deltaTime * zoomSmoothing);
			camTr.position = posSmooth + camTr.rotation * new Vector3(0f, 0f, -distanceSmooth);
		}

		private void FollowUpdate()
		{
			cameraForward = posSmooth - camTr.position;
			cameraForward.y = 0.0f;

			rotationAmount = Vector3.Angle(cameraForward, targetObject.forward);
			//if (rotationAmount < rotationThreshold) lastStationaryPosition = targetObject.position;

			rotationAmount *= forwardSnapSpeed * Time.deltaTime;
			if (Vector3.Angle(cameraForward, targetObject.right) < Vector3.Angle(cameraForward, targetObject.right * -1.0f))
			{
				rotationAmount *= -1.0f;
			}

			camTr.RotateAround(posSmooth, Vector3.up, rotationAmount);
		}

		private void FreeUpdate()
		{
			// *** Horizontal

			if (plyInput.GetButton(Key_HoldToRotate))
			{
				// Else rotate around target on horizontal
				rotationAmount = plyInput.GetAxis(Key_RotateAxis) * rotationSpeed;
				camTr.RotateAround(posSmooth, Vector3.up, rotationAmount);
			}
			else
			{	// need to rotate to face in player direction
				FollowUpdate();
			}

			// *** Vertical

			if (plyInput.GetButton(Key_HoldToTilt))
			{
				rotationAmount = plyInput.GetAxis(Key_TiltAxis) * -tiltSpeed;

				// Camera looking at target?
				lookFromBelow = Vector3.Angle(camTr.forward, targetObject.up * -1) > Vector3.Angle(camTr.forward, targetObject.up);

				// Rotate around and look at target position
				camTr.RotateAround(posSmooth, camTr.right, rotationAmount);
				camTr.LookAt(posSmooth);

				// Get the new rotation relative to the target forward vector
				forwardAngle = Vector3.Angle(targetObject.forward, SnappedCameraForward);

				// If the new rotation brought the camera over the clamp max, rotate it back by the difference
				if (forwardAngle > maxTiltAngle)
				{
					camTr.RotateAround(posSmooth, camTr.right, lookFromBelow ? forwardAngle - maxTiltAngle : maxTiltAngle - forwardAngle);
				}
			}

			//// *** Horizontal

			//if (plyInput.GetButton(Key_HoldToTilt))
			//{
			//	// Horizontal is handled by controller rotating the character when right-mouse held
			//	FollowUpdate();
			//}
			//else
			//{
			//	// Else rotate around target on horizontal
			//	rotationAmount = plyInput.GetAxis(Key_RotateAxis) * rotationSpeed;
			//	camTr.RotateAround(posSmooth, Vector3.up, rotationAmount);
			//}

			//// *** Vertical

			//rotationAmount = plyInput.GetAxis(Key_TiltAxis) * -tiltSpeed;

			//// Camera looking at target?
			//lookFromBelow = Vector3.Angle(camTr.forward, targetObject.up * -1) > Vector3.Angle(camTr.forward, targetObject.up);

			//// Rotate around and look at target position
			//camTr.RotateAround(posSmooth, camTr.right, rotationAmount);
			//camTr.LookAt(posSmooth);

			//// Get the new rotation relative to the target forward vector
			//forwardAngle = Vector3.Angle(targetObject.forward, SnappedCameraForward);

			//// If the new rotation brought the camera over the clamp max, rotate it back by the difference
			//if (forwardAngle > maxTiltAngle)
			//{
			//	camTr.RotateAround(posSmooth, camTr.right, lookFromBelow ? forwardAngle - maxTiltAngle : maxTiltAngle - forwardAngle);
			//}
		}

		private bool GamepadUpdate()
		{
			if (false == plyInput.IsActive(Key_GamepadRotate) && false == plyInput.IsActive(Key_GamepadTilt)) return false;

			bool ret = false;
			hAxis = plyInput.GetAxis(Key_GamepadRotate);
			vAxis = plyInput.GetAxis(Key_GamepadTilt);

			// *** Horizontal
			if (hAxis <= -0.1f || hAxis >= 0.1f)
			{
				ret = true;
				if (plyInput.SimilarBinds(Key_GamepadRotate, Key_GamepadCharacterTurn))
				{
					FollowUpdate();
				}
				else
				{
					rotationAmount = hAxis * rotationSpeed * gamepadRotateMulti;
					camTr.RotateAround(posSmooth, Vector3.up, rotationAmount);
				}
			}

			// *** Vertical
			if (vAxis <= -0.1f || vAxis >= 0.1f)
			{
				ret = true;
				rotationAmount = vAxis * -1.0f * tiltSpeed * gamepadTiltMulti;

				// Camera looking at target?
				lookFromBelow = Vector3.Angle(camTr.forward, targetObject.up * -1) > Vector3.Angle(camTr.forward, targetObject.up);

				// Rotate around and look at target position
				camTr.RotateAround(posSmooth, camTr.right, rotationAmount);
				camTr.LookAt(posSmooth);

				// Get the new rotation relative to the target forward vector
				forwardAngle = Vector3.Angle(targetObject.forward, SnappedCameraForward);

				// If the new rotation brought the camera over the clamp max, rotate it back by the difference
				if (forwardAngle > maxTiltAngle)
				{
					camTr.RotateAround(posSmooth, camTr.right, lookFromBelow ? forwardAngle - maxTiltAngle : maxTiltAngle - forwardAngle);
				}
			}

			return ret;
		}

		private float ViewRadius
		{
			get
			{
				// The minimum clear radius between the camera and the target
				// Half the width of the field of view of the camera at the position of the target
				fieldOfViewRadius = (optimalDistance / Mathf.Sin(90.0f - targetCamera.fieldOfView / 2.0f)) * Mathf.Sin(targetCamera.fieldOfView / 2.0f);
				doubleCharacterRadius = Mathf.Max(targetCollider.bounds.extents.x, targetCollider.bounds.extents.z);// *2.0f;
				return Mathf.Min(doubleCharacterRadius, fieldOfViewRadius);
			}
		}

		private Vector3 SnappedCameraForward
		{
			get
			{
				// The camera forward vector, clamped to the target forward vector so only horizontal rotation is kept
				planeForward = new Vector2(camTr.forward.x, camTr.forward.z);
				planeForward = new Vector2(targetObject.forward.x, targetObject.forward.z).normalized * planeForward.magnitude;
				return new Vector3(planeForward.x, camTr.forward.y, planeForward.y);
			}
		}

		// ============================================================================================================
	}
}
