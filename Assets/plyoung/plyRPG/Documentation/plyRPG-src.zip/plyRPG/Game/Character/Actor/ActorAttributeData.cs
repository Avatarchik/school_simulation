﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> Data related to an Actor Attribute. </summary>
	[System.Serializable]
	public class ActorAttributeData
	{
		[HideInInspector] public UniqueID id;				//!< Id of the Attribute represented by this Data
		public int baseValue = 5;							//!< What the base value must be inited with
		public int maxValue = 999;							//!< The absolute max the attribute's 'value' can ever reach

		public bool canGrow = false;						//!< Can the attribute's value grow with the level?
		public plyCurve growthCurve = new plyCurve(0, 0, 0);//!< How doe sis grow?
		public bool alsoUpdateConsumable = true;			//!< Set to true to also have the consumable value restore to what the Value will be. This is normally done to restore the character's health, mana, etc to the max when the character level up.

		public string nameCache { get; set; } // only used by editor

		// ============================================================================================================

		public override string ToString()
		{
			return nameCache;
		}

		public ActorAttributeData Copy()
		{
			ActorAttributeData obj = new ActorAttributeData();
			this.CopyTo(obj);
			return obj;
		}

		public void CopyTo(ActorAttributeData o)
		{
			o.id = this.id.Copy();
			o.baseValue = this.baseValue;
			o.maxValue = this.maxValue;

			o.canGrow = this.canGrow;
			o.growthCurve = new plyCurve(this.growthCurve);

			o.nameCache = this.nameCache;
		}

		// ============================================================================================================
	}
}