﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	/// <summary> Contains the info for a character that can be created by the player manager. </summary>
	[System.Serializable]
	public class PlayerManagerCharacterData
	{
		/// <summary> The character object (actor) with all its needed player related components. 
		/// This is an 'empty' object into which one of the artPrefabs will be placed when the
		/// character is instantiated. </summary>
		[SerializeField] public GameObject characterPrefab;

		/// <summary> The possible objects/ prefabs that can be used for the art side of the character. </summary>
		[SerializeField] public List<GameObject> artPrefabs = new List<GameObject>();

		//[SerializeField] public plyMetaData[] metaData = new plyMetaData[0];
	}

	/// <summary> The player manager is an optional system that can be used when you do not
	/// want to manually take care of player character loading and management </summary>
	[AddComponentMenu("")]
	public class PlayerManager: MonoBehaviour
	{
		/// <summary> The default player prefab is used when the designer uses Unity Play button
		/// to test a scene and also when there are no other player prefabs defined. This is the 
		/// one prefab that should be set if you want the manager active. </summary>
		[HideInInspector] public GameObject defaultPlayerFab;

		/// <summary> List of player character prefabs </summary>
		[HideInInspector] public List<PlayerManagerCharacterData> playerCharacters = new List<PlayerManagerCharacterData>();

		[HideInInspector] public int defaultCharaIdx = -1;
		[HideInInspector] public int defaultCharaArtIdx = -1;

		/// <summary> plyBlox associated with the player manager. </summary>
		[HideInInspector] public plyBlox blox;

		// ============================================================================================================

		/// <summary> Instance is set on Awake. Player Manager is auto-created by plyGame when the
		/// game starts and at least the defaultPlayerFab is set to a valid prefab. </summary>
		public static PlayerManager Instance { get; private set; }

		private int charaToSpawn = -1;
		private int artToUse = -1;
		private EventHandler_PlayerManager eventHandler = null;

		// ============================================================================================================

		protected void Awake()
		{
			Instance = this;
			name = "Player Manager";

			// Normally not a good idea to make calls to GameGlobal in Awake but GameGlobal
			// exist if this manager was auto-created (by GameGlobal).
			GameGlobal.RegisterLoadSaveListener(LS_OnSave, LS_OnLoad, LS_OnDelete, LS_OnCopy);
		}

		protected void Start()
		{
			eventHandler = gameObject.GetComponent<EventHandler_PlayerManager>();
		}

		private void LS_OnSave(object sender, object[] args)
		{
			string key = ((int)args[0]).ToString() + "." + ((int)args[1]).ToString() + ".plrman";
			GameGlobal.Instance.loadSaveProvider.SetInt(key + ".a", charaToSpawn);
			GameGlobal.Instance.loadSaveProvider.SetInt(key + ".b", artToUse);
		}

		private void LS_OnLoad(object sender, object[] args)
		{
			string key = ((int)args[0]).ToString() + "." + ((int)args[1]).ToString() + ".plrman";
			charaToSpawn = GameGlobal.Instance.loadSaveProvider.GetInt(key + ".a", charaToSpawn);
			artToUse = GameGlobal.Instance.loadSaveProvider.GetInt(key + ".b", artToUse);
		}

		private void LS_OnDelete(object sender, object[] args)
		{
			string key = ((int)args[0]).ToString() + "." + ((int)args[1]).ToString() + ".plrman";
			GameGlobal.Instance.loadSaveProvider.DeleteKey(key + ".a");
			GameGlobal.Instance.loadSaveProvider.DeleteKey(key + ".b");
		}

		private void LS_OnCopy(object sender, object[] args)
		{
			string loadKey = ((int)args[0]).ToString() + "." + ((int)args[1]).ToString() + ".plrman";
			string saveKey = ((int)args[0]).ToString() + "." + ((int)args[2]).ToString() + ".plrman";
			int a = GameGlobal.Instance.loadSaveProvider.GetInt(loadKey + ".a", -1);
			int b = GameGlobal.Instance.loadSaveProvider.GetInt(loadKey + ".b", -1);
			GameGlobal.Instance.loadSaveProvider.SetInt(saveKey + ".a", a);
			GameGlobal.Instance.loadSaveProvider.SetInt(saveKey + ".b", b);
		}

		// ============================================================================================================

		/// <summary> Instruct the Player Manager to spawn a Player character in the scene. ident is used to 
		/// identify this player character uniquely when you may be using more than one in a game session.
		/// It defaults to "player" if you pass an empty string. This ident is used when saving/ loading the
		/// player data. This call will silently fail if there is already a player character in the scene. 
		/// If targeTr is set then that transform's location and rotation is used to initialise the character's
		/// position and rotation. </summary>
		public void SpawnPlayer(string ident, Transform targetTr)
		{
			GameObject go = null;
			if (Player.Instance == null)
			{
				if (string.IsNullOrEmpty(ident)) ident = "player";

				if (charaToSpawn >= 0)
				{
					if (charaToSpawn < playerCharacters.Count)
					{
						if (playerCharacters[charaToSpawn].characterPrefab != null)
						{
							go = (GameObject)Object.Instantiate(playerCharacters[charaToSpawn].characterPrefab);
							if (artToUse >= 0)
							{
								if (playerCharacters[charaToSpawn].artPrefabs[artToUse] != null)
								{
									GameObject art = (GameObject)Object.Instantiate(playerCharacters[charaToSpawn].artPrefabs[artToUse]);
									art.transform.parent = go.transform;
									art.transform.localPosition = Vector3.zero;
									art.transform.localRotation = Quaternion.identity;
								}
								else
								{
									Debug.LogWarning("[PlayerManager] Failed to instantiate player art. The art prefab at index [" + artToUse + "] is not valid.");
								}
							}
						}
						else
						{
							Debug.LogError("[PlayerManager] Failed to create player. The actor prefab at index [" + charaToSpawn + "] is not valid.");
							return;
						}
					}
					else
					{
						Debug.LogError("[PlayerManager] Failed to create player. The actor prefab at index [" + charaToSpawn + "] is not valid.");
						return;
					}
				}
				else
				{
					if (defaultPlayerFab != null)
					{
						go = (GameObject)Object.Instantiate(defaultPlayerFab);
					}
					else
					{
						if (defaultCharaIdx >= 0 && defaultCharaIdx < playerCharacters.Count)
						{
							if (playerCharacters[defaultCharaIdx].characterPrefab != null)
							{
								go = (GameObject)Object.Instantiate(playerCharacters[defaultCharaIdx].characterPrefab);
								if (defaultCharaArtIdx >= 0 && defaultCharaArtIdx < playerCharacters[defaultCharaIdx].artPrefabs.Count)
								{
									if (playerCharacters[defaultCharaIdx].artPrefabs[defaultCharaArtIdx] != null)
									{
										GameObject art = (GameObject)Object.Instantiate(playerCharacters[defaultCharaIdx].artPrefabs[defaultCharaArtIdx]);
										art.transform.parent = go.transform;
										art.transform.localPosition = Vector3.zero;
										art.transform.localRotation = Quaternion.identity;
									}
									else
									{
										Debug.LogWarning("[PlayerManager] Failed to instantiate player art. The art prefab at index [" + artToUse + "] is not valid.");
									}
								}
							}
						}
					}

					if (go == null)
					{
						Debug.LogError("The Player Manager is not correctly set up. There should be a default player set.");
						return;
					}
				}
			}
			else
			{
				go = Player.Instance.gameObject;
			}

			go.name = "Player";

			if (targetTr != null)
			{
				go.transform.position = targetTr.position;
				go.transform.rotation = targetTr.rotation;
			}
			else
			{
				go.transform.position = new Vector3(0f, 0.1f, 0f);
			}

			PersistableObject p = go.GetComponent<PersistableObject>();
			if (p != null)
			{
				p.UseCustomKey(ident);
				p.persistPosition = GameGlobal.Instance.isSessionRestore; // do not restore position if not proper load but only scene change
			}
			if (eventHandler != null) eventHandler.OnPlayerCreated();
		}

		/// <summary> Instruct the Player Manager to remove the Player character from the scene. </summary>
		public void DestroyPlayer()
		{
			if (Player.Instance == null) return;
			Object.Destroy(Player.Instance.gameObject);
			Player.Instance = null;
			Player.Camera = null;

		}

		/// <summary> Set the active player from the playerCharacters list. </summary>
		public void SetActivePlayer(int idx)
		{
			charaToSpawn = -1;

			if (idx < 0 || idx >= playerCharacters.Count)
			{
				Debug.LogError("[PlayerManager] Setting Active Player not possible. Invalid index: " + idx);
				return;
			}

			charaToSpawn = idx;
		}

		/// <summary> Set the active player art from the playerCharacters list. The active player 
		/// must be set first via SetActivePlayer </summary>
		public void SetActivePlayerArt(int idx)
		{
			artToUse = -1;

			if (charaToSpawn == -1)
			{
				Debug.LogError("[PlayerManager] You first need to set the active player index.");
				return;
			}

			if (idx < 0 || idx >= playerCharacters[charaToSpawn].artPrefabs.Count)
			{
				Debug.LogError("[PlayerManager] Setting player art not possible. Invalid index: " + idx);
				return;
			}

			artToUse = idx;
		}

		/// <summary> Return reference to the Player Prefab from the Player Manager. </summary>
		public GameObject GetPlayerPrefab(int idx)
		{
			if (idx < 0 || idx >= playerCharacters.Count)
			{
				Debug.LogError("[PlayerManager] The Player index is invalid: " + idx);
				return null;
			}

			return playerCharacters[idx].characterPrefab;
		}

		/// <summary> Return reference to the Player Art Prefab from the Player Manager. </summary>
		public GameObject GetPlayerArtPrefab(int plridx, int idx)
		{
			if (plridx < 0 || plridx >= playerCharacters.Count)
			{
				Debug.LogError("[PlayerManager] The Player index is invalid: " + plridx);
				return null;
			}

			if (idx < 0 || idx >= playerCharacters[plridx].artPrefabs.Count)
			{
				Debug.LogError("[PlayerManager] The Art index is invalid: " + idx);
				return null;
			}

			return playerCharacters[plridx].artPrefabs[idx];
		}

		// ============================================================================================================
	}
}
