﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	[AddComponentMenu("plyGame/Character/Animation/Basic Mecanim Control")]
	public class BasicMecanimControl : AnimationControlBase
	{
		// notes:
		// moveSpeed is a multiplier of the root animation so moveSpeed = 1 is normal speed

		public Animator animator;
		public CharacterControllerBase character;

		public string speedParam = "Speed";			// [float] Speed (magnitude of movement vector on XZ)
		public string forwardParam = "Forward";		// [float] Forward/ Backward movement (Z)
		public string leftRightParam = "LeftRight";	// [float] Left/ Right movement (X)
		public string jumpParam = "Jump";			// [float] Up/ Down movement (Y)
		public string groundParam = "Grounded";		// [bool] True while character is touching ground
		public string onDeathParam = "OnDeath";		// [trigger]
		public string deadParam = "Dead";			// [bool]

		// ============================================================================================================

		//private float speed;
		private Vector3 moveInput;
		private Vector3 velocity;
		private Vector3 localMove;

		private float speedAmount;
		private float forwardAmount;
		private float leftRightAmount;
		private bool grounded;

		private Transform _tr;
		private IComparer rayHitComparer;
		private float fallTimer = 0f;
		private float groundCheckRadius = 0.5f;
		
		private int speedHash;
		private int forwardHash;
		private int leftRightHash;
		private int jumpHash;
		private int groundHash;
		private int onDeathHash;
		private int deadHash;

		// ============================================================================================================

		protected void Reset()
		{
			if (animator == null) animator = GetComponentInChildren<Animator>();
			if (character == null) character = GetComponentInChildren<CharacterControllerBase>();
		}

		protected void Awake()
		{
			GameGlobal.Create();
			_tr = transform;
		}

		protected void Start()
		{
			if (animator == null) animator = GetComponentInChildren<Animator>();
			if (character == null) character = GetComponentInChildren<CharacterControllerBase>();

			if (animator == null)
			{
				Debug.LogError("[BasicMecanimControl] No Animator found. Disabling this component.");
				enabled = false;
			}

			if (character == null)
			{
				Debug.LogError("[BasicMecanimControl] No character controller found. Disabling this component");
				enabled = false;
				return;
			}

			rayHitComparer = new plyUtil.RayHitComparer();
			character.onDeath += OnDeath;

			// use avatar from a child animator component if present
			// this is to enable easy swapping of the character model as a child node
			foreach (var childAnimator in GetComponentsInChildren<Animator>()) 
			{
				if (childAnimator != animator) 
				{
					animator.avatar = childAnimator.avatar;
					Destroy(childAnimator);
					break;
				}
			}

			// find a collider to get a radius off of
			CharacterController cc = GetComponent<CharacterController>();
			if (cc != null) groundCheckRadius = cc.radius;
			else
			{
				SphereCollider sc = GetComponent<SphereCollider>();
				if (sc != null) groundCheckRadius = sc.radius;
			}

			speedHash = Animator.StringToHash(speedParam);
			forwardHash = Animator.StringToHash(forwardParam);
			leftRightHash = Animator.StringToHash(leftRightParam);
			jumpHash = Animator.StringToHash(jumpParam);
			groundHash = Animator.StringToHash(groundParam);
			onDeathHash = Animator.StringToHash(onDeathParam);
			deadHash = Animator.StringToHash(deadParam);

			// the following will cause warning messages to be written to the console if a param is not defined
			// it is the best way atm that I can inform the designer that he missed a param
			animator.GetFloat(speedParam);
			animator.GetFloat(forwardParam);
			animator.GetFloat(leftRightParam);
			animator.GetFloat(jumpParam);
			animator.GetBool(groundParam);
			animator.GetBool(deadParam);
			animator.GetBool(onDeathParam);
		}

		// ============================================================================================================

		protected void Update()
		{
			UpdateMoveData();
			ConvertMoveInput();
			GroundCheck();
			UpdateAnimator();
		}

		// ============================================================================================================

		private void UpdateAnimator()
		{
			animator.applyRootMotion = false;

			animator.SetFloat(speedHash, speedAmount);
			animator.SetFloat(forwardHash, forwardAmount, 0.1f, Time.deltaTime);
			animator.SetFloat(leftRightHash, leftRightAmount, 0.1f, Time.deltaTime);
			animator.SetBool(groundHash, grounded);
			if (false == character.Grounded()) animator.SetFloat(jumpHash, velocity.y);
		}

		private void UpdateMoveData()
		{
			grounded = character.Grounded();
			velocity = character.Velocity();
			speedAmount = velocity.magnitude;
			moveInput = character.Movement().normalized;
		}

		private void ConvertMoveInput()
		{
			// convert the world relative moveInput vector into a local-relative turn
			// amount and forward amount required to head in the desired direction.
			localMove = _tr.InverseTransformDirection(velocity);
			forwardAmount = localMove.z;
			leftRightAmount = localMove.x;
		}

		private void GroundCheck()
		{
			if (velocity.y > 0.0f && !grounded)
			{
				fallTimer += Time.deltaTime;
				return;
			}

			Ray ray = new Ray(_tr.position + Vector3.up * groundCheckRadius * 2f, -Vector3.up);
			RaycastHit[] hits = Physics.SphereCastAll(ray, groundCheckRadius, groundCheckRadius * 3f);
			System.Array.Sort(hits, rayHitComparer);

			grounded = false;
			for (int i = 0; i < hits.Length; i++)
			{
				if (hits[i].collider.isTrigger) continue;
				if (hits[i].distance < (groundCheckRadius * 2f)) grounded = true;
				break;
			}

			if (grounded)
			{
				if (fallTimer < 0.5f && velocity.y < 0.0f) velocity.y = 0.0f;
				fallTimer = 0f;
			}
			else
			{
				fallTimer += Time.deltaTime;
			}
		}

		// ============================================================================================================

		public void OnDeath(object npc, object[] args)
		{
			animator.SetBool(deadHash, true);
			animator.SetTrigger(onDeathHash);
		}

		// ============================================================================================================
	}
}