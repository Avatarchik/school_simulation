﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary>
	/// Manages and contains a list of all the Factions. Factions should not be added at runtime.
	/// and must all be defined in the plyGame Main Editor.
	/// This manager will automatically interact with the SaveLoad System to save and restore
	/// the relevant data of factions.
	/// </summary>
	[AddComponentMenu("")]
	public class ActorFactionManager: MonoBehaviour
	{

		[HideInInspector]
		public List<ActorFaction> definedFactions = new List<ActorFaction>();	//!< List of defined factions

		[HideInInspector]
		public List<FactionVarList> varTypes = new List<FactionVarList>();		//!< The variable types use by factions

		[HideInInspector]
		public bool persistVars = true;											//!< should variables be persisted?

		[HideInInspector]
		public plyBlox blox = null;

		// ============================================================================================================

		private List<ActorFaction> factions = new List<ActorFaction>(0); // runtime factions 
		private bool persistenceOn = true;	

		// ============================================================================================================

		private static ActorFactionManager _instance;
		public static ActorFactionManager Instance
		{
			get
			{
				if (_instance == null)
				{	// most likely that no factions where defined so GameGlobal was not requested 
					// to auto-create the factions manager. But now something is looking for
					// a reference to it. Create an object so that there is something.
					Debug.Log("Creating Factions Manager. Note, no factions are defined.");
					GameObject go = new GameObject("Factions Manager");
					Object.DontDestroyOnLoad(go);
					_instance = go.AddComponent<ActorFactionManager>();
					_instance.persistVars = false; // no point in this case
					_instance.persistenceOn = false;
				}

				return _instance;
			}
		}

		// ============================================================================================================

		protected void Reset()
		{
			if (blox == null) blox = gameObject.AddComponent<plyBlox>();
		}

		protected void Awake()
		{
			_instance = this;
			name = "Factions Manager";

			// Normally not a good idea to make calls to GameGlobal in Awake but GameGlobal
			// exist since this manager was auto-created by GameGlobal.
			if (persistenceOn)
			{
				GameGlobal.RegisterLoadSaveListener(LS_OnSave, LS_OnLoad, LS_OnDelete, LS_OnCopy);
			}
		}

		protected void Start()
		{
			// init runtime factions
			// Init makes call to get event handler so this needs to be done
			// in Start() since event handlers are not yet ready during Awake
			factions = new List<ActorFaction>(definedFactions.Count);
			for (int i = 0; i < definedFactions.Count; i++)
			{
				ActorFaction f = definedFactions[i].Copy();
				f.Init(i, blox);
				factions.Add(f);
			}
			factions.TrimExcess();
			definedFactions = null;
		}

		private void LS_OnSave(object sender, object[] args)
		{
			if (!persistenceOn) return;
			string key = ((int)args[0]).ToString() + "." + ((int)args[1]).ToString() + ".faction";
			
			for (int i = 0; i < factions.Count; i++)
			{
				// save status of faction towards other
				string data = "";
				for (int j = 0; j < factions[i].statusTo.Count; j++)
				{
					data += ((int)factions[i].statusTo[j]).ToString() + (char)31;
				}
				GameGlobal.Instance.loadSaveProvider.SetString(key + i + ".st", data);

				// save faction variables
				data = "";
				for (int k = 0; k < factions.Count; k++)
				{
					for (int j = 0; j < factions[i].varListDef.Count; j++)
					{
						string varName = factions[i].varListDef[j].name;
						plyVar vr = factions[i].GetFactionVariable(varName, factions[k]);
						data += EncodeFactionVar(vr) + (char)29;
					}
					data += (char)31;
				}
				GameGlobal.Instance.loadSaveProvider.SetString(key + i + ".vr", data);
			}
		}

		private void LS_OnLoad(object sender, object[] args)
		{
			if (!persistenceOn) return;
			string key = ((int)args[0]).ToString() + "." + ((int)args[1]).ToString() + ".faction";

			for (int i = 0; i < factions.Count; i++)
			{
				// load status of faction towards other
				string data_s = GameGlobal.Instance.loadSaveProvider.GetString(key + i + ".st", "");
				string[] data = data_s.Split((char)31);
				for (int j = 0; j < factions[i].statusTo.Count; j++)
				{
					if (j < data.Length)
					{
						if (string.IsNullOrEmpty(data[j])) continue;
						factions[i].statusTo[j] = (StatusTowardsOther)int.Parse(data[j]);
					}
				}

				// load faction variables
				data_s = GameGlobal.Instance.loadSaveProvider.GetString(key + i + ".vr", "");
				data = data_s.Split((char)31);
				for (int k = 0; k < factions.Count; k++)
				{
					if (k < data.Length)
					{
						if (string.IsNullOrEmpty(data[k])) continue;
						string[] vars = data[k].Split((char)29);
						for (int j = 0; j < factions[i].varListDef.Count; j++)
						{
							if (j < vars.Length)
							{
								if (string.IsNullOrEmpty(vars[j])) continue;
								DecodeAndSetFactionVar(vars[j], factions[i], factions[k]);
							}
						}
					}
				}
				
			}
		}

		private void LS_OnDelete(object sender, object[] args)
		{
			if (!persistenceOn) return;
			string key = ((int)args[0]).ToString() + "." + ((int)args[1]).ToString() + ".faction";

			for (int i = 0; i < factions.Count; i++)
			{
				GameGlobal.Instance.loadSaveProvider.DeleteKey(key + i + ".st");
				GameGlobal.Instance.loadSaveProvider.DeleteKey(key + i + ".vr");
			}
		}

		private void LS_OnCopy(object sender, object[] args)
		{
			string loadKey = ((int)args[0]).ToString() + "." + ((int)args[1]).ToString() + ".faction";
			string saveKey = ((int)args[0]).ToString() + "." + ((int)args[2]).ToString() + ".faction";

			string d = "";
			for (int i = 0; i < factions.Count; i++)
			{
				if (false == GameGlobal.Instance.loadSaveProvider.HasKey(loadKey + i + ".st")) continue;
				d = GameGlobal.Instance.loadSaveProvider.GetString(loadKey + i + ".st", "");
				GameGlobal.Instance.loadSaveProvider.SetString(saveKey + i + ".st", d);

				if (false == GameGlobal.Instance.loadSaveProvider.HasKey(loadKey + i + ".vr")) continue;
				d = GameGlobal.Instance.loadSaveProvider.GetString(loadKey + i + ".vr", "");
				GameGlobal.Instance.loadSaveProvider.SetString(saveKey + i + ".vr", d);
			}
		}

		private string EncodeFactionVar(plyVar v)
		{
			string data = v.name + (char)30;
			switch (v.type)
			{
				case VariableType.Bool:
				{
					data += "0" + (char)30 + (v.boolValue ? "1" : "0");
				} break;
				case VariableType.Int:
				{
					data += "1" + (char)30 + v.intValue;
				} break;
				case VariableType.Float:
				{
					data += "2" + (char)30 + v.floatValue;
				} break;
				case VariableType.String:
				{
					data += "3" + (char)30 + v.stringValue;
				} break;
				case VariableType.Vector2:
				{
					data += "4" + (char)30 + v.vect2Value.x + "|" + v.vect2Value.y;
				} break;
				case VariableType.Vector3:
				{
					data += "5" + (char)30 + v.vect3Value.x + "|" + v.vect3Value.y + "|" + v.vect3Value.z;
				} break;
				case VariableType.Color:
				{
					data += "6" + (char)30 + v.colorValue.r + "|" + v.colorValue.g + "|" + v.colorValue.b + "|" + v.colorValue.a;
				} break;
				case VariableType.Rect:
				{
					data += "7" + (char)30 + v.rectValue.x + "|" + v.rectValue.y + "|" + v.rectValue.width + "|" + v.rectValue.height;
				} break;
			}
			return data;
		}

		private void DecodeAndSetFactionVar(string data, ActorFaction faction, ActorFaction targetFaction)
		{
			string[] v = data.Split((char)30);
			if (v.Length == 3)
			{	// 0:variable_name, 1:value_type, 3:value
				switch (v[1])
				{
					case "0":
					{
						bool val = (v[2] == "1");
						faction.SetFactionVarValue(v[0], val, targetFaction);
					} break;
					case "1":
					{
						int val = int.Parse(v[2]);
						faction.SetFactionVarValue(v[0], val, targetFaction);
					} break;
					case "2":
					{
						float val = float.Parse(v[2]);
						faction.SetFactionVarValue(v[0], val, targetFaction);
					} break;
					case "3":
					{
						faction.SetFactionVarValue(v[0], v[2], targetFaction);
					} break;
					case "4":
					{
						string[] xy = v[2].Split('|');
						Vector2 val = new Vector2(float.Parse(xy[0]), float.Parse(xy[1]));
						faction.SetFactionVarValue(v[0], val, targetFaction);
					} break;
					case "5":
					{
						string[] xyz = v[2].Split('|');
						Vector3 val = new Vector3(float.Parse(xyz[0]), float.Parse(xyz[1]), float.Parse(xyz[2]));
						faction.SetFactionVarValue(v[0], val, targetFaction);
					} break;
					case "6":
					{
						string[] rgba = v[2].Split('|');
						Color val = new Color(float.Parse(rgba[0]), float.Parse(rgba[1]), float.Parse(rgba[2]), float.Parse(rgba[3]));
						faction.SetFactionVarValue(v[0], val, targetFaction);
					} break;
					case "7":
					{
						string[] xywh = v[2].Split('|');
						Rect val = new Rect(float.Parse(xywh[0]), float.Parse(xywh[1]), float.Parse(xywh[2]), float.Parse(xywh[3]));
						faction.SetFactionVarValue(v[0], val, targetFaction);
					} break;
				}
			}
		}

		// ============================================================================================================

		/// <summary> Get a defined faction by an ident. Return null if not found. </summary>
		public ActorFaction GetDefinitionByIdent(string ident, plyGameObjectIdentifyingType identType)
		{
			if (string.IsNullOrEmpty(ident)) return null;
			if (identType == plyGameObjectIdentifyingType.ident)
			{
				for (int i = 0; i < definedFactions.Count; i++) if (definedFactions[i].def.ident.Equals(ident)) return definedFactions[i];
			}
			if (identType == plyGameObjectIdentifyingType.screenName)
			{
				for (int i = 0; i < definedFactions.Count; i++) if (definedFactions[i].def.screenName.Equals(ident)) return definedFactions[i];
			}
			if (identType == plyGameObjectIdentifyingType.shortName)
			{
				for (int i = 0; i < definedFactions.Count; i++) if (definedFactions[i].def.shortName.Equals(ident)) return definedFactions[i];
			}
			if (identType == plyGameObjectIdentifyingType.meta)
			{
				for (int i = 0; i < definedFactions.Count; i++) if (definedFactions[i].def.meta.Equals(ident)) return definedFactions[i];
			}
			return null;
		}

		/// <summary> Get a defined faction by its Id. Return null if not defined or invalid id. </summary>
		public ActorFaction GetDefinitionById(UniqueID id)
		{
			if (id.IsEmpty) return null;
			for (int i = 0; i < definedFactions.Count; i++)
			{
				if (definedFactions[i].id == id) return definedFactions[i];
			}
			return null;
		}

		/// <summary> Return the index of the faction in the list of defined factions </summary>
		public int GetDefinitionIdx(ActorFaction f)
		{
			for (int i = 0; i < definedFactions.Count; i++)
			{
				if (definedFactions[i].id == f.id) return i;
			}
			return -1;
		}

		/// <summary> Get a faction by an ident. Return null if not found. </summary>
		public ActorFaction GetRuntimeByIdent(string ident, plyGameObjectIdentifyingType identType)
		{
			if (string.IsNullOrEmpty(ident)) return null;
			if (identType == plyGameObjectIdentifyingType.ident)
			{
				for (int i = 0; i < factions.Count; i++) if (factions[i].def.ident.Equals(ident)) return factions[i];
			}
			if (identType == plyGameObjectIdentifyingType.screenName)
			{
				for (int i = 0; i < factions.Count; i++) if (factions[i].def.screenName.Equals(ident)) return factions[i];
			}
			if (identType == plyGameObjectIdentifyingType.shortName)
			{
				for (int i = 0; i < factions.Count; i++) if (factions[i].def.shortName.Equals(ident)) return factions[i];
			}
			if (identType == plyGameObjectIdentifyingType.meta)
			{
				for (int i = 0; i < factions.Count; i++) if (factions[i].def.meta.Equals(ident)) return factions[i];
			}
			return null;
		}

		/// <summary> Get a faction by its Id. Return null if not defined or invalid id. </summary>
		public ActorFaction GetRuntimeById(UniqueID id)
		{
			if (id.IsEmpty) return null;
			for (int i = 0; i < factions.Count; i++)
			{
				if (factions[i].id == id) return factions[i];
			}
			return null;
		}

		/// <summary> Return the index of the faction in the list of active runtime factions </summary>
		public int GetRuntimeIdx(ActorFaction f)
		{
			for (int i = 0; i < factions.Count; i++)
			{
				if (factions[i].id == f.id) return i;
			}
			return -1;
		}
		
		// ============================================================================================================
	}
}