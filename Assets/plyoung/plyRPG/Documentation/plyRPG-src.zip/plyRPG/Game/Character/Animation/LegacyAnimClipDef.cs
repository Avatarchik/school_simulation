﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary>
	/// Animation definition used in Legacy animation controller
	/// </summary>
	[System.Serializable]
	public class LegacyAnimClipDef
	{
		public string clipName;					//!< name of clip
		public bool reverse = false;			//!< should it play in reverse?
		public float playbackSpeed = 1f;		//!< how fast should it play
		public WrapMode wrapMode = WrapMode.Loop; //!< wrap mode to use

		private Animation ani = null;

		/// <summary>
		/// Is animation valid? Use after Init()
		/// </summary>
		public bool IsValid 
		{ 
			get 
			{ 
				return ani != null; 
			} 
		}

		/// <summary>
		/// Length of the clip
		/// </summary>
		public float ClipLength
		{
			get
			{
				if (ani != null) return ani[clipName].length;
				return 0f;
			}
		}

		/// <summary>
		/// This should be called before using any of the other functions of this class. You should specify to 
		/// which animation this clip (animation definition) belongs
		/// </summary>
		public bool Init(Animation ani, bool silent)
		{
			if (string.IsNullOrEmpty(clipName))
			{
				if (!silent) Debug.LogError("[LegacyAnimClipDef.Init] The clipName is null or empty.");
				return false;
			}

			AnimationClip clip = ani.GetClip(clipName);
			if (clip == null)
			{
				if (!silent) Debug.LogError("[LegacyAnimClipDef.Init] The AnimationClip was not found: " + clipName);
				return false;
			}

			AnimationState aniState = ani[clipName];
			if (aniState == null)
			{
				if (!silent) Debug.LogError("[LegacyAnimClipDef.Init] The AnimationState was not found: " + clipName);
				return false;
			}

			this.ani = ani;
			return true;
		}

		/// <summary>
		/// Play the animation
		/// </summary>
		public bool Play()
		{
			if (ani == null) return false;
			ani[clipName].speed = reverse ? this.playbackSpeed * -1f : this.playbackSpeed;
			ani[clipName].wrapMode = this.wrapMode;
			ani.Play(clipName);
			return true;
		}

		/// <summary>
		/// Play the animation
		/// </summary>
		public bool Play(bool firstRewind)
		{
			if (ani == null) return false;
			ani[clipName].speed = reverse ? this.playbackSpeed * -1f : this.playbackSpeed;
			ani[clipName].wrapMode = this.wrapMode;
			if (firstRewind) ani.Rewind(clipName);
			ani.Play(clipName);
			return true;
		}

		/// <summary>
		/// Crossfade the animation
		/// </summary>
		public bool CrossFade()
		{			
			if (ani == null) return false;
			ani[clipName].speed = reverse ? this.playbackSpeed * -1f : this.playbackSpeed;
			ani[clipName].wrapMode = this.wrapMode;
			ani.CrossFade(clipName);
			return true;
		}

		// ============================================================================================================
	}
}