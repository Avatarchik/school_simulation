﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	/// <summary> The projectiles created by a Skill. The projectile will trigger Events in the Skill's
	///  Blox as needed. </summary>
	[AddComponentMenu("")]
	public class SkillProjectile : MonoBehaviour
	{
		public Skill owner;									//!< The skill this projectile belongs to

		public float moveSpeed;								//!< How fast this projectile is moving
		public Vector3 targetLocation;						//!< Location it is trying to reach
		public Transform targetTr;							//!< Target object it is trying to reach
		public Vector3 followOffset;						//!< Offset it is following at if targetTr is set
		public float maxLiveTime;							//!< The maximum time it has to live before fizzling (seconds)
		public bool triggerSecondaryOnFizzle;				//!< will it trigger a secondary effect when it fizzle?
		public bool triggerSecondaryOnFizzleOnlyIfObstacle;	//!< should the secondary only be triggered when it fizzles from hitting an obstacle?
		public float collisionRayWidth = 0.0f;				//!< Use a ray-cast (when 0) or a spherical cast to check if it hit something yet?

		public LayerMask validTargetsLayerMask;				//!< Things in these layers are considered targets (Skill.AttemptHit() will have the last say to determine if a valid hit was made)
		public LayerMask obstacleCheckMask;					//!< Things in these layers are considered obstacles that causes a fizzle
		public bool destroyProjectileOnHit = true;			//!< Should the projectile (this GameObject) be destroyed when it hits something? The alternative is that it will destroy itself once fizzle point is reached.
		public Transform createAtDummy = null;				//!< If this is set then use this transform;s position as the create point of the projectile.

		private Transform _tr;
		private Vector3 prevPos;
		private RaycastHit hit;
		private float distance;
		private Ray ray;

		private List<GameObject> hitList = new List<GameObject>(0);

		// ============================================================================================================

		/// <summary>
		/// you can override this with "new protected void Start()" in custom projectile behaviour
		/// The projectile should not yet be active, so use gameObject.SetActive(false); here
		/// The call to MakeActive() will indicate when the projectile should go active
		/// </summary>
		protected void Awake()
		{
			_tr = transform;
			gameObject.SetActive(false);
		}

		/// <summary>
		/// This should have an override in custom projectile classes. This is called once the projectile should go active.
		/// </summary>
		public virtual void MakeActive()
		{
			if (createAtDummy != null)
			{
				_tr.position = createAtDummy.position;
			}

			gameObject.SetActive(true);
		}

		/// <summary>
		/// you can override this with "new protected void Start()" in custom projectile behaviour
		/// </summary>
		protected void Start()
		{
			prevPos = _tr.position;
			ray = new Ray();
		}

		/// <summary>
		/// you can override this with "new protected void Update()" in custom projectile behaviour
		/// </summary>
		protected void Update()
		{
			if (GameGlobal.Paused) return;

			if (owner == null)
			{
				Destroy(gameObject); // fizzle when owner become invalid (skill was removed from actor or actor dead)
				return;
			}

			if (owner.owner.IsDead())
			{
				Destroy(gameObject); // fizzle when owner is dead
				return;
			}

			//if (owner.owner.character.controlEnabled == false)
			//{
			//	Destroy(gameObject); // fizzle when character controlling this skill has become inactive
			//	return;
			//}

			if (targetTr != null) targetLocation = targetTr.position + followOffset;

			prevPos = _tr.position;
			_tr.position = Vector3.MoveTowards(_tr.position, targetLocation, Time.deltaTime * moveSpeed);
			_tr.forward = (targetLocation - _tr.position).normalized;

			ray.origin = prevPos;
			ray.direction = _tr.position - prevPos;
			distance = ray.direction.magnitude;

			if (collisionRayWidth > 0.0f)
			{
				// check if collided with valid target
				if (Physics.SphereCast(ray, collisionRayWidth, out hit, distance, validTargetsLayerMask))
				{
					if (owner != null)
					{
						if (false == hitList.Contains(hit.transform.gameObject))
						{
							if (owner.AttemptHit(hit.transform.gameObject, hit.point))
							{	// only destroy if the hit was valid
								if (destroyProjectileOnHit)
								{
									Destroy(gameObject);
									return;
								}
								else
								{
									hitList.Add(hit.transform.gameObject);
								}
							}
						}
					}
					else
					{	// only destroy here if owner was null and could not do check for valid target
						Destroy(gameObject);
						return;
					}
				}


				// check if collided with an obstacle and fizzle if so
				if (obstacleCheckMask != 0)
				{
					if (Physics.SphereCast(ray, collisionRayWidth, out hit, distance, obstacleCheckMask))
					{
						if (owner != null)
						{
							owner.ExecuteFizzleEvent(_tr.position, true);
							if (triggerSecondaryOnFizzle) owner.ExecuteSecondary(_tr.position, null);
						}
						Destroy(gameObject);
						return;
					}
				}
			}
			else
			{
				// check if collided with valid target
				if (Physics.Raycast(ray, out hit, distance, validTargetsLayerMask))
				{
					if (owner != null)
					{
						if (false == hitList.Contains(hit.transform.gameObject))
						{
							if (owner.AttemptHit(hit.transform.gameObject, hit.point))
							{	// only destroy if the hit was valid
								if (destroyProjectileOnHit)
								{
									Destroy(gameObject);
									return;
								}
								else
								{
									hitList.Add(hit.transform.gameObject);
								}
							}
						}
					}
					else
					{	// only destroy here if owner was null and could not do check for valid target
						Destroy(gameObject);
						return;
					}
				}


				// check if collided with an obstacle and fizzle if so
				if (obstacleCheckMask != 0)
				{
					if (Physics.Raycast(ray, out hit, distance, obstacleCheckMask))
					{
						if (owner != null)
						{
							owner.ExecuteFizzleEvent(_tr.position, true);
							if (triggerSecondaryOnFizzle) owner.ExecuteSecondary(_tr.position, null);
						}
						Destroy(gameObject);
						return;
					}
				}
			}

			// Fizzle when reached the target location
			maxLiveTime -= Time.deltaTime;
			if ((targetLocation - _tr.position).sqrMagnitude < 0.01f || maxLiveTime <= 0.0f)
			{
				if (owner != null)
				{
					owner.ExecuteFizzleEvent(_tr.position, false);
					if (triggerSecondaryOnFizzle && triggerSecondaryOnFizzleOnlyIfObstacle == false)
					{
						owner.ExecuteSecondary(_tr.position, null);
					}
				}
				Destroy(gameObject);
			}
		}

		// ============================================================================================================
	}
}