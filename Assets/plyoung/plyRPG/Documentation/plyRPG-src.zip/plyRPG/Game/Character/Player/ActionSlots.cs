﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	public class ActionSlots
	{
		public enum SlotType
		{
			None = 0, Skill = 1, Item = 2
		}

		public class Slot
		{
			public SlotType type = SlotType.None;
			public int idx = -1;
			public int keyBind = -1;
			public UniqueID id = UniqueID.Empty; // id of linked item prefab or skill
		}

		public Slot[] slots { get; set; }

		private Actor owner;
		private ItemBag ownerBag;

		// ============================================================================================================
		#region init

		public void Init(int slotCount, Actor owner)
		{
			this.owner = owner;
			this.ownerBag = owner.gameObject.GetComponent<ItemBag>();
			if (slotCount < 0) slotCount = 0;
			slots = new Slot[slotCount];
			for (int i = 0; i < slotCount; i++)
			{
				slots[i] = new Slot();
				slots[i].idx = i;
			}
		}

		public void InitDefaultBinds()
		{
			for (int i = 0; i < slots.Length; i++)
			{
				if (i > 9) break;
				slots[i].keyBind = plyInput.GetInputIdx("Action/Action" + (i + 1).ToString());
			}
		}

		#endregion
		// ============================================================================================================
		#region load/save

		public void Save(string key)
		{
			DeleteSaveData(key);
			key = key + ".actslots.";
			for (int i = 0; i < slots.Length; i++)
			{
				if (!slots[i].id.IsEmpty)
				{
					GameGlobal.SetStringKey(key + i, slots[i].id.ToString());
				}
			}
		}

		public void Load(string key)
		{			
			key = key + ".actslots.";
			for (int i = 0; i < slots.Length; i++)
			{
				string ids = GameGlobal.GetStringKey(key + i, null);
				if (ids != null)
				{
					UniqueID id = new UniqueID(ids);
					if (!id.IsEmpty) EquipSkill(i, id);
				}
			}
		}

		public void DeleteSaveData(string key)
		{
			key = key + ".actslots.";
			for (int i = 0; i < slots.Length; i++)
			{
				GameGlobal.DeleteKey(key + i);
			}
		}

		#endregion
		// ============================================================================================================
		#region pub

		public void Update()
		{
			for (int i=0; i < slots.Length; i++)
			{
				if (plyInput.GetButtonDown(slots[i].keyBind)) TriggerSlot(i);
			}
		}

		public bool TriggerSlot(int idx)
		{
			if (idx < 0 || idx >= slots.Length)
			{
				Debug.LogError("The slot index is invalid: " + idx);
				return false;
			} 

			if (slots[idx].type == SlotType.None) return true;
			else if (slots[idx].type == SlotType.Skill) UseSkill(slots[idx]);
			else if (slots[idx].type == SlotType.Item) UseItem(slots[idx]);
			return true;
		}

		private void UseSkill(Slot s)
		{
			owner.QueueSkillForExecution(s.id, false);
		}

		private void UseItem(Slot s)
		{
			if (ownerBag != null) ownerBag.UseItem(s.id);
		}

		public bool BindToInput(int slotIdx, string inputBindName)
		{
			if (slotIdx < 0 || slotIdx >= slots.Length)
			{
				Debug.LogError("The slot index is invalid: " + slotIdx);
				return false;
			}

			if (string.IsNullOrEmpty(inputBindName))
			{
				slots[slotIdx].keyBind = -1;
			}
			else
			{
				slots[slotIdx].keyBind = plyInput.GetInputIdx(inputBindName);
				if (slots[slotIdx].keyBind < 0)
				{
					Debug.LogError("Input bind name is invalid: " + inputBindName);
					return false;
				}
			}

			return true;
		}

		public bool ClearSlot(int idx)
		{
			if (idx < 0 || idx >= slots.Length)
			{
				Debug.LogError("The slot index is invalid: " + idx);
				return false;
			} 
			
			slots[idx].type = SlotType.None;
			slots[idx].id = UniqueID.Empty;

			return true;
		}

		public bool EquipSkill(int idx, UniqueID skillId)
		{
			if (skillId.IsEmpty)
			{
				Debug.LogError("No valid skill specified.");
				return false;
			}

			if (idx < 0 || idx >= slots.Length)
			{
				Debug.LogError("The slot index is invalid: " + idx);
				return false;
			}

			ClearSlot(idx);
			slots[idx].type = SlotType.Skill;
			slots[idx].id = skillId;

			return true;
		}

		public bool EquipItem(int idx, UniqueID itemFabId)
		{
			if (ownerBag == null)
			{
				Debug.LogError("The player does not have a ItemBag component on it.");
				return false;
			}

			if (itemFabId.IsEmpty)
			{
				Debug.LogError("No valid item specified.");
				return false;
			}

			if (idx < 0 || idx >= slots.Length)
			{
				Debug.LogError("The slot index is invalid: " + idx);
				return false;
			}

			ClearSlot(idx);
			slots[idx].type = SlotType.Item;
			slots[idx].id = itemFabId;			

			return true;
		}

		public SlotType EquippedType(int idx)
		{
			if (idx < 0 || idx >= slots.Length)
			{
				Debug.LogError("The slot index is invalid: " + idx);
				return SlotType.None;
			}

			return slots[idx].type;
		}

		/// <summary>
		/// Return a reference to the Skill Definition or Item Prefab rather than the Skill object or Item in bag.
		/// </summary>
		public System.Object GetEquippedNfo(int idx)
		{
			if (idx < 0 || idx >= slots.Length)
			{
				Debug.LogError("The slot index is invalid: " + idx);
				return null;
			}

			if (slots[idx].type == SlotType.Skill) return SkillsAsset.Instance.GetDefinition(slots[idx].id);
			else if (slots[idx].type == SlotType.Item) return ItemsAsset.Instance.GetDefinition(slots[idx].id);
			return null;
		}

		/// <summary>
		/// Return reference to the known Skill or Item in Bag. Will return null if skill not known or Item not found bag.
		/// </summary>
		public System.Object GetEquipped(int idx)
		{
			if (idx < 0 || idx >= slots.Length)
			{
				Debug.LogError("The slot index is invalid: " + idx);
				return null;
			}

			if (slots[idx].type == SlotType.Skill) return owner.GetKnownSkill(slots[idx].id);
			else if (slots[idx].type == SlotType.Item && ownerBag != null) ownerBag.FindItem(slots[idx].id);
			return null;
		}

		#endregion
		// ============================================================================================================
	}
}
