﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> The Actor Attribute defines a property an actor may have. Attributes are linked to
	///  Actors via the Actor Class assigned to an Actor. </summary>
	[System.Serializable]
	public class ActorAttribute
	{
		#region properties

		/// <summary> Attribute Value Types </summary>
		public enum ValueType 
		{ 
			Value,				//!< 'Value' value type. Used as the max that consumable types can reach. Also used with attributes like Wisdom, Strength, Intelligence, etc.
			ConsumableValue,	//!< 'Consumable' value type. Used where the attribute can be 'consumed, for example Health or Mana points.
			Bonus,				//!< The Bonus value. When used to "set" then UpdateSimpleBonus() is used. When reading then value of bonusValue is returned.
		}

		[HideInInspector] public UniqueID id = new UniqueID();			//!< Unique Id of the Attribute
		public CommonDefinitionData def = new CommonDefinitionData();	//!< common data

		#endregion
		// ============================================================================================================
		#region runtime

		/// <summary> Owner (ActorClass) of this Attribute. Only valid at run-time. </summary>
		public ActorClass owner { get; set; }

		/// <summary> Data contains the base, max, etc type data for the Attribute. Initialised by the Actor class at runtime </summary>
		public ActorAttributeData data { get; set; }

		/// <summary> (baseValue + bonusValue) This is the real value of the attribute. This is the
		///  value to read when you want to see what STR, INT, etc is, or if you want to know what MAX
		///  is that Health or Mana type attributes can reach. </summary>
		public float Value { get; private set; }

		/// <summary> This is the variable/ consumable value of the attribute. Used to tract the CURRENT
		///  value of an attribute like Health or Mana. Not used with attributes that do not get consumed,
		///  like Strength or Intelligence. </summary>
		public float ConsumableValue
		{
			get { return _consumableValue; }
		}

		public float lastValue { get; private set; } //!< what it was before the last change
		public float lastConsumableValue { get; private set; } //!< what it was before the last change
		public GameObject lastInfluence { get; set; } //!< what object was associated with the change in attribute value, if any. Normally use when there is an attacker decreasing the Health ConsumableValue

		public float BonusValue { get; private set; }
		private float _consumableValue = 0f;

		// this is a value that will be added to bonus when bonus is calculated.
		// it is a simple way to add/ remove bonus values without going through the bonus calculators registration
		// this value is not saved/ restored during scene loads.
		private float _simpleBonus = 0f;

		private ResultCallback BonusCalculators = null; // the callbacks that will return a value to add to the Bonus
		private GeneralCallback ChangeListener = null;

		#endregion
		// ============================================================================================================
		#region system

		public override string ToString()
		{
			return def.screenName;
		}

		public ActorAttribute Copy()
		{
			ActorAttribute obj = new ActorAttribute();
			this.CopyTo(obj);
			return obj;
		}

		public void CopyTo(ActorAttribute o)
		{
			o.id = this.id.Copy();
			o.def = this.def.Copy();
		}

		private void Broadcast()
		{
			owner.owner.BroadcastMessage("OnAttributeChange", this, SendMessageOptions.DontRequireReceiver);
			if (id == ActorAttributesAsset.Instance.xpAttribId) owner.owner.BroadcastMessage("OnXPChanged", this, SendMessageOptions.DontRequireReceiver);
			if (id == ActorAttributesAsset.Instance.hpAttribId) owner.owner.BroadcastMessage("OnHPChanged", this, SendMessageOptions.DontRequireReceiver);
			if (ChangeListener != null) ChangeListener(this, new object[] { Value, ConsumableValue });
		}

		#endregion
		// ============================================================================================================
		#region saving & loading (called by ActorClass when needed)

		public void Save(string key)
		{
			if (data.canGrow) return; // do not bother if growth is controlled by Level

			key = key + "." + id;
			GameGlobal.SetFloatKey(key + ".b", data.baseValue);		// base value
			GameGlobal.SetFloatKey(key + ".m", data.maxValue);		// max value
			GameGlobal.SetFloatKey(key + ".c", _consumableValue);	// current level of consumable value
			// todo: how to handle bonus values?
		}

		public void Load(string key)
		{
			if (data.canGrow) return; // do not bother if growth is controlled by Level

			key = key + "." + id;
			data.baseValue = GameGlobal.GetIntKey(key + ".b", data.baseValue);
			data.maxValue = GameGlobal.GetIntKey(key + ".m", data.maxValue);
			_consumableValue = GameGlobal.GetFloatKey(key + ".c", _consumableValue);
			lastConsumableValue = _consumableValue;
		}

		public void DeleteSaveData(string key)
		{
			if (data.canGrow) return; // do not bother if growth is controlled by Level

			key = key + "." + id;
			GameGlobal.DeleteKey(key + ".b");
			GameGlobal.DeleteKey(key + ".m");
			GameGlobal.DeleteKey(key + ".c");
		}

		#endregion
		// ============================================================================================================
		#region pub

		/// <summary> Init the Value and ConsumableValue without triggering callbacks. Used by Actor Class
		///  when it creates the Attribute. </summary>
		public void Init(ActorClass owner, int currLevel)
		{
			this.owner = owner;
			if (data.canGrow && currLevel > 0)
			{
				data.baseValue = (int)data.growthCurve.GetYValue(currLevel - 1);
			}

			Recalc(false);
			_consumableValue = Value;
			lastConsumableValue = Value;
			lastValue = Value;
			lastInfluence = null;
		}

		/// <summary> Call this to force a recalculate of the Value. ConsumableValue will be updated to not
		///  be more than Value. </summary>
		public void Recalc(bool withCallbacks)
		{
			BonusValue = 0f;
			lastValue = Value;
			float consumableWas = ConsumableValue;

			if (BonusCalculators != null)
			{
				//Debug.Log("TEST IF THIS WORKS AS EXPECTED WHEN THERE IS MORE THAN ONE BONUS CALC REGED");
				BonusValue = (float)BonusCalculators(this, null);
			}

			BonusValue += _simpleBonus;
			Value = data.baseValue + BonusValue;
			if (Value < 0.0f) Value = 0.0f;
			//if (Value > data.maxValue) Value = data.maxValue; - remove this check as it prevents bonuses when Value is already at max
			if (_consumableValue > Value) _consumableValue = Value;

			if (withCallbacks)
			{
				if (lastValue != Value || consumableWas != ConsumableValue)
				{
					Broadcast();
				}
			}
		}

		/// <summary> Register a Callback that should return a Float value which will be added to
		///  bonusValue when recalculating what the Value of the attribute should be. </summary>
		public void RegisterBonusCalculator(ResultCallback callback)
		{
			BonusCalculators += callback;
		}

		/// <summary> Removes the bonus calculator described by callback. </summary>
		public void RemoveBonusCalculator(ResultCallback callback)
		{
			BonusCalculators -= callback;
		}

		/// <summary> Registers a callback that should be informed when the Value or ConsumableValue
		///  changes. </summary>
		public void RegisterChangeListener(GeneralCallback callback)
		{
			ChangeListener += callback;
		}

		/// <summary> Removes the change listener described by callback. </summary>
		public void RemoveChangeListener(GeneralCallback callback)
		{
			ChangeListener -= callback;
		}

		/// <summary>
		/// Set the consumable value. You can optionally set an 'influence'. This is the object that was the 
		/// reason for the change in value. Useful when tagging who was the attacker when Hp decreased.
		/// </summary>
		public void SetConsumableValue(float v, GameObject influence)
		{
			lastInfluence = influence;
			lastConsumableValue = _consumableValue;
			_consumableValue = v;
			if (_consumableValue < 0.0f) _consumableValue = 0.0f;
			if (_consumableValue > Value) _consumableValue = Value;
			if (lastConsumableValue != _consumableValue) Broadcast();
		}

		/// <summary> Sets the attribute's 'Value' and call recalculate to make sure ConsumableValue is the
		///  same or less. </summary>
		public void SetBaseValue(int v)
		{
			data.baseValue = v;
			if (data.baseValue < 0) data.baseValue = 0;
			Recalc(true);
		}

		/// <summary> Change base value and call Recalculate to update 'Value' and to make sure ConsumableValue
		///  is the same or less. </summary>
		public void ChangeBaseValueBy(int v)
		{
			if (v == 0) return; // will have no effect
			data.baseValue += v;
			if (data.baseValue < 0) data.baseValue = 0;
			Recalc(true);
		}

		/// <summary> Tell the Attribute that the level changed. It will act on that if it is an attribute
		///  that is linked to the leveling system. </summary>
		public void LevelChanged(int newLevel)
		{
			if (data.canGrow)
			{
				data.baseValue = (int)data.growthCurve.GetYValue(newLevel - 1);
				Recalc(false);
				if (data.alsoUpdateConsumable) _consumableValue = Value;
			}
		}

		/// <summary>
		/// Pass positive or negative value to influence bonus value. This can push bonus to negative
		/// and this negatively influence the final Value calculation.
		/// </summary>
		public void ChangeSimpleBonus(int val)
		{
			_simpleBonus += val;
			Recalc(true);
		}

		/// <summary>
		/// Set simple bonus value to this exact value.
		/// </summary>
		public void SetSimpleBonus(int val)
		{
			_simpleBonus = val;
			Recalc(true);
		}

		#endregion
		// ============================================================================================================
	}
}