﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace plyGame
{
	/// <summary>
	/// A movement definition, used in Legacy Animation controller
	/// </summary>
	[System.Serializable]
	public class LegacyAnimMoveDef
	{
		public string name = "";			//!< name
		public float speedDetect = 999f;	//!< play only if movement speed is this value or lower
		
		public LegacyAnimClipDef forward = new LegacyAnimClipDef();			//!< forward
		public LegacyAnimClipDef backward = new LegacyAnimClipDef();		//!< backward
		public LegacyAnimClipDef forwardRight = new LegacyAnimClipDef();	//!< forward-right
		public LegacyAnimClipDef forwardLeft = new LegacyAnimClipDef();		//!< forward-left
		public LegacyAnimClipDef backwardRight = new LegacyAnimClipDef();	//!< backward-right
		public LegacyAnimClipDef backwardLeft = new LegacyAnimClipDef();	//!< backward-left

		public bool lrfRotateBody = true;	//!< .
		public bool lrbRotateBody = true;	//!< .
		public float lrfMaxAngle = 70f;		//!< .
		public float lrbMaxAngle = 70f;		//!< .

		/// <summary>
		/// Init should be called before any of the other functions can be used
		/// </summary>
		public void Init(Animation ani)
		{
			forward.Init(ani, true);
			forwardRight.Init(ani, true);
			forwardLeft.Init(ani, true);

			backward.Init(ani, true);
			backwardRight.Init(ani, true);
			backwardLeft.Init(ani, true);
		}

		/// <summary>
		/// Play the animation
		/// </summary>
		public float PlayAni(float speed, Vector3 movement, CharacterControllerBase chara, Transform tr, Transform bip, Transform spine)
		{
			float targetAngle = Vector3.Angle(movement, new Vector3(tr.forward.x, 0.0f, tr.forward.z));

			// Negative rotation if shortest route is counter-clockwise
			if (Vector3.Angle(movement, tr.right) > Vector3.Angle(movement, tr.right * -1)) targetAngle *= -1.0f;

			// When walking backwards, don't rotate over 90 degrees and rotate opposite
			if (Mathf.Abs(targetAngle) > 91.0f) targetAngle = targetAngle + (targetAngle > 0 ? -180.0f : 180.0f);

			// If the direction if backwards, play the animations backwards
			if (Vector3.Angle(tr.forward, movement) > 91.0f)
			{
				if (targetAngle > 0f) backwardLeft.CrossFade();
				else if (targetAngle < 0f) backwardRight.CrossFade();
				else backward.CrossFade();

				if (lrbRotateBody)
				{
					if (targetAngle < 10f && targetAngle > -10f) return 0.0f;
					if (targetAngle > 0f && targetAngle > lrbMaxAngle) targetAngle = lrbMaxAngle;
					else if (targetAngle < 0f && targetAngle < -lrbMaxAngle) targetAngle = -lrbMaxAngle;
					return targetAngle;
				}
			}

			// Else, forward
			else
			{
				if (targetAngle > 0f) forwardRight.CrossFade();
				else if (targetAngle < 0f) forwardLeft.CrossFade();
				else forward.CrossFade();

				if (lrfRotateBody)
				{
					if (targetAngle < 10f && targetAngle > -10f) return 0.0f;
					if (targetAngle > 0f && targetAngle > lrfMaxAngle) targetAngle = lrfMaxAngle;
					else if (targetAngle < 0f && targetAngle < -lrfMaxAngle) targetAngle = -lrfMaxAngle;
					return targetAngle;
				}
			}

			return 0.0f;
		}

		// ============================================================================================================
	}
}