﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace plyGame
{
	/// <summary> This is the base class for the NPC movement controllers. All movement controllers should derive from this. </summary>
	[AddComponentMenu("plyGame/Character/NPC/Movement/No-Move")]
	public class NPCMoveBase: MonoBehaviour
	{
		/// <summary> Ask mover to move the NPC to the target position. </summary>
		public virtual void MoveTo(Vector3 pos, float moveSpeed, float turnSpeed)
		{
		}

		/// <summary> Ask the mover to face the NPC in the target direction. </summary>
		public virtual void FaceDirection(Vector3 direction, float turnSpeed)
		{
		}

		/// <summary> Make the mover stop immediately. </summary>
		public virtual void Stop()
		{
		}

		/// <summary> Current velocity according to mover. </summary>
		public virtual Vector3 Velocity()
		{
			return Vector3.zero;
		}

		/// <summary> Mover's desired velocity. </summary>
		public virtual Vector3 DesiredVelocity()
		{
			return Vector3.zero;
		}

		/// <summary> Tell mover to use this velocity. </summary>
		public virtual void UpdateVelocity(Vector3 v)
		{
		}

		/// <summary> Is the character on the ground? </summary>
		public virtual bool Grounded()
		{
			return true;
		}

		/// <summary> Is the mover moving the character or getting ready to move it? </summary>
		public virtual bool IsMovingOrPathing()
		{
			return false;
		}

		/// <summary> Return true if in controlled turn. Normally when performing a FaceDirection() request. </summary>
		public virtual bool InControlledTurn()
		{
			return false;
		}

		// ============================================================================================================
	}
}