﻿//using UnityEngine;
//using plyBloxKit;

//namespace plyGame
//{
//	public class test
//	{

//		public void func()
//		{
//			Item item;
//plyBlox blox = item.gameObject.GetComponent<plyBlox>();
//blox.SetLocalVarValue("A", Random.Range(1, 100), true);
//blox.SetLocalVarValue("B", Random.Range(1, 100));
//blox.SetLocalVarValue("C", Random.Range(1, 100));
//blox.SetLocalVarValue("D", Random.Range(1, 100));
			

//		}

//	}
//}