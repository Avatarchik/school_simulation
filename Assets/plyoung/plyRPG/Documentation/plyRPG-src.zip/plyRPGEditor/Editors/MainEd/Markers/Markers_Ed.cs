﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using plyCommon;
using plyGame;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;

namespace plyGameEditor
{
	[ChildEditor("Markers", Order = -99800, Icon="marker")]
	public class Markers_Ed : ChildEditorBase
	{
		private static string[] menuOpts = new string[0];
		private static ChildEditorBase[] editors;

		private DataAsset dataAsset;
		private MarkersAsset markersAsset;

		private static GUIContent GC_Refresh;
		private static GUIContent GC_Ping;

		private Vector2 scroll = Vector2.zero;
		private int prevSel = 0;
		private int sel = 0;

		// ============================================================================================================

		public override void OnCreated(Assembly[] asms) 
		{
			// find all the classes that inherit from ChildEditorBase
			List<System.Type> foundEdTypes = new List<System.Type>();
			for (int i = 0; i < asms.Length; i++)
			{
				System.Type[] types = asms[i].GetExportedTypes();
				for (int j = 0; j < types.Length; j++)
				{
					if (types[j].IsClass && typeof(ChildEditorBase).IsAssignableFrom(types[j]) && types[j].Name != "ChildEditorBase")
					{
						foundEdTypes.Add(types[j]);
					}
				}
			}

			// extract some def.meta data and look specifically for MarkersEdMenu attribute
			List<string> labels = new List<string>();
			List<ChildEditorBase> eds = new List<ChildEditorBase>();

			labels.Add("Markers");	// first entry is the list of markers
			eds.Add(null);
			labels.Add(null);		// second is a spacer before custom marker editors follows
			eds.Add(null);

			for (int i = 0; i < foundEdTypes.Count; i++)
			{
				EdMenuOptionAttribute att = null;
				System.Object[] attribs = foundEdTypes[i].GetCustomAttributes(typeof(EdMenuOptionAttribute), false);
				if (attribs.Length > 0)
				{
					att = attribs[0] as EdMenuOptionAttribute;
					if (att != null)
					{
						if (att.ParentEd == typeof(Markers_Ed))
						{
							ChildEditorBase ed = (ChildEditorBase)System.Activator.CreateInstance(foundEdTypes[i]);
							labels.Add(att.Name);
							eds.Add(ed);
							ed.OnCreated(asms);
						}
					}
				}
			}

			// update the caches
			menuOpts = labels.ToArray();
			editors = eds.ToArray();
		}	

		public override void OnFocus()
		{
			if (markersAsset == null)
			{
				dataAsset = EdGlobal.GetDataAsset();
				markersAsset = (MarkersAsset)dataAsset.GetAsset<MarkersAsset>();
				if (markersAsset == null)
				{
					markersAsset = (MarkersAsset)EdGlobal.LoadOrCreateAsset<MarkersAsset>(EdGlobal.DATA_PATH_SYSTEM + "markers.asset", "Marker Definitions");
					if (markersAsset.markerFabs.Count > 0)
					{	// make sure the asset is in the data asset if there is data defined
						if (dataAsset.AddAsset(markersAsset)) EditorUtility.SetDirty(dataAsset);
					}
				}
			}

			if (markersAsset.UpdateCache())
			{
				EditorUtility.SetDirty(markersAsset);
			}

			if (sel > 1)
			{
				editors[sel].ed = this.ed;
				editors[sel].OnFocus();
			}
		}

		private void CheckGUIContent()
		{
			if (GC_Refresh == null)
			{
				GC_Refresh = new GUIContent(FA.refresh + " Refresh", "Run through project and find all marker prefabs");
				GC_Ping = new GUIContent(FA.Ico12(FA.bullseye, plyEdGUI.IconColor), "Ping the prefab");
			}
		}

		public override void OnGUI()
		{
			CheckGUIContent();
			EditorGUILayout.BeginHorizontal();
			{
				prevSel = sel;
				sel = plyEdGUI.Menu(sel, menuOpts, GUILayout.Width(MainEditorWindow.MenuWidth));

				EditorGUILayout.BeginVertical();
				{
					if (sel == 0)
					{
						DetectedMarkers();
					}
					else if (sel > 1) // note, skip 1 as it is a spacer
					{
						editors[sel].ed = this.ed;
						if (sel != prevSel) editors[sel].OnFocus();
						editors[sel].OnGUI();
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();
		}

		private void DetectedMarkers()
		{
			EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
			{
				if (GUILayout.Button(GC_Refresh, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(120)))
				{
					plyEdGUI.ClearFocus();
					RefreshMarkers();
				}
				EditorGUILayout.Space();
				if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.ToolbarIconButtonStyle))
				{
					Application.OpenURL(plyRPGEdGlobal.HLP_MarkerListEd);
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			if (markersAsset.markers.Count > 0)
			{
				scroll = EditorGUILayout.BeginScrollView(scroll);
				EditorGUILayout.BeginVertical(plyEdGUI.LRPaddingHelperStyle);
				{
					bool style2 = true;
					for (int i = 0; i < markersAsset.markers.Count; i++)
					{
						style2 = !style2;
						Rect r = EditorGUILayout.BeginHorizontal(style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
						{
							if (GUILayout.Button(GC_Ping, EditorStyles.miniButton, GUILayout.Width(20)))
							{
								EditorGUIUtility.PingObject(markersAsset.markers[i].gameObject);
							}
							GUILayout.Label(markersAsset.markers[i].name);
							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
					}
				}
				EditorGUILayout.Space();
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			else
			{
				GUILayout.Label("No Marker prefabs detected. Use the Refresh\nbutton to force a refresh if needed.");
			}
		}

		private void RefreshMarkers()
		{
			List<Marker> markers = plyEdUtil.FindPrefabsOfTypeAll<Marker>("Please wait", "Searching for all Marker prefabs");
			
			markersAsset.markerFabs = new List<GameObject>(0);
			for (int i = 0; i < markers.Count; i++)
			{
				markersAsset.markerFabs.Add(markers[i].gameObject);
			}

			markersAsset.UpdateCache();
			EditorUtility.SetDirty(markersAsset);
		}

		// ============================================================================================================
	}
}