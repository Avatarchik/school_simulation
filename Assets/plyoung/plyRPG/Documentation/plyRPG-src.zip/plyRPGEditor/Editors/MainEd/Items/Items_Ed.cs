﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using plyCommon;
using plyGame;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;

namespace plyGameEditor
{
	[ChildEditor("Items", Order = -99700, Icon = "items")]
	public class Items_Ed : ChildEditorBase
	{
		private ItemsAsset itemsAsset;

		private static string[] menuOpts = new string[0];
		private static ChildEditorBase[] editors;

		private static GUIContent GC_Refresh;
		private static GUIContent GC_Ping;
		private static GUIContent GC_General;
		private static GUIContent GC_ItemTypes;
		private static GUIContent GC_EquipSlots;

		private Vector2[] scroll = { Vector2.zero, Vector2.zero, Vector2.zero };
		private int prevSel = 0;
		private int sel = 0;
		private bool needInit = true;

		private int showDef = 0; // 0:item groups, 1:equip slots
		private string currSlot = null;
		private ItemType currItemType = null;
		private string currItemSubType = null;

		// ============================================================================================================

		public override void OnCreated(Assembly[] asms)
		{
			// find all the classes that inherit from ChildEditorBase
			List<System.Type> foundEdTypes = new List<System.Type>();
			for (int i = 0; i < asms.Length; i++)
			{
				System.Type[] types = asms[i].GetExportedTypes();
				for (int j = 0; j < types.Length; j++)
				{
					if (types[j].IsClass && typeof(ChildEditorBase).IsAssignableFrom(types[j]) && types[j].Name != "ChildEditorBase")
					{
						foundEdTypes.Add(types[j]);
					}
				}
			}

			// extract some def.meta data and look specifically for MarkersEdMenu attribute
			List<string> labels = new List<string>();
			List<ChildEditorBase> eds = new List<ChildEditorBase>();

			labels.Add("Settings");
			eds.Add(null);
			labels.Add("Items");
			eds.Add(null);
			labels.Add(null); // spacer
			eds.Add(null);

			for (int i = 0; i < foundEdTypes.Count; i++)
			{
				EdMenuOptionAttribute att = null;
				System.Object[] attribs = foundEdTypes[i].GetCustomAttributes(typeof(EdMenuOptionAttribute), false);
				if (attribs.Length > 0)
				{
					att = attribs[0] as EdMenuOptionAttribute;
					if (att != null)
					{
						if (att.ParentEd == typeof(Items_Ed))
						{
							ChildEditorBase ed = (ChildEditorBase)System.Activator.CreateInstance(foundEdTypes[i]);
							labels.Add(att.Name);
							eds.Add(ed);
							ed.OnCreated(asms);
						}
					}
				}
			}

			// update the caches
			menuOpts = labels.ToArray();
			editors = eds.ToArray();
		}

		public override void OnFocus()
		{
			needInit = true;
			if (sel > 2)
			{
				editors[sel].ed = this.ed;
				editors[sel].OnFocus();
			}

			if (itemsAsset == null)
			{
				DataAsset dataAsset = EdGlobal.GetDataAsset();
				itemsAsset = (ItemsAsset)dataAsset.GetAsset<ItemsAsset>();
				if (itemsAsset == null)
				{
					itemsAsset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(EdGlobal.DATA_PATH_SYSTEM + "items.asset", "Items System");
					if (dataAsset.AddAsset(itemsAsset)) EditorUtility.SetDirty(dataAsset);
				}
			}
		}

		private void Init()
		{
			if (plyRPGEdGlobal.edData != null)
			{
				needInit = false;
				if (itemsAsset.UpdateItemCache())
				{
					EditorUtility.SetDirty(plyRPGEdGlobal.edData);
				}
			}
		}

		private void CheckGUIContent()
		{
			if (GC_Refresh == null)
			{
				GC_Refresh = new GUIContent(FA.refresh + " Refresh", "Run through project and find all item prefabs");
				GC_Ping = new GUIContent(FA.Ico12(FA.bullseye, plyEdGUI.IconColor), "Ping the prefab");
				GC_General = new GUIContent(FA.gear + " Settings");
				GC_ItemTypes = new GUIContent(FA.glass + " Item Types");
				GC_EquipSlots = new GUIContent(FA.male + " Equip Slots");
			}
		}

		public override void OnGUI()
		{
			if (needInit) Init();
			CheckGUIContent();
			EditorGUILayout.BeginHorizontal();
			{
				prevSel = sel;
				sel = plyEdGUI.Menu(sel, menuOpts, GUILayout.Width(MainEditorWindow.MenuWidth));

				EditorGUILayout.BeginVertical();
				{
					if (sel == 0) ShowSettings();
					if (sel == 1) ShowItems();
					else if (sel > 2) // note, skip 2 as it is a spacer
					{
						editors[sel].ed = this.ed;
						if (sel != prevSel) editors[sel].OnFocus();
						editors[sel].OnGUI();
					}
				}
				EditorGUILayout.EndVertical();
			}
			EditorGUILayout.EndHorizontal();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(itemsAsset);
			}

		}

		// ============================================================================================================

		private void ShowSettings()
		{
			EditorGUILayout.BeginVertical();
			{
				EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
				{
					if (plyEdGUI.ToggleButton(showDef == 0, GC_General, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(100))) showDef = 0;
					if (plyEdGUI.ToggleButton(showDef == 1, GC_ItemTypes, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(100))) showDef = 1;
					if (plyEdGUI.ToggleButton(showDef == 2, GC_EquipSlots, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(100))) showDef = 2;
					GUILayout.FlexibleSpace();
				}
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Space();

				if (showDef == 0) General();
				else if (showDef == 1) ItemTypes();
				else if (showDef == 2) EquipSlots();
			}
			EditorGUILayout.EndVertical();
		}

		private void General()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Settings");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				itemsAsset.storageMethod = (ItemsAsset.StorageMethod)EditorGUILayout.EnumPopup("Storage Method", itemsAsset.storageMethod);
				itemsAsset.autoPickItemDisableDistance = EditorGUILayout.FloatField("Item Disable Distance", itemsAsset.autoPickItemDisableDistance);
				itemsAsset.runtimeCreatedItemsPersist = EditorGUILayout.Toggle("Runtime Items Persist", itemsAsset.runtimeCreatedItemsPersist);
			}
			EditorGUILayout.EndVertical();

			plyEdGUI.HLine(20);
		}

		private void ItemTypes()
		{
			EditorGUILayout.BeginHorizontal(plyEdGUI.LRPaddingHelperStyle);
			{
				if (plyEdGUI.ItemsList<ItemType>(ref currItemType, itemsAsset.itemTypes, false, true, false, false, ItemTypesCallback, ref scroll[1], null, "No types defined", false, null, null, GUILayout.Width(200)))
				{
					scroll[2] = Vector2.zero;
					currItemSubType = null;
				}
				GUILayout.Space(3);
				if (currItemType != null)
				{
					plyEdGUI.ItemsList<string>(ref currItemSubType, currItemType.subTypes, false, true, false, false, ItemSubTypesCallback, ref scroll[2], null, "No sub-types defined", false, null, null, GUILayout.Width(200));
				}
			}
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
		}

		private object ItemTypesCallback(object sender, object[] args)
		{
			// 1: new, 2: copy, 3: about to delete, 4: deleted, 5: position changed, 6: rename
			int act = (int)args[0];
			if (act == 1)
			{
				currItemType = new ItemType();
				currItemType.name = "item type " + itemsAsset.itemTypes.Count;
				itemsAsset.itemTypes.Add(currItemType);
				EditorUtility.SetDirty(itemsAsset);
				return currItemType;
			}
			else if (act == 3)
			{
				int pos = (int)args[2];
				for (int i = 0; i < itemsAsset.items.Count; i++)
				{
					if (itemsAsset.items[i].itemType == pos)
					{
						itemsAsset.items[i].itemType = -1;
						itemsAsset.items[i].itemSubType = -1;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
					else if (itemsAsset.items[i].itemType > pos)
					{	// those a level higher must move one down
						itemsAsset.items[i].itemType--;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
				}
			}
			else if (act == 4)
			{
				currItemType = itemsAsset.itemTypes.Count > 0 ? itemsAsset.itemTypes[0] : null;
				EditorUtility.SetDirty(itemsAsset);
				return currItemType;
			}
			else if (act == 5)
			{
				int prevPos = (int)args[1];
				int newPos = (int)args[2];
				for (int i = 0; i < itemsAsset.items.Count; i++)
				{
					if (itemsAsset.items[i].itemType == prevPos)
					{
						itemsAsset.items[i].itemType = newPos;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
					else if (itemsAsset.items[i].itemType == newPos)
					{
						itemsAsset.items[i].itemType = prevPos;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
				}
			}
			else if (act == 6)
			{
				plyTextInputWiz.ShowWiz("Rename Item Type", "Enter a unique name", currItemType.name, OnRename, new object[] { 2 });
				return null;
			}
			EditorUtility.SetDirty(itemsAsset);
			return null;
		}

		private object ItemSubTypesCallback(object sender, object[] args)
		{
			int act = (int)args[0];
			if (act == 1)
			{
				currItemSubType = "type " + currItemType.subTypes.Count;
				currItemType.subTypes.Add(currItemSubType);
				EditorUtility.SetDirty(itemsAsset);
				return currItemSubType;
			}
			else if (act == 3)
			{
				int pos = (int)args[2];
				for (int i = 0; i < itemsAsset.items.Count; i++)
				{
					if (itemsAsset.items[i].itemSubType == pos)
					{
						itemsAsset.items[i].itemSubType = -1;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
					else if (itemsAsset.items[i].itemSubType > pos)
					{	// those a level higher must move one down
						itemsAsset.items[i].itemSubType--;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
				}
			}
			else if (act == 4)
			{
				currItemSubType = currItemType.subTypes.Count > 0 ? currItemType.subTypes[0] : null;
				EditorUtility.SetDirty(itemsAsset);
				return currItemSubType;
			}
			else if (act == 5)
			{
				int prevPos = (int)args[1];
				int newPos = (int)args[2];
				for (int i = 0; i < itemsAsset.items.Count; i++)
				{
					if (itemsAsset.items[i].itemSubType == prevPos)
					{
						itemsAsset.items[i].itemSubType = newPos;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
					else if (itemsAsset.items[i].itemSubType == newPos)
					{
						itemsAsset.items[i].itemSubType = prevPos;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
				}
			}
			else if (act == 6)
			{
				plyTextInputWiz.ShowWiz("Rename Item Sub-type", "Enter a unique name", currItemSubType, OnRename, new object[] { 3 });
				return null;
			}
			EditorUtility.SetDirty(itemsAsset);
			return null;
		}

		private void EquipSlots()
		{
			EditorGUILayout.BeginHorizontal(plyEdGUI.LRPaddingHelperStyle);
			{
				plyEdGUI.ItemsList<string>(ref currSlot, itemsAsset.equipSlots, false, true, false, false, EquipSlotsCallback, ref scroll[1], null, "No Equip Slots defined", false, null, null, GUILayout.Width(200));
			}
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
		}

		private object EquipSlotsCallback(object sender, object[] args)
		{
			int act = (int)args[0];
			if (act == 1)
			{
				currSlot = "slot " + itemsAsset.equipSlots.Count;
				itemsAsset.equipSlots.Add(currSlot);
				EditorUtility.SetDirty(itemsAsset);
				return currSlot;
			}
			else if (act == 3)
			{
				int pos = (int)args[2];
				for (int i = 0; i < itemsAsset.items.Count; i++)
				{
					if (itemsAsset.items[i].equipSlot == pos)
					{
						itemsAsset.items[i].equipSlot = -1;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
					else if (itemsAsset.items[i].equipSlot > pos)
					{	// those a level higher must move one down
						itemsAsset.items[i].equipSlot--;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
				}
			}
			else if (act == 4)
			{
				currSlot = itemsAsset.equipSlots.Count > 0 ? itemsAsset.equipSlots[0] : null;
				EditorUtility.SetDirty(itemsAsset);
				return currSlot;
			}
			else if (act == 5)
			{
				int prevPos = (int)args[1];
				int newPos = (int)args[2];
				for (int i = 0; i < itemsAsset.items.Count; i++)
				{
					if (itemsAsset.items[i].equipSlot == prevPos)
					{
						itemsAsset.items[i].equipSlot = newPos;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
					else if (itemsAsset.items[i].equipSlot == newPos)
					{
						itemsAsset.items[i].equipSlot = prevPos;
						EditorUtility.SetDirty(itemsAsset.items[i]);
					}
				}
			}
			else if (act == 6)
			{
				plyTextInputWiz.ShowWiz("Rename Equip Slot", "Enter a unique name", currSlot, OnRename, new object[] { 1 });
				return null;
			}
			EditorUtility.SetDirty(itemsAsset);
			return null;
		}

		private void OnRename(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();
			if (!string.IsNullOrEmpty(s))
			{
				int act = (int)args[0];
				if (act == 1)
				{
					int i = itemsAsset.equipSlots.IndexOf(currSlot);
					currSlot = itemsAsset.equipSlots[i] = s;
					EditorUtility.SetDirty(itemsAsset);
				}
				else if (act == 2)
				{
					currItemType.name = s;
					EditorUtility.SetDirty(itemsAsset);
				}
				else if (act == 3)
				{
					int i = currItemType.subTypes.IndexOf(currItemSubType);
					currItemSubType = currItemType.subTypes[i] = s;
					EditorUtility.SetDirty(itemsAsset);
				}
			}
			ed.Repaint();
		}

		// ============================================================================================================

		private void ShowItems()
		{
			EditorGUILayout.BeginHorizontal(plyEdGUI.ToolbarStyle);
			{
				if (GUILayout.Button(GC_Refresh, plyEdGUI.ToolbarButtonStyle, GUILayout.Width(120)))
				{
					plyEdGUI.ClearFocus();
					RefreshItems();
				}
				EditorGUILayout.Space();
				if (GUILayout.Button(plyEdGUI.GC_Help, plyEdGUI.ToolbarIconButtonStyle))
				{
					Application.OpenURL(plyRPGEdGlobal.HLP_ItemsEd);
				}
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();

			if (itemsAsset.items.Count > 0)
			{
				scroll[0] = EditorGUILayout.BeginScrollView(scroll[0]);
				EditorGUILayout.BeginVertical(plyEdGUI.LRPaddingHelperStyle);
				{
					bool style2 = true;
					for (int i = 0; i < itemsAsset.items.Count; i++)
					{
						style2 = !style2;
						EditorGUILayout.BeginHorizontal(style2 ? plyEdGUI.ItemListEntry2Style : plyEdGUI.ItemListEntry1Style);
						{
							if (GUILayout.Button(GC_Ping, EditorStyles.miniButton, GUILayout.Width(20)))
							{
								EditorGUIUtility.PingObject(itemsAsset.itemFabs[i].gameObject);
							}

							GUILayout.Label(itemsAsset.items[i].ToString());
							GUILayout.FlexibleSpace();
						}
						EditorGUILayout.EndHorizontal();
					}
				}
				EditorGUILayout.Space();
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndScrollView();
			}
			else
			{
				GUILayout.Label("No Item prefabs detected. Use the Refresh\nbutton to force a refresh if needed.");
			}
		}

		private void RefreshItems()
		{
			List<Item> items = plyEdUtil.FindPrefabsOfTypeAll<Item>("Please wait", "Searching for all Item prefabs");
			itemsAsset.itemFabs = new List<GameObject>(0);
			for (int i = 0; i < items.Count; i++)
			{
				itemsAsset.itemFabs.Add(items[i].gameObject);
			}
			itemsAsset.UpdateItemCache();
			EditorUtility.SetDirty(plyRPGEdGlobal.edData);
		}

		// ============================================================================================================
/*
		private ItemsAsset itemsAsset;
		private Item currItem = null;

		private Vector2[] scroll = { Vector2.zero, Vector2.zero, Vector2.zero };
		private int activeImg = 0;

		private static GUIContent GC_plyBlox;
		private static GUIContent GC_plyBloxVars;
		private static GUIContent GC_General;
		private static GUIContent GC_ItemTypes;
		private static GUIContent GC_EquipSlots;
		private static GUIContent GC_SlotOff;
		private static GUIContent GC_SlotOn;
		private static GUIContent GC_UpdateScenes;
		private static GUIStyle SlotStyle;
	
		private int showDef = 0; // 0:item groups, 1:equip slots
		private string currSlot = null;
		private ItemType currItemType = null;
		private string currItemSubType = null;
		private string[] slotNames = new string[0];

		 ============================================================================================================

		public override void OnFocus()
		{
			if (itemsAsset == null)
			{
				currItem = null;
				DataAsset dataAsset = EdGlobal.GetDataAsset();
				itemsAsset = (ItemsAsset)dataAsset.GetAsset<ItemsAsset>();
				if (itemsAsset == null)
				{
					itemsAsset = (ItemsAsset)EdGlobal.LoadOrCreateAsset<ItemsAsset>(EdGlobal.DATA_PATH_SYSTEM + "items.asset", "Item Definitions");
					if (dataAsset.AddAsset(itemsAsset)) EditorUtility.SetDirty(dataAsset);
				}
			}

			slotNames = itemsAsset.equipSlots.ToArray();
		}

		private void InitGUI()
		{
			plyBloxGUI.UseSkin();
			if (GC_plyBlox == null)
			{
				GC_plyBlox = new GUIContent(" Edit Events", plyBloxGUI.LogoIcon16, "Open plyBlox Editor");
				GC_plyBloxVars = new GUIContent(" Edit Variables", FA.Ico16(FA.code, plyEdGUI.IconColor), "Edit Local plyBlox variables of object");

				GC_General = new GUIContent(FA.gear + " Settings");
				GC_ItemTypes = new GUIContent(FA.glass + " Item Types");
				GC_EquipSlots = new GUIContent(FA.male + " Equip Slots");
				GC_SlotOff = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.itemslots_0.png", typeof(EdGlobal).Assembly));
				GC_SlotOn = new GUIContent(plyEdGUI.LoadTextureResource("plyGameEditor.edRes.plyGame.itemslots_1.png", typeof(EdGlobal).Assembly));
				GC_UpdateScenes = new GUIContent(" Update Scenes", FA.Ico16(FA.refresh, plyEdGUI.IconColor), "Update the floor objects for this Item in scenes");

				SlotStyle = new GUIStyle()
				{
					padding = new RectOffset(0, 0, 0, 0),
					margin = new RectOffset(0, 0, 0, 0)
				};
			}
		}

		public override void OnGUI()
		{
			if (itemsAsset == null) return;
			InitGUI();

			EditorGUILayout.BeginHorizontal();
			{
				if (plyEdGUI.ItemsList<Item>(ref currItem, itemsAsset.items, true, false, OnListCallback, ref scroll[0], plyRPGEdGlobal.HLP_ItemsEd, "No Items Defined", true, new GUIContent[] { plyEdGUI.GC_Settings }, new BasicCallback[] { OnSettingsIcon }, GUILayout.Width(230)))
				{
					plyEdGUI.ClearFocus();
				}

				if (currItem != null)
				{
					ShowSelectedInfo();
				}
				else
				{
					Config();
				}
			}
			EditorGUILayout.EndHorizontal();

			// --------------------------------------------------------------------------------------------------------
			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(itemsAsset);
			}
		}

		private Item OnListCallback(object sender, object[] args)
		{
			int act = (int)args[0]; // 1:add, 2:copied, 3:deleting, 4:called after delete (return default), 5:position changed, 6:rename

			if (act == 1)
			{
				currItem = new Item();
				currItem.id = UniqueID.Create();
				currItem.def.screenName = "Item " + itemsAsset.items.Count;
				itemsAsset.items.Add(currItem);
				EditorUtility.SetDirty(itemsAsset);
				//CreateItemPrefab(currItem);
				return currItem;
			}
			else if (act == 2)
			{
				Item a = args[1] as Item;
				currItem = (Item)a.Copy();
				currItem.id = UniqueID.Create(); // need to create a new unique id for the copy
				currItem.def.screenName = currItem.def.screenName + " (copy)";

				if (a.eventHandlerPrefab != null)
				{
					currItem.eventHandlerPrefab = plyEdUtil.CopyPrefab(AssetDatabase.GetAssetPath(a.eventHandlerPrefab), plyRPGEdGlobal.DATA_PATH_ITEMS + currItem.id.ToString() + ".prefab");
				}

				itemsAsset.items.Add(currItem);
				EditorUtility.SetDirty(itemsAsset);
				//CreateItemPrefab(currItem);
				return currItem;
			}
			else if (act == 3)
			{
				Item it = (Item)args[1];
				if (it.eventHandlerPrefab != null) plyEdUtil.DeletePrefab(it.eventHandlerPrefab);
			}
			else if (act == 4)
			{
				currItem = itemsAsset.items.Count > 0 ? itemsAsset.items[0] : null;
				EditorUtility.SetDirty(itemsAsset);
				return currItem;
			}

			EditorUtility.SetDirty(itemsAsset);
			return null;
		}

		private void OnSettingsIcon()
		{
			currItem = null;
		}

		// ============================================================================================================

		private void ShowSelectedInfo()
		{
			scroll[1] = EditorGUILayout.BeginScrollView(scroll[1]);
			EditorGUILayout.BeginVertical();

			BasicInfo();
			plyBloxEdButtons();
			ItemInfo();

			plyEdGUI.HLine(20);
			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();
		}

		private void BasicInfo()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Item Definition");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				CommonDefinitionDataDrawer.Draw(currItem.def, ref activeImg);
			}
			EditorGUILayout.EndVertical();
		}

		private void ItemInfo()
		{
			EditorGUILayout.Space();
			plyEdGUI.SectionHeading("Item Info");
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(450));
			{
				GUILayout.Label("Prefabs");
				EditorGUI.indentLevel++;
				currItem.floorArtPrefab = (GameObject)EditorGUILayout.ObjectField("Item on Floor", currItem.floorArtPrefab, typeof(GameObject), false);
				currItem.heldArtPrefab = (GameObject)EditorGUILayout.ObjectField("Item Held", currItem.heldArtPrefab, typeof(GameObject), false);
				EditorGUI.indentLevel--;
				EditorGUILayout.BeginHorizontal();
				{
					GUILayout.Space(155);
					if (GUILayout.Button(GC_UpdateScenes, GUILayout.Width(130)))
					{
						if (EditorUtility.DisplayDialog("Update Scenes", "All scenes will be checked for an instance of this Item and then be updated with the new Floor Object. This can take a while. Continue?", "Yes", "No"))
						{
							UpdateScenes(currItem);
						}
					}
				}
				EditorGUILayout.EndHorizontal();
				EditorGUILayout.Space();

				GUILayout.Label("Interact");
				EditorGUI.indentLevel++;
				currItem.isCurrency = EditorGUILayout.Toggle("Is Currency", currItem.isCurrency);
				if (currItem.isCurrency)
				{
					currItem.minCurrency = EditorGUILayout.IntField("Min Value", currItem.minCurrency);
					currItem.maxCurrency = EditorGUILayout.IntField("Max Value", currItem.maxCurrency);
				}
				else
				{
					currItem.baseValue = EditorGUILayout.IntField("Base Value", currItem.baseValue);
				}

				bool ap = currItem.autoPickupDist > 0.0f;
				EditorGUI.BeginChangeCheck();
				ap = EditorGUILayout.Toggle("Auto-pickup", ap);
				if (EditorGUI.EndChangeCheck()) { currItem.autoPickupDist = ap ? 2.0f : 0.0f; EditorUtility.SetDirty(itemsAsset); }
				if (ap)
				{
					EditorGUI.indentLevel++;
					currItem.autoPickupDist = EditorGUILayout.FloatField("Distance", currItem.autoPickupDist);
					EditorGUI.indentLevel--;
				}
				EditorGUI.indentLevel--;
				EditorGUILayout.Space();

				if (false == currItem.isCurrency)
				{
					GUILayout.Label("Use");
					EditorGUI.indentLevel++;
					currItem.consumeOnUse = EditorGUILayout.Toggle("Consumed on Use", currItem.consumeOnUse);
					currItem.canEquip = EditorGUILayout.Toggle("Can be Equipped", currItem.canEquip);

					if (currItem.canEquip)
					{
						currItem.equipSlot = plyEdGUI.Popup("Slot", currItem.equipSlot, slotNames);
					}
					else
					{
						if (currItem.equipSlot != -1)
						{
							currItem.equipSlot = -1;
							GUI.changed = true;
						}
					}

					EditorGUI.indentLevel--;
					EditorGUILayout.Space();

					GUILayout.Label("Bag");
					EditorGUI.indentLevel++;
					currItem.maxStack = EditorGUILayout.IntField("Stack Size", currItem.maxStack);

					if (itemsAsset.storageMethod == ItemsAsset.StorageMethod.Weight)
					{
						currItem.weight = EditorGUILayout.FloatField("Weight", currItem.weight);
					}
					else if (itemsAsset.storageMethod == ItemsAsset.StorageMethod.Slots)
					{
						GUILayout.Label("    Slots Layout: " + currItem.hSlots + " x " + currItem.vSlots);

						EditorGUILayout.BeginHorizontal();
						GUILayout.Space(30);
						for (int x = 0; x < 6; x++)
						{
							EditorGUILayout.BeginVertical();
							for (int y = 0; y < 6; y++)
							{
								if (GUILayout.Button(currItem.hSlots > x && currItem.vSlots > y ? GC_SlotOn : GC_SlotOff, SlotStyle))
								{
									currItem.hSlots = x + 1;
									currItem.vSlots = y + 1;
									EditorUtility.SetDirty(itemsAsset);
								}
							}
							EditorGUILayout.EndVertical();
						}
						GUILayout.FlexibleSpace();
						EditorGUILayout.EndHorizontal();
					}
					EditorGUI.indentLevel--;
					EditorGUILayout.Space();
				}

			}
			EditorGUILayout.EndVertical();
		}

		private void plyBloxEdButtons()
		{
			EditorGUILayout.Space();
			EditorGUILayout.BeginHorizontal();
			if (GUILayout.Button(GC_plyBlox, GUILayout.Width(120), GUILayout.Height(25)))
			{
				GameObject go = GetEventResponderForCurrent();
				plyBlox blox = go.GetComponent<plyBlox>();
				if (blox != null)
				{
					Selection.activeObject = go;
					EditorGUIUtility.PingObject(Selection.activeObject);
					plyBloxEd.Show_plyBloxEd(blox, currItem.def.screenName);
				}
				else Debug.LogError("[Item Editor] The Item Event Responder object is invalid. No plyBlox object was found on it.");
			}
			EditorGUILayout.Space();
			if (GUILayout.Button(GC_plyBloxVars, GUILayout.Width(135), GUILayout.Height(25)))
			{
				GameObject go = GetEventResponderForCurrent();
				plyBlox blox = go.GetComponent<plyBlox>();
				if (blox != null)
				{
					Selection.activeObject = go;
					EditorGUIUtility.PingObject(Selection.activeObject);
				}
				else Debug.LogError("[Item Editor] The Item Event Responder object is invalid. No plyBlox object was found on it.");
			}
			GUILayout.FlexibleSpace();
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();
		}

		private GameObject GetEventResponderForCurrent()
		{
			if (currItem.eventHandlerPrefab == null)
			{
				// first check that path exist
				plyRPGEdGlobal.CheckDataPaths();

				// now create the event responder prefab and update item
				string fn = plyRPGEdGlobal.DATA_PATH_ITEMS + currItem.id.ToString() + ".prefab";
				currItem.eventHandlerPrefab = plyEdUtil.LoadOrCreatePrefab<plyBlox>(currItem.id.ToString(), fn);
				EditorUtility.SetDirty(itemsAsset);
			}
			return currItem.eventHandlerPrefab;
		}

		// ============================================================================================================



		// ============================================================================================================

		private void UpdateScenes(Item it)
		{
			string openScene = EditorApplication.currentScene;
			if (!EditorApplication.SaveCurrentSceneIfUserWantsTo()) return;

			float progress = 0f;
			float step = 1f;
			EditorUtility.DisplayProgressBar("Please wait", "Updating ...", progress);

			for (int i = 0; i < EditorBuildSettings.scenes.Length; i++)
			{
				if (EditorApplication.OpenScene(EditorBuildSettings.scenes[i].path))
				{
					bool changed = false;
					ItemInScene[] its = Object.FindObjectsOfType<ItemInScene>();
					if (its.Length > 0)
					{

						progress = 0f;
						step = 1f / (float)its.Length;						

						for (int a = its.Length - 1; a >= 0; a--)
						{
							progress += step;
							EditorUtility.DisplayProgressBar("Please wait", "Updating ...", progress);

							if (its[a].itemID == it.id)
							{
								changed = true;
								Vector3 pos = its[a].transform.position;
								Quaternion rot = its[a].transform.rotation;

								// destroy old object
								Object.DestroyImmediate(its[a].gameObject);

								// 1st create the parent if it does not exist
								GameObject parent = GameObject.Find("Items");
								if (!parent) parent = new GameObject("Items");

								// create item
								GameObject obj = it.floorArtPrefab == null ? new GameObject(it.def.screenName) : (GameObject)Object.Instantiate(it.floorArtPrefab);
								obj.name = it.def.screenName;
								obj.transform.position = pos;
								obj.transform.rotation = rot;
								obj.transform.parent = parent.transform;

								ItemInScene c = obj.AddComponent<ItemInScene>();
								c.itemID = it.id.Copy();
							}
						}
					}

					if (changed)
					{
						EditorApplication.SaveScene();
					}
				}
			}

			EditorUtility.ClearProgressBar();
			EditorApplication.OpenScene(openScene);
		}
*/
		// ============================================================================================================
	}
}