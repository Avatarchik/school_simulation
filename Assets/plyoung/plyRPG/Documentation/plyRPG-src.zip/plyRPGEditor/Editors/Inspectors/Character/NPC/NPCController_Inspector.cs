﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommonEditor;
using plyGame;
using plyCommon;

namespace plyGameEditor
{
	[CustomEditor(typeof(NPCController))]
	public class NPCController_Inspector : Editor
	{
		private NPCController Target;

		protected void OnEnable() 
		{
			Target = (NPCController)target;
		}

		public override void OnInspectorGUI()
		{
			Target.moveSpeed = EditorGUILayout.FloatField("Movement Speed", Target.moveSpeed);
			Target.runSpeed = EditorGUILayout.FloatField("Run Speed", Target.runSpeed);
			Target.turnSpeed = EditorGUILayout.FloatField("Turn Speed", Target.turnSpeed);

			EditorGUILayout.Space();
			Target.thinkInterval = EditorGUILayout.FloatField("Think Interval (sec)", Target.thinkInterval);

			Target.idleMode = (NPCController.IdleMode)EditorGUILayout.EnumPopup("Idle Mode", Target.idleMode);

			if (Target.idleMode == NPCController.IdleMode.Wander)
			{
				EditorGUI.indentLevel++;
				Target.wanderArea = (NPCController.WanderArea)EditorGUILayout.EnumPopup("Area", Target.wanderArea);
				if (Target.wanderArea == NPCController.WanderArea.Circular)
				{
					Target.wanderRadius = EditorGUILayout.FloatField("Wander Radius", Target.wanderRadius);
				}
				else
				{
					Target.wanderWH = EditorGUILayout.Vector2Field("Area Size", Target.wanderWH);
					Target.wanderRadius = EditorGUILayout.Slider("Angle", Target.wanderRadius, 0, 180);
				}
				Target.wanderDelayMin = EditorGUILayout.FloatField("Idle Delay Min", Target.wanderDelayMin);
				Target.wanderDelayMax = EditorGUILayout.FloatField("Idle Delay Max", Target.wanderDelayMax);
				EditorGUI.indentLevel--;
			}
			else if (Target.idleMode == NPCController.IdleMode.Patrol)
			{
				EditorGUI.indentLevel++;
				Target.path = (WaypointPath)EditorGUILayout.ObjectField("Path", Target.path, typeof(WaypointPath), true);
				EditorGUI.indentLevel--;
			}
			else if (Target.idleMode == NPCController.IdleMode.Follow)
			{
				EditorGUI.indentLevel++;
				Target.followObject = (Transform)EditorGUILayout.ObjectField("target", Target.followObject, typeof(Transform), true);
				Target.minFollowDistance = EditorGUILayout.FloatField("Min Distance", Target.minFollowDistance);
				Target.maxFollowDistance = EditorGUILayout.FloatField("Max Distance", Target.maxFollowDistance);
				EditorGUI.indentLevel--;
			}

			EditorGUILayout.Space();
			GUILayout.Label("Detection System");
			EditorGUI.indentLevel++;

			Target.canDetectPlayer = EditorGUILayout.Toggle("Can Detect Player", Target.canDetectPlayer);
			if (Target.canDetectPlayer)
			{
				EditorGUI.indentLevel++;
				Target.whenStatusTowardsPlayer = (StatusTowardsOther)EditorGUILayout.EnumPopup("when status to", Target.whenStatusTowardsPlayer);
				//Target.checkFactionToPlayer = EditorGUILayout.Toggle("or Faction to", Target.checkFactionToPlayer);
				//if (Target.checkFactionToPlayer) Target.whenFactionTowardPlayer = (StatusTowardsOther)EditorGUILayout.EnumPopup(" ", Target.whenFactionTowardPlayer);
				EditorGUI.indentLevel--;
			}

			Target.canDetectNPCs = EditorGUILayout.Toggle("Can Detect NPCs", Target.canDetectNPCs);
			if (Target.canDetectNPCs)
			{
				EditorGUI.indentLevel++;
				Target.whenStatusTowardNPC = (StatusTowardsOther)EditorGUILayout.EnumPopup("when status to", Target.whenStatusTowardNPC);
				EditorGUI.indentLevel--;
			}

			if (Target.canDetectPlayer || Target.canDetectNPCs)
			{
				Target.ignoreEssentialActor = EditorGUILayout.Toggle("Ignore if Essential", Target.ignoreEssentialActor);
				EditorGUILayout.Space();
				Target.detectionTimeout = EditorGUILayout.Slider("Interval", Target.detectionTimeout, 0.2f, 30f);
				Target.skipIfEngaged = EditorGUILayout.Toggle("Skip if Engaged", Target.skipIfEngaged);
				Target.autoEngageClosest = EditorGUILayout.Toggle("Auto Engage", Target.autoEngageClosest);

				EditorGUILayout.Space();
				Target.engagedMinDistance = EditorGUILayout.FloatField("Engaged Min Distance", Target.engagedMinDistance);
				Target.engagedMaxDistance = EditorGUILayout.FloatField("Engaged Max Distance", Target.engagedMaxDistance);

				EditorGUILayout.Space();
				Target.disengageDistanceHome = EditorGUILayout.FloatField("Disengage (home)", Target.disengageDistanceHome);
				Target.disengageDistanceTarget = EditorGUILayout.FloatField("Disengage (target)", Target.disengageDistanceTarget);
				EditorGUILayout.Space();

				Target.detection360Distance = EditorGUILayout.Slider("360 Distance", Target.detection360Distance, 1, 100);
				Target.detectionForwardDistance = EditorGUILayout.Slider("Forward Distance", Target.detectionForwardDistance, 1, 100);
				Target.detectionForwardAngle = EditorGUILayout.Slider("Forward Angle", Target.detectionForwardAngle, 10, 300);
				Target.detectionObstacleMask = plyEdGUI.LayerMaskField("360 Obstacles", Target.detectionObstacleMask, 0);
				Target.detectionFwObstacleMask = plyEdGUI.LayerMaskField("Forward Obstacles", Target.detectionFwObstacleMask, 0);
				Target.obstacleCheckOffsetY = EditorGUILayout.FloatField("Check Y-offset", Target.obstacleCheckOffsetY);
			}
			EditorGUI.indentLevel--;
		

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(target);
			}
		}

		protected void OnSceneGUI()
		{
			// *** IdleMode
			if (Target.idleMode == NPCController.IdleMode.Wander)
			{
				Vector3 p = EditorApplication.isPlaying ? Target.spawnLocation : Target.transform.position;
				if (Target.wanderArea == NPCController.WanderArea.Circular)
				{
					Handles.color = new Color(0.4f, 1f, 0.9f, 0.1f);
					Handles.DrawSolidDisc(p, Vector3.up, Target.wanderRadius);
					Handles.color = new Color(0.4f, 1f, 0.9f, 1f);
					Handles.DrawWireDisc(p, Vector3.up, Target.wanderRadius);
				}
				else
				{
					Vector3[] verts = plyUtil.RotatedRectangle(p, Target.wanderWH, Target.wanderRadius);
					Handles.color = Color.white;
					Handles.DrawSolidRectangleWithOutline(verts, new Color(0.4f, 1f, 0.9f, 0.1f), new Color(0.4f, 1f, 0.9f, 1f));
				}

			}
			else if (Target.idleMode == NPCController.IdleMode.Patrol)
			{
				if (Target.path != null)
				{
					Handles.color = new Color(0.4f, 1f, 0.9f, 1f);
					Handles.DrawLine(Target.transform.position + Vector3.up * 0.3f, Target.path.transform.position + Vector3.up * 0.3f);
				}
			}
			else if (Target.idleMode == NPCController.IdleMode.Follow)
			{
				if (Target.followObject != null)
				{
					Handles.color = new Color(0.4f, 1f, 0.9f, 1f);
					Handles.DrawLine(Target.transform.position + Vector3.up * 0.3f, Target.followObject.position + Vector3.up * 0.3f);
				}
			}

			if (Target.canDetectPlayer || Target.canDetectNPCs)
			{
				// *** Detection (360)
				Handles.color = new Color(1f, 0.1f, 0f, 0.1f);
				Handles.DrawSolidDisc(Target.transform.position, Vector3.up, Target.detection360Distance);
				Handles.color = new Color(1f, 0.1f, 0f, 1f);
				Handles.DrawWireDisc(Target.transform.position, Vector3.up, Target.detection360Distance);

				// *** Detection (forward)
				Handles.color = new Color(1f, 0.4f, 0f, 0.1f);
				Handles.DrawSolidArc(Target.transform.position, Target.transform.up, Quaternion.AngleAxis(-(Target.detectionForwardAngle / 2f), Target.transform.up) * Target.transform.forward, Target.detectionForwardAngle, Target.detectionForwardDistance);
				Handles.color = new Color(1f, 0.4f, 0f, 1f);
				Handles.DrawWireArc(Target.transform.position, Target.transform.up, Quaternion.AngleAxis(-(Target.detectionForwardAngle / 2f), Target.transform.up) * Target.transform.forward, Target.detectionForwardAngle, Target.detectionForwardDistance);
			}
		}

		// ============================================================================================================
	}
}
