﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyBloxKitEditor;
using plyCommonEditor;
using plyGame;
using plyCommon;

namespace plyGameEditor
{
	[plyPropertyHandler(typeof(SkillFieldData))]
	public class SkillFieldData_Handler : plyBlockFieldHandler
	{

		private SkillsAsset skillsAsset;

		public override object GetCopy(object obj)
		{
			SkillFieldData target = obj as SkillFieldData;
			if (target != null) return target.Copy();
			return new SkillFieldData();
		}

		public override void OnFocus(object obj, plyBlock fieldOfBlock)
		{
			SkillFieldData target = obj == null ? new SkillFieldData() : obj as SkillFieldData;
			if (skillsAsset == null)
			{
				skillsAsset = (SkillsAsset)EdGlobal.LoadOrCreateAsset<SkillsAsset>(EdGlobal.DATA_PATH_SYSTEM + "skills.asset", "Skill Definitions");
				skillsAsset.UpdateCache();
			}

			// check if saved skill still valid
			if (!string.IsNullOrEmpty(target.id))
			{
				bool found = false;
				UniqueID id = new UniqueID(target.id);
				for (int i = 0; i < skillsAsset.skills.Count; i++)
				{
					if (id == skillsAsset.skills[i].id) { found = true; break; }
				}
				if (!found)
				{
					target.id = "";
					target.cachedName = "";
					ed.ForceSerialise();
				}
			}
		}

		public override bool DrawField(ref object obj, plyBlock fieldOfBlock)
		{
			bool ret = (obj == null);
			SkillFieldData target = obj == null ? new SkillFieldData() : obj as SkillFieldData;

			if (GUILayout.Button(string.IsNullOrEmpty(target.cachedName) ? "-select-" : target.cachedName))
			{
				skillsAsset.UpdateCacheIfNeeded();
				List<object> l = new List<object>();
				for (int i = 0; i < skillsAsset.skills.Count; i++) l.Add(new UniqueIdNamePair() { id = skillsAsset.skills[i].id.Copy(), name = skillsAsset.skills[i].def.screenName });
				plyListSelectWiz.ShowWiz("Select Skill", l, true, null, OnSkillSelect, new object[] { ed, target });
			}

			obj = target;
			return ret;
		}

		private void OnSkillSelect(object sender, object[] args)
		{
			SkillFieldData target = args[1] as SkillFieldData;
			plyBloxEd plyed = args[0] as plyBloxEd;

			plyListSelectWiz wiz = sender as plyListSelectWiz;
			UniqueIdNamePair uimp = wiz.selected as UniqueIdNamePair;
			wiz.Close();

			if (plyed == null || target == null) return;

			GUI.changed = true;
			if (uimp != null)
			{
				target.id = uimp.id.ToString();
				target.cachedName = uimp.name;
			}
			else
			{
				target.id = "";
				target.cachedName = "";
			}
			plyed.ForceSerialise();
			plyed.Repaint();
		}
		
		// ============================================================================================================
	}
}