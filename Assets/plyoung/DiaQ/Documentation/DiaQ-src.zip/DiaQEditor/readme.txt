 -= Notes on compiling =-
 
Do NOT copy any of the scripts (source files) 
into your Unity project (Assets folder).
It will cause errors if you do.
 
You will have to update the references to point to the
plyBlox and plyCommon DLLs (found in Assets/plyoung/...)

Open the project properties and go to 'Build Events'
There you will notice Post-build commands. Update
these to point to the correct paths or remove it.
If you remove it you will have to copy the DLLs to
the correct Assets/plyoung/.... folder manually 
after each build.

If you are struggling to build/ compile this code then 
you should probably not be messing around with it.

Please use the forum to ask questions.
http://plyoung.com/forum/