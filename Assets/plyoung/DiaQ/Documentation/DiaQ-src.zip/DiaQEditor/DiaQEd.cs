﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;

namespace DiaQEditor
{

	public class DiaQEd : EditorWindow
	{
		// ============================================================================================================
		#region vars

		[System.NonSerialized] private plyGraphEditor graphEd = null;
		private static GUIContent[] extraIcons = null;
		private BasicCallback[] extraCallbacks = new BasicCallback[] { DiaQEdGlobal.ShowDiaQuestWindow, DiaQEdGlobal.ShowDiaSettingsWindow };

		#endregion
		// ============================================================================================================
		#region init

		public static void ShowDiaQEditorWindow()
		{
			DiaQEd win = EditorWindow.GetWindow<DiaQEd>("DiaGraphs");
		}

		#endregion
		// ============================================================================================================
		#region system

		protected void OnDestroy()
		{
			if (graphEd != null) graphEd.OnDestroy();
		}

		protected void OnFocus()
		{
			if (graphEd == null) graphEd = new plyGraphEditor(DiaQEdGlobal.GraphsAsset, this, new List<string>() { "Common", "DiaQ" }, new Color(0.375f, 0.535f, 0.578f, 1f), plyEdGUI.GridLineMinorColor, plyEdGUI.GridLineMajorColor, EditorGUIUtility.isProSkin ? new Color(0f, 0f, 0f, 1f) : new Color(0f, 0f, 0f, 0.3f), plyEdGUI.LoadTextureResource("DiaQEditor.edRes.logo2.png", typeof(DiaQEd).Assembly), DiaQEdGlobal.HLP_URL);
			else if (false == DiaQEdGlobal.GraphAssetValid()) graphEd.SetAsset(DiaQEdGlobal.GraphsAsset);
			graphEd.OnFocus(this, DiaQEdGlobal.GraphsAsset);
		}

		protected void OnLostFocus()
		{
			graphEd.OnLostFocus(this);
		}

		protected void Update()
		{
			if (EditorApplication.isPlayingOrWillChangePlaymode) return;
			if (graphEd == null) return;
			graphEd.Update(this);
		}

		private void SetSkin()
		{
			plyEdGUI.UseSkin();			
			if (extraIcons == null) 
			{
				extraIcons = new GUIContent[2];
				extraIcons[0] = new GUIContent(FA.star.ToString(), "DiaQuest Editor");
				extraIcons[1] = new GUIContent(FA.gear.ToString(), "DiaQ Settings");
			}
		}

		protected void OnGUI()
		{
			if (graphEd == null) return;
			if (EditorApplication.isPlayingOrWillChangePlaymode)
			{
				ShowNotification(new GUIContent("Can't edit DiaQ in play mode"));
				return;
			}

			SetSkin();

			EditorGUILayout.BeginHorizontal();
			{
				// graph menu
				graphEd.RenderGraphMenu(this, 220, extraIcons, extraCallbacks);

				// graph main area
				graphEd.RenderGraphGUI(this);
			}
			EditorGUILayout.EndHorizontal();
		}

		#endregion
		// ============================================================================================================
	}
}
