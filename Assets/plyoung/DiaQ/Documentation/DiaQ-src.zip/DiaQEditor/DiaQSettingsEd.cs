﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;

namespace DiaQEditor
{
	public class DiaQSettingsEd : EditorWindow
	{
		private Vector2 scroll = Vector2.zero;
		private int curr = -1;
		private int res;

		// ============================================================================================================

		public static void Show_DiaQSettingsEd()
		{
			EditorWindow.GetWindow<DiaQSettingsEd>("DiaQ");
		}

		protected void OnFocus()
		{
			plyGraphEditor.OnFocusGraphAssetSettings(this);
		}

		// ============================================================================================================

		protected void OnGUI()
		{
			plyEdGUI.UseSkin();
			scroll = EditorGUILayout.BeginScrollView(scroll);
			{
				plyGraphEditor.RenderGraphAssetSettings(DiaQEdGlobal.GraphsAsset, this, "DiaQ Global MetaData", DiaQEdGlobal.HLP_URL);

				plyEdGUI.HLine(20);
				EditorGUILayout.Space();
				plyEdGUI.SectionHeading("Inline Values", false);

				///		0: Nothing changed
				///		1: Another Item selected in List
				///		2: The Add button was pressed. You need to handle the actual addition of an item to the list
				///		10: (or greater) An item must be deleted. The returned value is the index of the item plus 10 so use (idx = result - 10) to get index of item to delete
				res = plyEdGUI.SimpleItemList<plyInlineValue>(ref curr, DiaQEdGlobal.EngineAsset.inlineValues, null, OnDrawInlineValue);
				if (res >= 1)
				{
					if (res == 2)
					{
						plyTextInputWiz.ShowWiz("Value Name", "Enter a unique name", "", OnAddValue, null);
					}
					else if (res >= 10)
					{
						res -= 10; 
						if (curr > 0) curr--;
						if (curr == res) curr--;

						DiaQEdGlobal.EngineAsset.inlineValues.RemoveAt(res);
						EditorUtility.SetDirty(DiaQEdGlobal.EngineAsset);
					}
					Repaint();
				}

			}
			GUILayout.Space(20);
			EditorGUILayout.EndScrollView();

			if (GUI.changed)
			{
				GUI.changed = false;
				EditorUtility.SetDirty(DiaQEdGlobal.EngineAsset);
			}
		}

		public void OnAddValue(object sender, object[] args)
		{
			plyTextInputWiz wiz = sender as plyTextInputWiz;
			string s = wiz.text;
			wiz.Close();

			if (false == string.IsNullOrEmpty(s))
			{
				plyInlineValue v = new plyInlineValue();
				v.name = s;
				if (false == string.IsNullOrEmpty(v.name))
				{
					for (int i = 0; i < DiaQEdGlobal.EngineAsset.inlineValues.Count; i++)
					{
						if (DiaQEdGlobal.EngineAsset.inlineValues[i].name.Equals(v.name))
						{
							EditorUtility.DisplayDialog("Error", "You need to enter a unique name for the inline value", "Ok");
							return;
						}
					}

					DiaQEdGlobal.EngineAsset.inlineValues.Add(v);
					EditorUtility.SetDirty(DiaQEdGlobal.EngineAsset);
				}
				else
				{
					EditorUtility.DisplayDialog("Error", "You need to enter a unique name for the inline value. The name should not include any spaces or the character { and }", "Ok");
				}
			}

			Repaint();
		}

		public void OnDrawInlineValue(object sender, object[] args)
		{
			int i = (int)args[0];

			if (plyDataObjectEditor.DrawField(DiaQEdGlobal.EngineAsset.inlineValues[i].name, ref DiaQEdGlobal.EngineAsset.inlineValues[i].valueDataProvider, "data", this.Repaint, SimpleSaveCallback, plyEdGUI.ButtonLeftStyle))
			{
				GUI.changed = true;
			}
		}

		public void SimpleSaveCallback()
		{
			EditorUtility.SetDirty(DiaQEdGlobal.EngineAsset);
		}
		
		// ============================================================================================================
	}
}
