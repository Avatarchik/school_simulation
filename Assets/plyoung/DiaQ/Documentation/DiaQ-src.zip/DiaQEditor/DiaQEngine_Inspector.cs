﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyCommonEditor;
using plyCommon;
using DiaQ;

namespace DiaQEditor
{
	[CustomEditor(typeof(DiaQEngine))]
	public class DiaQEngine_Inspector : Editor
	{
		public override void OnInspectorGUI()
		{
			//EditorGUILayout.Space();
			//DrawDefaultInspector();
		}

		// ============================================================================================================
	}
}
