﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyCommonEditor;
using plyCommonEditor.FontAwesome;
using DiaQ;

namespace DiaQEditor
{
	public class DiaQDataProviderInfo : plyDataProviderInfo
	{

		// nfo[0]: kind of metaData (0=DiaQ, 1:Graph, 2:Node, 3:Quest)
		// nfo[1]: Graph id or Quest id
		// nfo[2]: Node id
		// nfo[3]: metaData name
		// nfo[4]: a pretty name helper for 'Graph.Node' path
		// nfo[5]: what kind of data (0:metaData, 1:Graph Object, 2:Quest Object)
		// note: setting graph or quest not supported

		private static string[] MainOptions = { "Value of metaData", "Graph Object", "Quest Object" };
		private static string[] Options = { "DiaQ", "Graph", "Node", "Quest" };
		private int mainSelected = 0;
		private int selected = 0;
		private bool selectingGraph = false;
		private bool selectingNode = false;
		private bool selectingQuest = false;
		private bool wantSelectNode = false;
		private plyGraph selectedGraph = null;

		private static GUIContent GC_BACK;

		public DiaQDataProviderInfo()
		{
			GC_BACK = new GUIContent(" Back", FA.Ico12(FA.arrow_circle_o_left, plyEdGUI.IconColor));
		}

		public override string ProviderName()
		{
			return "DiaQ";
		}

		public override string PrettyName(plyDataObject data, string emptyText)
		{
			if (data.nfo[5] == "0")
			{
				if (data.nfo[0] == "0") return "DiaQ." + (string.IsNullOrEmpty(data.nfo[3]) ? "unknown" : data.nfo[3]);
				if (data.nfo[0] == "1") return "DiaGraph." + (string.IsNullOrEmpty(data.nfo[3]) ? "unknown" : data.nfo[3]);
				if (data.nfo[0] == "2") return "DiaNode." + (string.IsNullOrEmpty(data.nfo[3]) ? "unknown" : data.nfo[3]);
				if (data.nfo[0] == "3") return "DiaQuest." + (string.IsNullOrEmpty(data.nfo[3]) ? "unknown" : data.nfo[3]);
			}
			else if (!string.IsNullOrEmpty(data.nfo[4]))
			{
				return data.nfo[4];
			}
			return emptyText;
		}

		public override plyDataObject.TargetObjectType DefaultTargetType()
		{
			return plyDataObject.TargetObjectType.Name;
		}

		public override string DefaultTargetTypeData()
		{
			return "DiaQ";
		}

		public override string DefaultComponent()
		{
			return typeof(DiaQEngine).Name;
		}

		public override string[] InitNfo()
		{
			return (new string[] { "1", "", "", "", "", "0" });
		}

		public override bool CanChangeType()
		{
			return false;
		}

		public override void NfoFieldFocus(plyDataObject data, EditorWindow ed)
		{
			selectedGraph = null;
			selectingGraph = false;
			selectingNode = false;
			wantSelectNode = false;
			selected = 0;
			mainSelected = 0;
			int.TryParse(data.nfo[0], out selected);
			int.TryParse(data.nfo[5], out mainSelected);
		}

		public override void NfoField(plyDataObject data, EditorWindow ed)
		{
			if (selectingQuest)
			{
				ShowSelectingQuest(data);
				return;
			}

			if (selectingNode)
			{
				ShowSelectingNode(data);
				return;
			}

			if (selectingGraph)
			{
				ShowSelectingGraph(data);
				return;
			}

			EditorGUI.BeginChangeCheck();
			mainSelected = EditorGUILayout.Popup(mainSelected, MainOptions);
			if (EditorGUI.EndChangeCheck())
			{
				data.nfo[0] = "1";
				data.nfo[1] = ""; data.nfo[2] = "";
				data.nfo[3] = ""; data.nfo[4] = "";
				data.nfo[5] = mainSelected.ToString();
			}

			// ***  meta data
			if (mainSelected == 0)
			{
				data.nfo[3] = EditorGUILayout.TextField("named", data.nfo[3]);

				EditorGUI.BeginChangeCheck();
				selected = EditorGUILayout.Popup("in", selected, Options);
				if (EditorGUI.EndChangeCheck()) data.nfo[0] = selected.ToString();

				if (selected == 1)
				{
					if (plyEdGUI.LabelButton(" ", string.IsNullOrEmpty(data.nfo[4]) ? "-select-" : data.nfo[4], 95, 0))
					{
						selectingGraph = true;
						selectingNode = false;
						wantSelectNode = false;
					}
				}
				else if (selected == 2)
				{
					if (plyEdGUI.LabelButton(" ", string.IsNullOrEmpty(data.nfo[4]) ? "-select-" : data.nfo[4], 95, 0))
					{
						selectingGraph = true;
						selectingNode = false;
						wantSelectNode = true;
					}
				}
				else if (selected == 3)
				{
					if (plyEdGUI.LabelButton(" ", string.IsNullOrEmpty(data.nfo[4]) ? "-select-" : data.nfo[4], 95, 0))
					{
						selectingQuest = true;
						selectingGraph = false;
						selectingNode = false;
						wantSelectNode = false;
					}
				}
			}

			// ***  graph object
			else if (mainSelected == 1)
			{
				if (plyEdGUI.LabelButton(" ", string.IsNullOrEmpty(data.nfo[4]) ? "-select-" : data.nfo[4], 95, 0))
				{
					selectingGraph = true;
					selectingNode = false;
					wantSelectNode = false;
				}
			}

			// ***  quest object
			else if (mainSelected == 2)
			{
				if (plyEdGUI.LabelButton(" ", string.IsNullOrEmpty(data.nfo[4]) ? "-select-" : data.nfo[4], 95, 0))
				{
					selectingQuest = true;
					selectingGraph = false;
					selectingNode = false;
					wantSelectNode = false;
				}
			}
		}

		private void ShowSelectingGraph(plyDataObject data)
		{
			GUILayout.Label("Select Graph");
			if (GUILayout.Button(GC_BACK))
			{
				selectingGraph = false;
				return;
			}

			foreach (plyGraph g in DiaQEdGlobal.GraphsAsset.graphs)
			{
				if (GUILayout.Button(g.name))
				{
					data.nfo[1] = g.id.ToString();	// graph ident
					data.nfo[2] = "";				// node ident
					data.nfo[4] = g.name;			// pretty name
					if (wantSelectNode)
					{
						selectedGraph = g;
						selectingNode = true;
					}
					else
					{
						selectingGraph = false;
					}
					return;
				}
			}
		}

		private void ShowSelectingNode(plyDataObject data)
		{
			GUILayout.Label("Select Node");
			if (GUILayout.Button(GC_BACK))
			{
				selectedGraph = null;
				selectingNode = false;
				return;
			}

			foreach (plyNode n in selectedGraph.nodes)
			{
				string s = string.IsNullOrEmpty(n.customIdent) ? (n.id + "." + n.PrettyName()) : n.customIdent;
				if (GUILayout.Button(s))
				{
					selectedGraph = null;
					selectingGraph = false;
					selectingNode = false;
					data.nfo[2] = n.id.ToString();	// node ident
					data.nfo[4] += "." + s;			// pretty name
					return;
				}
			}
		}

		private void ShowSelectingQuest(plyDataObject data)
		{
			GUILayout.Label("Select Quest");
			if (GUILayout.Button(GC_BACK))
			{
				selectingQuest = false;
				return;
			}

			foreach (DiaQuest q in DiaQEdGlobal.QuestsAsset.quests)
			{
				if (GUILayout.Button(q.name))
				{
					data.nfo[1] = q.id.ToString();	// quest ident
					data.nfo[2] = "";				// node ident
					data.nfo[4] = q.name;			// pretty name
					selectingQuest = false;
					return;
				}
			}
		}

		// ============================================================================================================
	}
}
