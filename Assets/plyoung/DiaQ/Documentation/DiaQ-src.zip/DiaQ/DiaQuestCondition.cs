﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace DiaQ
{
	/// <summary> A DiaQ Quest Condition to complete. You should use the functions in DiaQuest and not interact
	/// with the condition directly, except when you want to interact with the metaData. If you change value 
	/// here directly the quest might not pick up on the state change of the condition and not be able to 
	/// update whether the quest is completed </summary>
	[System.Serializable]
	public class DiaQuestCondition: plyMetaDataInterface
	{
		/// <summary> identifies the condition </summary>
		public string key = "";

		/// <summary> most quests have to do with collecting or doing something a number of times.
		/// This field can be used to indicate the amount needed. </summary>
		public int targetValue = 1;

		/// <summary> Text associated with the condition </summary>
		public string text = "";

		/// <summary> Extra data that can be associated with the condition. Do not access at runtime, use provided functions. </summary>
		public plyMetaData[] metaData = new plyMetaData[0];

		// ============================================================================================================

		/// <summary> Indicates that this condition is met. will not reset progress if set to false. </summary>
		public bool completed
		{
			get
			{
				return _completed;
			}
			set
			{
				_completed = value;
				if (_completed) _performedTimes = targetValue;
			}
		}
		private bool _completed = false;

		/// <summary> how many times the condition has been performed. Once this value reaches targetValue 
		/// the condition will be considered completed </summary>
		public int performedTimes
		{
			get
			{
				return _performedTimes;
			}
			set
			{
				_performedTimes = value;
				if (_performedTimes >= targetValue) completed = true;
			}
		}
		private int _performedTimes = 0;

		public Dictionary<string, plyMetaData> runtimeMetaData { get; private set; }

		// ============================================================================================================

		/// <summary> called by Quest's Awake at runtime </summary>
		public void Awake()
		{
			runtimeMetaData = new Dictionary<string, plyMetaData>(0);
			for (int i = 0; i < metaData.Length; i++)
			{
				if (metaData == null) continue;
				runtimeMetaData.Add(metaData[i].name, metaData[i]);
			}
			if (false == Application.isEditor) metaData = null;
		}

		// ============================================================================================================

		public Dictionary<string, plyMetaData> AllMetaData()
		{
			return runtimeMetaData;
		}

		public List<plyMetaData> AllMetaDataList()
		{
			List<plyMetaData> r = new List<plyMetaData>();
			foreach(plyMetaData md in runtimeMetaData.Values) r.Add(md);
			return r;
		}

		/// <summary> Return reference to meta data object. Null if not found. </summary>
		public plyMetaData GetMetaData(string name)
		{
			if (runtimeMetaData.ContainsKey(name)) return runtimeMetaData[name];
			return null;
		}

		/// <summary> Return meta data value. Null if named meta data not found. </summary>
		public object GetMetaDataValue(string name)
		{
			plyMetaData md = GetMetaData(name);
			if (md == null) return null;
			return md.GetValue();
		}

		/// <summary> Set meta data value. Will create the named meta data if not found and then set value. </summary>
		public void SetMetaDataValue(string name, object val)
		{
			plyMetaData md = GetMetaData(name);
			if (md == null)
			{
				md = new plyMetaData();
				md.name = name;
				runtimeMetaData.Add(name, md);
			}
			md.SetValue(val);
		}

		/// <summary>
		/// Return parsed text. The inline values will be inserted if any present in text.
		/// </summary>
		public string ParsedConditionText()
		{
			return plyInlineValue.ParseText(text, DiaQEngine.Instance.inlineValues);
		}

		// ============================================================================================================
	}
}
