﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;

namespace DiaQ
{
	/// <summary> Provide access to Quest Data </summary>
	[AddComponentMenu("")]
	public class DiaQuestManager : MonoBehaviour
	{
		/// <summary> All defined quests </summary>
		public List<DiaQuest> quests = new List<DiaQuest>();

		/// <summary> Used by editor. Do not manipulate. </summary>
		public int __next_quest_id = 0;

		// ============================================================================================================	
		#region system

		protected void Awake()
		{
			for (int i = 0; i < quests.Count; i++)
			{
				quests[i].Awake();
			}
		}

		#endregion
		// ============================================================================================================	
		#region pub

		/// <summary> Get quest by its unique id. Return null if not found. </summary>
		public DiaQuest GetQuestById(int id)
		{
			if (id < 0) return null;
			for (int i = 0; i < quests.Count; i++)
			{
				if (quests[i].id == id) return quests[i];
			}
			return null;
		}

		/// <summary> Get quest by its name. Return null if not found. </summary>
		public DiaQuest GetQuestByName(string name)
		{
			if (string.IsNullOrEmpty(name)) return null;
			for (int i = 0; i < quests.Count; i++)
			{
				if (quests[i].name.Equals(name)) return quests[i];
			}
			return null;
		}

		/// <summary> Get quest by its custom ident. Return null if not found. </summary>
		public DiaQuest GetQuestByIdent(string ident)
		{
			if (string.IsNullOrEmpty(ident)) return null;
			for (int i = 0; i < quests.Count; i++)
			{
				if (quests[i].customIdent.Equals(ident)) return quests[i];
			}
			return null;
		}

		/// <summary> Update all quests that the player has accepted and not completed, which uses the same condition key.
		/// This will update the condition and note that it has been performed. The condition will be
		/// considered completed once it has been performed the target number of times DiaQuestCondition.targetValue.
		/// Will update DiaQuest.completed when quest is completed. </summary>
		public void ConditionPerformed(string key)
		{
			for (int a = 0; a < quests.Count; a++)
			{
				if (quests[a].completed) continue;
				if (!quests[a].accepted) continue;
				quests[a].ConditionPerformed(key);
			}
		}

		/// <summary> Update all quests that the player has accepted and not completed, which uses the same condition key.
		/// This will update the condition's value. It is possible to send a negative value to decrease the performedTimes
		/// of the quest condition. </summary>
		public void ConditionPerformed(string key, int val)
		{
			for (int a = 0; a < quests.Count; a++)
			{
				if (quests[a].completed) continue;
				if (!quests[a].accepted) continue;
				quests[a].ConditionPerformed(key, val);
			}
		}

		#endregion
		// ============================================================================================================	
	}
}
