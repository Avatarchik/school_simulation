﻿// -= DiaQ =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using plyCommon;

namespace DiaQ
{
	/// <summary>
	/// Branch depending on status of quest
	/// </summary>
	public class DiaQNode_QStatus : plyNode
	{
		// ============================================================================================================
		#region properties

		/// <summary> The quest to check </summary>
		public int questId = -1;

		#endregion
		// ============================================================================================================
		#region pub

		public override string PrettyName()
		{
			return "Quest Status";
		}

		public override void OnAddedToGraph()
		{
			base.OnAddedToGraph();
			__rect.width = 130;
		}

		public override void CopyTo(plyNode n)
		{
			base.CopyTo(n);
			DiaQNode_QStatus o = n as DiaQNode_QStatus;

			o.questId = this.questId;
		}

		public override int InitOutlinkCount()
		{
			return 4;
		}

		public override int Enter()
		{
			DiaQuest q = DiaQEngine.Instance.questManager.GetQuestById(questId);
			if (q == null)
			{
				LogError("The Quest could not be found. It might have been removed.");
				return (int)ReturnCode.Stop;
			}

			if (q.rewarded) return 0;
			else if (q.completed) return 1;
			else if (q.accepted) return 2;
			return 3;
		}

		#endregion
		// ============================================================================================================	
	}
}
